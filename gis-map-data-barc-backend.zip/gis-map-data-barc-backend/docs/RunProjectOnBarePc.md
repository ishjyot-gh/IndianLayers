# Check Docker
docker --version
docker compose version

# Install Docker On Ubuntu/Linux
sudo apt update
sudo apt install -y docker.io docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER

# Then log out and log in again, or reboot.

# Check Again
docker --version
docker compose version

# Run Packaged Project Zip
unzip gis-map-data-barc-backend-release.zip
cd gis-map-data-barc-backend-release
docker compose up --build

# Open:
http://localhost:5000/

// If other dependencies there then :
# go to project folder
cd gis-map-data-barc-backend-release

# install root npm dependencies
npm install

# install backend npm dependencies
cd backend
npm install

# if auth packages are not already in package.json
npm install bcryptjs jsonwebtoken

# go back and run
cd ..
npm start

# If express / pg are missing

cd backend
npm install express pg bcryptjs jsonwebtoken