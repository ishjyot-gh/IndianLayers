# GIS Map Backend Database ERD

This document explains the final database structure for the GIS map backend.
If Mermaid diagrams are not rendered in your viewer, open the real box-and-arrow ERD file:

```text
docs/database_erd.svg
```

![Database ERD](./database_erd.svg)

The database is PostgreSQL with the PostGIS extension enabled.

The main concept is:

- `sites` stores each GIS/NPP site.
- GIS layers are stored through `layer_catalog`, `site_layers`, and `geo_features`.
- Instruments are linked to a site through `erc_locations`.
- Contacts can be global for all sites or linked to selected sites.
- Users can be referenced by instruments for assignment/checking metadata.

## Entity Relationship Diagram

```mermaid
erDiagram
    USERS {
        integer id PK
        text name
        text email UK
        text password_hash
        text role
        timestamptz created_at
        integer emp_no UK
        varchar first_name
        varchar last_name
        varchar user_type
        varchar designation
        varchar section
        varchar division
        varchar location
        varchar extension
    }

    SITES {
        integer id PK
        text name
        text folder
        text state
        text zone
        text reactor_type
        integer installed_capacity_mw
        integer units
        text operator
        text status
        text description
        double latitude
        double longitude
    }

    LAYER_CATALOG {
        text layer_key PK
        text display_name
        text category
        text geometry_type
    }

    SITE_LAYERS {
        integer site_id PK, FK
        text layer_key PK, FK
        text file_name
        boolean is_enabled
    }

    GEO_FEATURES {
        bigint id PK
        integer site_id FK
        text layer_key FK
        jsonb properties
        geometry geom
    }

    ERC_LOCATIONS {
        integer erc_id PK
        integer site_id FK
        varchar erc_state
        varchar location
        varchar unit
        varchar coordinator
        varchar phone_number_o
        varchar phone_number_h
        varchar mobile_number
    }

    MANUFACTURERS {
        integer manufacturer_id PK
        varchar manufacturer_name
        varchar address
        varchar phone_number
        varchar fax_number
        varchar email
        varchar supplier_name_and_address
    }

    INSTRUMENT_CATEGORIES {
        integer instrument_category_id PK
        varchar monitor_type
        varchar ranges
        integer efficiency
        varchar resolution
        varchar calib_factor
        varchar sensitivity
        varchar remarks
    }

    INSTRUMENT_STATUS {
        integer status_id PK
        varchar status_des
    }

    INSTRUMENTS {
        bigint inst_id PK
        integer erc_id FK
        integer manufacturer_id FK
        integer category_id FK
        integer status_id FK
        integer checked_by_user_id FK
        integer assigned_to_user_id FK
        date checked_on
        date calibrated_on
        varchar inst_sno
        varchar inst_model
        varchar curr_location
        varchar bcode_verification
        integer efficiency
        varchar resolution
        varchar calib_factor
        varchar sensitivity
        varchar datasheet
        varchar remark
        timestamptz created_at
        timestamptz updated_at
    }

    CONTACTS {
        bigint id PK
        text contact_category
        text dae_unit
        text std_code
        text unit
        text name
        text designation
        text office_tel_fax
        text head_tel_fax
        text residence_mobile
        text email
        text address
        text remarks
        boolean applies_to_all_sites
        timestamptz created_at
        timestamptz updated_at
    }

    SITE_CONTACT_LINKS {
        integer site_id PK, FK
        bigint contact_id PK, FK
    }

    SITES ||--o{ SITE_LAYERS : has_enabled_layers
    LAYER_CATALOG ||--o{ SITE_LAYERS : defines_layer

    SITES ||--o{ GEO_FEATURES : owns_features
    LAYER_CATALOG ||--o{ GEO_FEATURES : classifies_features

    SITES ||--o{ ERC_LOCATIONS : has_erc_locations
    ERC_LOCATIONS ||--o{ INSTRUMENTS : contains_instruments

    MANUFACTURERS ||--o{ INSTRUMENTS : made_by
    INSTRUMENT_CATEGORIES ||--o{ INSTRUMENTS : categorizes
    INSTRUMENT_STATUS ||--o{ INSTRUMENTS : status

    USERS ||--o{ INSTRUMENTS : checked_by
    USERS ||--o{ INSTRUMENTS : assigned_to

    SITES ||--o{ SITE_CONTACT_LINKS : selected_site_contacts
    CONTACTS ||--o{ SITE_CONTACT_LINKS : linked_to_sites
```

## Table Groups

### Site And GIS Tables

#### `sites`

Stores one row per site shown on the map.

Important columns:

- `id`: site identifier used by APIs and frontend URLs.
- `name`: site display name.
- `folder`: data/import folder name for the site.
- `state`, `zone`, `reactor_type`, `operator`, `status`: site metadata.
- `installed_capacity_mw`, `units`: capacity/unit metadata.
- `latitude`, `longitude`: marker coordinates used by Leaflet.

Used by:

- `GET /api/sites`
- `GET /api/sites/:id`
- Site detail URL: `npp_sites/site.html?id=<site_id>`

#### `layer_catalog`

Master table for available GIS layer types.

Examples:

- `road`
- `railway_track`
- `river_line`
- `water_bodies`
- `hospital`
- `sector`

Important columns:

- `layer_key`: stable key used by frontend/backend.
- `display_name`: human-readable layer name.
- `category`: group shown in the layer control.
- `geometry_type`: expected geometry type such as point, line, or polygon.

#### `site_layers`

Links sites to the GIS layers enabled for that site.

Relationship:

- One `sites` row can have many `site_layers`.
- One `layer_catalog` row can be used by many sites.

Important columns:

- `site_id`: references `sites(id)`.
- `layer_key`: references `layer_catalog(layer_key)`.
- `file_name`: source GeoJSON file used by the import script.
- `is_enabled`: controls whether the layer appears in the site detail page.

#### `geo_features`

Stores imported GeoJSON features as PostGIS geometries.

Relationship:

- Each feature belongs to one site.
- Each feature belongs to one layer type.

Important columns:

- `properties`: original GeoJSON feature properties.
- `geom`: PostGIS geometry in SRID `4326`.

Indexes:

- `geo_features_site_layer_idx` for site/layer filtering.
- `geo_features_geom_idx` GIST index for spatial operations.

Used by:

- `GET /api/sites/:id/layers/:layerKey`

## Instrument Tables

### `erc_locations`

Links instrument locations/units to a site.

Relationship:

- One site can have many ERC locations.
- One ERC location can have many instruments.

Important columns:

- `erc_id`: ERC/location identifier.
- `site_id`: references `sites(id)`.
- `erc_state`, `location`, `unit`: location metadata.
- `coordinator`, `phone_number_o`, `phone_number_h`, `mobile_number`: ERC contact fields.

Used by:

- `GET /api/sites/:id/erc-locations`
- `POST /api/sites/:id/erc-locations`

### `instruments`

Main instrument inventory table.

Relationship:

- Each instrument must belong to one ERC location.
- Through `erc_locations.site_id`, each instrument is connected to a site.

Important columns:

- `inst_id`: instrument identifier.
- `erc_id`: references `erc_locations(erc_id)`.
- `manufacturer_id`: references `manufacturers(manufacturer_id)`.
- `category_id`: references `instrument_categories(instrument_category_id)`.
- `status_id`: references `instrument_status(status_id)`.
- `checked_by_user_id`: references `users(id)`.
- `assigned_to_user_id`: references `users(id)`.
- `inst_sno`, `inst_model`: instrument identity fields.
- `checked_on`, `calibrated_on`: date fields.
- `efficiency`, `resolution`, `calib_factor`, `sensitivity`: instrument technical values.

Used by:

- `GET /api/sites/:id/instruments`
- `POST /api/sites/:id/instruments`
- `PUT /api/instruments/:id`

### `manufacturers`

Stores manufacturer/supplier metadata for instruments.

Relationship:

- One manufacturer can be linked to many instruments.

### `instrument_categories`

Stores reusable instrument type/category metadata.

Relationship:

- One category can be linked to many instruments.

### `instrument_status`

Stores fixed instrument status values.

Starter values:

- `1`: Active
- `2`: Inactive
- `3`: Calibration Due
- `4`: Under Repair
- `5`: Retired

## Contact Tables

### `contacts`

Stores contact records from the contact PDF.

This table supports the contact categories:

- `DAE-RERC Coordinator`
- `DAE-RERC Alternate Coordinator`
- `DAE-RERC Unit Head Details`
- `Other Contact Details`

Important columns:

- `contact_category`: category/group for display.
- `dae_unit`: DAE unit value from source records.
- `std_code`: STD code from source records.
- `unit`: unit/head detail field.
- `name`, `designation`: person metadata.
- `office_tel_fax`: office telephone/fax.
- `head_tel_fax`: unit/head telephone/fax.
- `residence_mobile`: residence/mobile field.
- `applies_to_all_sites`: if `true`, the contact appears for every site.

Used by:

- `GET /api/sites/:id/contacts`
- `POST /api/sites/:id/contacts`
- `PUT /api/contacts/:id`

### `site_contact_links`

Optional many-to-many link table between contacts and sites.

Use this only when a contact should appear for selected sites, not all sites.

Rules:

- If `contacts.applies_to_all_sites = true`, the contact appears for every site.
- If `contacts.applies_to_all_sites = false`, the contact appears only for sites linked in `site_contact_links`.

## User Table

### `users`

Stores login/user metadata and optional employee details.

Important columns:

- `email`: unique login/email value.
- `password_hash`: stored password hash.
- `role`: app role.
- `emp_no`: optional unique employee number.
- `designation`, `section`, `division`, `location`, `extension`: employee metadata.

Instrument usage:

- `instruments.checked_by_user_id` references `users(id)`.
- `instruments.assigned_to_user_id` references `users(id)`.

## How The Site Detail Page Works

For a site detail page such as:

```text
npp_sites/site.html?id=1
```

the frontend loads:

1. `GET /api/sites/:id`
   - Loads site metadata.

2. `GET /api/sites/:id/layers`
   - Loads enabled layer list for that site.

3. `GET /api/sites/:id/layers/:layerKey`
   - Loads GeoJSON features for each selected layer.

4. `GET /api/sites/:id/contacts`
   - Loads global contacts plus contacts linked to that site.

5. `GET /api/sites/:id/erc-locations`
   - Loads ERC locations for that site.

6. `GET /api/sites/:id/instruments`
   - Loads instruments connected to the site through ERC locations.

7. `GET /api/instrument-lookups`
   - Loads dropdown values for statuses, manufacturers, categories, ERC locations, and users.

## Main Data Paths

### GIS Layer Path

```text
sites
  -> site_layers
  -> layer_catalog
  -> geo_features
```

Meaning:

- A site has enabled layers.
- Each enabled layer has a layer definition.
- Actual map geometry is read from `geo_features`.

### Instrument Path

```text
sites
  -> erc_locations
  -> instruments
  -> manufacturers
  -> instrument_categories
  -> instrument_status
```

Meaning:

- A site has one or more ERC locations.
- Instruments are stored under ERC locations.
- Instrument metadata is normalized into manufacturer, category, and status tables.

### Contact Path

Global contacts:

```text
contacts.applies_to_all_sites = true
```

Site-specific contacts:

```text
sites
  -> site_contact_links
  -> contacts
```

Meaning:

- Most PDF contacts can be global.
- If needed later, selected contacts can be attached to selected sites only.
