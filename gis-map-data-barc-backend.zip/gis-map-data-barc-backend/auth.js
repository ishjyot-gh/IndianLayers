window.NppAuth = (function () {
  const tokenKey = "nppSites.authToken";
  const userKey = "nppSites.authUser";
  let loginModal;
  let pendingUrl = null;

  function getToken() {
    return localStorage.getItem(tokenKey);
  }

  function getUser() {
    try {
      return JSON.parse(localStorage.getItem(userKey));
    } catch (error) {
      return null;
    }
  }

  function saveSession(token, user) {
    localStorage.setItem(tokenKey, token);
    localStorage.setItem(userKey, JSON.stringify(user));
    renderToolbar();
  }

  function clearSession() {
    localStorage.removeItem(tokenKey);
    localStorage.removeItem(userKey);
    renderToolbar();
  }

  function ensureLoginModal() {
    if (loginModal) {
      return loginModal;
    }

    loginModal = document.createElement("div");
    loginModal.className = "auth-modal";
    loginModal.hidden = true;
    loginModal.innerHTML = `
      <div class="auth-panel" role="dialog" aria-modal="true" aria-labelledby="authTitle">
        <h1 id="authTitle">Login required</h1>
        <p>Sign in to open protected site details and records.</p>
        <div class="auth-tabs">
          <button type="button" data-auth-mode="login" class="is-active">Login</button>
          <button type="button" data-auth-mode="signup">Signup</button>
        </div>
        <form id="loginForm" class="auth-form">
          <label>Email <input name="email" type="email" value="admin@example.local" autocomplete="username" required></label>
          <label>Password <input name="password" type="password" value="Admin@12345" autocomplete="current-password" required></label>
          <div id="loginMessage" class="auth-message"></div>
          <button type="submit">Login</button>
          <button type="button" class="secondary-button" data-close-login>Back to map</button>
        </form>
        <form id="signupForm" class="auth-form" hidden>
          <label>Name <input name="name" type="text" autocomplete="name" required></label>
          <label>Email <input name="email" type="email" autocomplete="username" required></label>
          <label>Password <input name="password" type="password" autocomplete="new-password" required></label>
          <label>Employee No. <input name="emp_no" type="number"></label>
          <label>Designation <input name="designation" type="text"></label>
          <label>Section <input name="section" type="text"></label>
          <label>Division <input name="division" type="text"></label>
          <label>Location <input name="location" type="text"></label>
          <div id="signupMessage" class="auth-message"></div>
          <button type="submit">Create account</button>
          <button type="button" class="secondary-button" data-close-login>Back to map</button>
        </form>
      </div>
    `;

    document.body.appendChild(loginModal);
    loginModal.querySelectorAll("[data-close-login]").forEach(button => {
      button.addEventListener("click", hideLogin);
    });
    loginModal.querySelectorAll("[data-auth-mode]").forEach(button => {
      button.addEventListener("click", () => setAuthMode(button.dataset.authMode));
    });
    loginModal.querySelector("#loginForm").addEventListener("submit", login);
    loginModal.querySelector("#signupForm").addEventListener("submit", signup);
    return loginModal;
  }

  function setAuthMode(mode) {
    const modal = ensureLoginModal();
    const isSignup = mode === "signup";

    modal.querySelector("#loginForm").hidden = isSignup;
    modal.querySelector("#signupForm").hidden = !isSignup;
    modal.querySelectorAll("[data-auth-mode]").forEach(button => {
      button.classList.toggle("is-active", button.dataset.authMode === mode);
    });
  }

  function showLogin(nextUrl) {
    pendingUrl = nextUrl || pendingUrl;
    const modal = ensureLoginModal();
    modal.hidden = false;
    modal.querySelector("input[name='email']").focus();
  }

  function hideLogin() {
    ensureLoginModal().hidden = true;
  }

  async function login(event) {
    event.preventDefault();

    const form = event.currentTarget;
    const message = form.querySelector("#loginMessage");
    const submitButton = form.querySelector("button[type='submit']");
    const payload = Object.fromEntries(new FormData(form).entries());

    message.textContent = "";
    submitButton.disabled = true;

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(data.error || "Login failed");
      }

      saveSession(data.token, data.user);
      hideLogin();

      if (pendingUrl) {
        window.location.href = pendingUrl;
      }
    } catch (error) {
      message.textContent = error.message;
    } finally {
      submitButton.disabled = false;
    }
  }

  async function signup(event) {
    event.preventDefault();

    const form = event.currentTarget;
    const message = form.querySelector("#signupMessage");
    const submitButton = form.querySelector("button[type='submit']");
    const payload = Object.fromEntries(new FormData(form).entries());

    message.textContent = "";
    submitButton.disabled = true;

    try {
      const response = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(data.error || "Signup failed");
      }

      saveSession(data.token, data.user);
      hideLogin();

      if (pendingUrl) {
        window.location.href = pendingUrl;
      }
    } catch (error) {
      message.textContent = error.message;
    } finally {
      submitButton.disabled = false;
    }
  }

  function logout() {
    fetch("/api/auth/logout", {
      method: "POST",
      headers: getToken() ? { Authorization: `Bearer ${getToken()}` } : {}
    }).catch(() => {});
    clearSession();

    if (window.location.pathname.includes("/npp_sites/site.html")) {
      window.location.href = "../index.html?login=1";
      return;
    }

    showLogin();
  }

  function handleUnauthorized() {
    clearSession();
    showLogin(window.location.pathname.includes("/npp_sites/site.html") ? window.location.href : pendingUrl);
  }

  function openProtectedSite(url) {
    if (getToken()) {
      window.location.href = url;
      return;
    }

    showLogin(url);
  }

  function renderToolbar() {
    let toolbar = document.getElementById("userToolbar");

    if (!toolbar) {
      toolbar = document.createElement("div");
      toolbar.id = "userToolbar";
      toolbar.className = "user-toolbar";
      document.body.appendChild(toolbar);
    }

    const user = getUser();
    toolbar.replaceChildren();

    if (user) {
      const name = document.createElement("span");
      name.textContent = user.name || user.email;

      const logoutButton = document.createElement("button");
      logoutButton.type = "button";
      logoutButton.textContent = "Logout";
      logoutButton.addEventListener("click", logout);

      toolbar.append(name, logoutButton);
      return;
    }

    const loginButton = document.createElement("button");
    loginButton.type = "button";
    loginButton.textContent = "Login";
    loginButton.addEventListener("click", () => showLogin());
    toolbar.append(loginButton);
  }

  document.addEventListener("DOMContentLoaded", () => {
    renderToolbar();

    if (new URLSearchParams(window.location.search).get("login") === "1" && !getToken()) {
      showLogin();
    }
  });

  return {
    clearSession,
    getToken,
    getUser,
    handleUnauthorized,
    openProtectedSite,
    showLogin
  };
})();
