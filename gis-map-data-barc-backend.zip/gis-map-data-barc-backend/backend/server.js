const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const pool = require("./db");
const config = require("./config");

const app = express();

app.use(express.json());

// serve frontend from project root
app.use(express.static(path.join(__dirname, "..")));

function authRequired(req, res, next) {
  const header = req.headers.authorization;

  if (!header) {
    return res.status(401).json({ error: "Login required" });
  }

  const token = header.replace("Bearer ", "");

  try {
    req.user = jwt.verify(token, config.jwtSecret);
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

// signup
app.post("/api/auth/signup", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: "All fields required" });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO users (name, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, name, email, role`,
      [name, email, passwordHash]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Signup failed" });
  }
});

// login
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const result = await pool.query(
      "SELECT * FROM users WHERE email = $1",
      [email]
    );

    const user = result.rows[0];

    if (!user) {
      return res.status(401).json({ error: "Invalid login" });
    }

    const ok = await bcrypt.compare(password, user.password_hash);

    if (!ok) {
      return res.status(401).json({ error: "Invalid login" });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      config.jwtSecret,
      { expiresIn: "8h" }
    );

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});

// public site markers
app.get("/api/sites", async (req, res) => {
  const result = await pool.query(`
    SELECT
      id,
      name,
      folder,
      state,
      zone,
      reactor_type,
      installed_capacity_mw,
      units,
      operator,
      status,
      description,
      latitude AS lat,
      longitude AS lng
    FROM sites
    ORDER BY id
  `);

  res.json(result.rows);
});

// protected site detail
app.get("/api/sites/:id", async (req, res) => {
  const result = await pool.query(`
    SELECT
      id,
      name,
      folder,
      state,
      zone,
      reactor_type,
      installed_capacity_mw,
      units,
      operator,
      status,
      description,
      latitude AS lat,
      longitude AS lng
    FROM sites
    WHERE id = $1
  `, [req.params.id]);

  if (!result.rows.length) {
    return res.status(404).json({ error: "Site not found" });
  }

  res.json(result.rows[0]);
});

// protected layer list
app.get("/api/sites/:id/layers", async (req, res) => {
  const result = await pool.query(`
    SELECT
      lc.layer_key AS key,
      lc.display_name AS name,
      lc.category,
      lc.geometry_type
    FROM site_layers sl
    JOIN layer_catalog lc ON lc.layer_key = sl.layer_key
    WHERE sl.site_id = $1 AND sl.is_enabled = TRUE
    ORDER BY lc.category, lc.display_name
  `, [req.params.id]);

  res.json(result.rows);
});

// protected GeoJSON layer
app.get("/api/sites/:id/layers/:layerKey", async (req, res) => {
  const { id, layerKey } = req.params;

  const result = await pool.query(`
    SELECT jsonb_build_object(
      'type', 'FeatureCollection',
      'features', COALESCE(jsonb_agg(
        jsonb_build_object(
          'type', 'Feature',
          'properties', properties,
          'geometry', ST_AsGeoJSON(geom)::jsonb
        )
      ), '[]'::jsonb)
    ) AS geojson
    FROM geo_features
    WHERE site_id = $1 AND layer_key = $2
  `, [id, layerKey]);

  res.json(result.rows[0].geojson);
});

app.listen(config.port, () => {
  console.log(`Server running at http://localhost:${config.port}`);
});