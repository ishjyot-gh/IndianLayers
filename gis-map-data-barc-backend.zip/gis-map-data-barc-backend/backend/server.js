const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const pool = require("./db");
const config = require("./config");

const app = express();

app.use(express.json());

// serve frontend from project root
app.use(express.static(path.join(__dirname, "..")));

function emptyToNull(value) {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  return value;
}

function intOrNull(value) {
  const cleanedValue = emptyToNull(value);

  if (cleanedValue === null) {
    return null;
  }

  const parsedValue = Number(cleanedValue);

  if (!Number.isInteger(parsedValue)) {
    return null;
  }

  return parsedValue;
}

async function getNextIntegerId(tableName, columnName) {
  const result = await pool.query(`SELECT COALESCE(MAX(${columnName}), 0) + 1 AS next_id FROM ${tableName}`);
  return result.rows[0].next_id;
}

async function linkContactToSite(siteId, contactId) {
  await pool.query(`
    INSERT INTO site_contact_links (site_id, contact_id)
    VALUES ($1, $2)
    ON CONFLICT (site_id, contact_id) DO NOTHING
  `, [siteId, contactId]);
}

function publicUser(row) {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
    emp_no: row.emp_no,
    designation: row.designation,
    section: row.section,
    division: row.division,
    location: row.location
  };
}

function createToken(user) {
  return jwt.sign(
    {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    },
    config.jwtSecret,
    { expiresIn: "8h" }
  );
}

async function ensureDemoAdminUser() {
  await pool.query(`
    INSERT INTO users (
      name,
      email,
      password_hash,
      role,
      emp_no,
      designation,
      section,
      division,
      location
    ) VALUES (
      'Demo Admin',
      'admin@example.local',
      '$2b$10$/tDy7pj5FAdxaZ2mROs4ie0gLjcugwEU1IlGLGwVh0Db9HF37.3EO',
      'admin',
      10001,
      'Demo Administrator',
      'Emergency Preparedness',
      'BARC',
      'Mumbai'
    )
    ON CONFLICT (email) DO NOTHING
  `);
}

function requireAuth(req, res, next) {
  const authHeader = req.get("Authorization") || "";
  const [scheme, token] = authHeader.split(" ");

  if (scheme !== "Bearer" || !token) {
    return res.status(401).json({ error: "Login required" });
  }

  try {
    req.user = jwt.verify(token, config.jwtSecret);
    next();
  } catch (error) {
    return res.status(401).json({ error: "Invalid or expired login" });
  }
}

function requireRole(roles) {
  return function roleMiddleware(req, res, next) {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Insufficient permissions" });
    }

    next();
  };
}

async function getOrCreateManufacturerId(body) {
  const existingId = intOrNull(body.manufacturer_id);

  if (existingId) {
    return existingId;
  }

  if (!body.manufacturer_name) {
    return null;
  }

  const manufacturerId = await getNextIntegerId("manufacturers", "manufacturer_id");
  const result = await pool.query(`
    INSERT INTO manufacturers (
      manufacturer_id,
      manufacturer_name,
      address,
      phone_number,
      fax_number,
      email,
      supplier_name_and_address
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7)
    RETURNING manufacturer_id
  `, [
    manufacturerId,
    body.manufacturer_name,
    emptyToNull(body.manufacturer_address),
    emptyToNull(body.manufacturer_phone_number),
    emptyToNull(body.manufacturer_fax_number),
    emptyToNull(body.manufacturer_email),
    emptyToNull(body.supplier_name_and_address)
  ]);

  return result.rows[0].manufacturer_id;
}

async function getOrCreateCategoryId(body) {
  const existingId = intOrNull(body.category_id);

  if (existingId) {
    return existingId;
  }

  if (!body.monitor_type) {
    return null;
  }

  const categoryId = await getNextIntegerId("instrument_categories", "instrument_category_id");
  const result = await pool.query(`
    INSERT INTO instrument_categories (
      instrument_category_id,
      monitor_type,
      ranges,
      efficiency,
      resolution,
      calib_factor,
      sensitivity,
      remarks
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    RETURNING instrument_category_id
  `, [
    categoryId,
    body.monitor_type,
    emptyToNull(body.category_ranges),
    intOrNull(body.category_efficiency),
    emptyToNull(body.category_resolution),
    emptyToNull(body.category_calib_factor),
    emptyToNull(body.category_sensitivity),
    emptyToNull(body.category_remarks)
  ]);

  return result.rows[0].instrument_category_id;
}

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    await ensureDemoAdminUser();

    const result = await pool.query(
      `SELECT id, name, email, password_hash, role, emp_no, designation, section, division, location
       FROM users
       WHERE lower(email) = lower($1)`,
      [email]
    );

    if (!result.rows.length) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const user = result.rows[0];
    const passwordMatches = await bcrypt.compare(password, user.password_hash);

    if (!passwordMatches) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const safeUser = publicUser(user);
    res.json({
      token: createToken(safeUser),
      user: safeUser
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/signup", async (req, res, next) => {
  try {
    const {
      name,
      email,
      password,
      emp_no,
      designation,
      section,
      division,
      location
    } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const result = await pool.query(`
      INSERT INTO users (
        name,
        email,
        password_hash,
        role,
        emp_no,
        designation,
        section,
        division,
        location
      )
      VALUES ($1, lower($2), $3, 'viewer', $4, $5, $6, $7, $8)
      RETURNING id, name, email, role, emp_no, designation, section, division, location
    `, [
      name || email,
      email,
      passwordHash,
      intOrNull(emp_no),
      emptyToNull(designation),
      emptyToNull(section),
      emptyToNull(division),
      emptyToNull(location)
    ]);

    const safeUser = publicUser(result.rows[0]);
    res.status(201).json({
      token: createToken(safeUser),
      user: safeUser
    });
  } catch (error) {
    if (error.code === "23505") {
      return res.status(400).json({ error: "Email or employee number already exists" });
    }

    next(error);
  }
});

app.get("/api/auth/me", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, name, email, role, emp_no, designation, section, division, location
       FROM users
       WHERE id = $1`,
      [req.user.id]
    );

    if (!result.rows.length) {
      return res.status(401).json({ error: "Invalid or expired login" });
    }

    res.json({ user: publicUser(result.rows[0]) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/logout", (req, res) => {
  res.json({ status: "ok" });
});

// public site markers
app.get("/api/sites", async (req, res) => {
  const result = await pool.query(`
    SELECT
      id,
      name,
      folder,
      state,
      zone,
      reactor_type,
      installed_capacity_mw,
      units,
      operator,
      status,
      description,
      latitude AS lat,
      longitude AS lng
    FROM sites
    ORDER BY id
  `);

  res.json(result.rows);
});

// protected site detail
app.get("/api/sites/:id", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT
      id,
      name,
      folder,
      state,
      zone,
      reactor_type,
      installed_capacity_mw,
      units,
      operator,
      status,
      description,
      latitude AS lat,
      longitude AS lng
    FROM sites
    WHERE id = $1
  `, [req.params.id]);

  if (!result.rows.length) {
    return res.status(404).json({ error: "Site not found" });
  }

  res.json(result.rows[0]);
});

// protected layer list
app.get("/api/sites/:id/layers", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT
      lc.layer_key AS key,
      lc.display_name AS name,
      lc.category,
      lc.geometry_type
    FROM site_layers sl
    JOIN layer_catalog lc ON lc.layer_key = sl.layer_key
    WHERE sl.site_id = $1 AND sl.is_enabled = TRUE
    ORDER BY lc.category, lc.display_name
  `, [req.params.id]);

  res.json(result.rows);
});

// protected GeoJSON layer
app.get("/api/sites/:id/layers/:layerKey", requireAuth, async (req, res) => {
  const { id, layerKey } = req.params;

  const result = await pool.query(`
    SELECT jsonb_build_object(
      'type', 'FeatureCollection',
      'features', COALESCE(jsonb_agg(
        jsonb_build_object(
          'type', 'Feature',
          'properties', properties,
          'geometry', ST_AsGeoJSON(geom)::jsonb
        )
      ), '[]'::jsonb)
    ) AS geojson
    FROM geo_features
    WHERE site_id = $1 AND layer_key = $2
  `, [id, layerKey]);

  res.json(result.rows[0].geojson);
});

app.get("/api/sites/:id/contacts", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT DISTINCT c.*
    FROM contacts c
    LEFT JOIN site_contact_links scl ON scl.contact_id = c.id
    WHERE c.applies_to_all_sites = TRUE
       OR scl.site_id = $1
    ORDER BY c.contact_category, c.dae_unit, c.name, c.id
  `, [req.params.id]);

  res.json(result.rows);
});

app.post("/api/sites/:id/contacts", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const siteId = req.params.id;
  const {
    contact_category,
    dae_unit,
    std_code,
    unit,
    name,
    designation,
    office_tel_fax,
    head_tel_fax,
    residence_mobile,
    email,
    address,
    remarks,
    applies_to_all_sites
  } = req.body;

  const result = await pool.query(`
    INSERT INTO contacts (
      contact_category,
      dae_unit,
      std_code,
      unit,
      name,
      designation,
      office_tel_fax,
      head_tel_fax,
      residence_mobile,
      email,
      address,
      remarks,
      applies_to_all_sites
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
    RETURNING *
  `, [
    contact_category || "Other Contact Details",
    emptyToNull(dae_unit),
    emptyToNull(std_code),
    emptyToNull(unit),
    emptyToNull(name),
    emptyToNull(designation),
    emptyToNull(office_tel_fax),
    emptyToNull(head_tel_fax),
    emptyToNull(residence_mobile),
    emptyToNull(email),
    emptyToNull(address),
    emptyToNull(remarks),
    applies_to_all_sites !== false
  ]);

  if (result.rows[0].applies_to_all_sites === false) {
    await linkContactToSite(siteId, result.rows[0].id);
  }

  res.status(201).json(result.rows[0]);
});

app.put("/api/contacts/:id", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const {
    contact_category,
    dae_unit,
    std_code,
    unit,
    name,
    designation,
    office_tel_fax,
    head_tel_fax,
    residence_mobile,
    email,
    address,
    remarks,
    applies_to_all_sites
  } = req.body;

  const result = await pool.query(`
    UPDATE contacts
    SET
      contact_category = $1,
      dae_unit = $2,
      std_code = $3,
      unit = $4,
      name = $5,
      designation = $6,
      office_tel_fax = $7,
      head_tel_fax = $8,
      residence_mobile = $9,
      email = $10,
      address = $11,
      remarks = $12,
      applies_to_all_sites = $13,
      updated_at = NOW()
    WHERE id = $14
    RETURNING *
  `, [
    contact_category || "Other Contact Details",
    emptyToNull(dae_unit),
    emptyToNull(std_code),
    emptyToNull(unit),
    emptyToNull(name),
    emptyToNull(designation),
    emptyToNull(office_tel_fax),
    emptyToNull(head_tel_fax),
    emptyToNull(residence_mobile),
    emptyToNull(email),
    emptyToNull(address),
    emptyToNull(remarks),
    applies_to_all_sites !== false,
    req.params.id
  ]);

  if (!result.rows.length) {
    return res.status(404).json({ error: "Contact not found" });
  }

  res.json(result.rows[0]);
});

app.get("/api/sites/:id/erc-locations", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT *
    FROM erc_locations
    WHERE site_id = $1
    ORDER BY location, unit, erc_id
  `, [req.params.id]);

  res.json(result.rows);
});

app.post("/api/sites/:id/erc-locations", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const ercId = await getNextIntegerId("erc_locations", "erc_id");
  const result = await pool.query(`
    INSERT INTO erc_locations (
      erc_id,
      site_id,
      erc_state,
      location,
      unit,
      coordinator,
      phone_number_o,
      phone_number_h,
      mobile_number
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    RETURNING *
  `, [
    ercId,
    req.params.id,
    emptyToNull(req.body.erc_state),
    emptyToNull(req.body.location),
    emptyToNull(req.body.unit),
    emptyToNull(req.body.coordinator),
    emptyToNull(req.body.phone_number_o),
    emptyToNull(req.body.phone_number_h),
    emptyToNull(req.body.mobile_number)
  ]);

  res.status(201).json(result.rows[0]);
});

app.get("/api/instrument-lookups", requireAuth, async (req, res) => {
  const [ercLocations, manufacturers, categories, statuses, users] = await Promise.all([
    pool.query("SELECT * FROM erc_locations ORDER BY site_id, location, unit, erc_id"),
    pool.query("SELECT * FROM manufacturers ORDER BY manufacturer_name, manufacturer_id"),
    pool.query("SELECT * FROM instrument_categories ORDER BY monitor_type, instrument_category_id"),
    pool.query("SELECT * FROM instrument_status ORDER BY status_id"),
    pool.query("SELECT id, name, email, emp_no, first_name, last_name FROM users ORDER BY name, id")
  ]);

  res.json({
    erc_locations: ercLocations.rows,
    manufacturers: manufacturers.rows,
    categories: categories.rows,
    statuses: statuses.rows,
    users: users.rows
  });
});

app.get("/api/sites/:id/instruments", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT
      i.*,
      e.location AS erc_location,
      e.unit AS erc_unit,
      e.erc_state,
      m.manufacturer_name,
      c.monitor_type,
      s.status_des,
      checked_user.name AS checked_by_name,
      assigned_user.name AS assigned_to_name
    FROM instruments i
    JOIN erc_locations e ON e.erc_id = i.erc_id
    LEFT JOIN manufacturers m ON m.manufacturer_id = i.manufacturer_id
    LEFT JOIN instrument_categories c ON c.instrument_category_id = i.category_id
    LEFT JOIN instrument_status s ON s.status_id = i.status_id
    LEFT JOIN users checked_user ON checked_user.id = i.checked_by_user_id
    LEFT JOIN users assigned_user ON assigned_user.id = i.assigned_to_user_id
    WHERE e.site_id = $1
    ORDER BY i.inst_sno, i.inst_id
  `, [req.params.id]);

  res.json(result.rows);
});

app.post("/api/sites/:id/instruments", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const siteErcResult = await pool.query(
    "SELECT erc_id FROM erc_locations WHERE erc_id = $1 AND site_id = $2",
    [req.body.erc_id, req.params.id]
  );

  if (!siteErcResult.rows.length) {
    return res.status(400).json({ error: "Select an ERC location for this site before saving the instrument." });
  }

  const manufacturerId = await getOrCreateManufacturerId(req.body);
  const categoryId = await getOrCreateCategoryId(req.body);

  const result = await pool.query(`
    INSERT INTO instruments (
      erc_id,
      manufacturer_id,
      category_id,
      status_id,
      checked_by_user_id,
      assigned_to_user_id,
      checked_on,
      calibrated_on,
      inst_sno,
      inst_model,
      curr_location,
      bcode_verification,
      efficiency,
      resolution,
      calib_factor,
      sensitivity,
      datasheet,
      remark
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
    RETURNING *
  `, [
    intOrNull(req.body.erc_id),
    manufacturerId,
    categoryId,
    intOrNull(req.body.status_id),
    intOrNull(req.body.checked_by_user_id),
    intOrNull(req.body.assigned_to_user_id),
    emptyToNull(req.body.checked_on),
    emptyToNull(req.body.calibrated_on),
    emptyToNull(req.body.inst_sno),
    emptyToNull(req.body.inst_model),
    emptyToNull(req.body.curr_location),
    emptyToNull(req.body.bcode_verification),
    intOrNull(req.body.efficiency),
    emptyToNull(req.body.resolution),
    emptyToNull(req.body.calib_factor),
    emptyToNull(req.body.sensitivity),
    emptyToNull(req.body.datasheet),
    emptyToNull(req.body.remark)
  ]);

  res.status(201).json(result.rows[0]);
});

app.put("/api/instruments/:id", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const manufacturerId = await getOrCreateManufacturerId(req.body);
  const categoryId = await getOrCreateCategoryId(req.body);

  const result = await pool.query(`
    UPDATE instruments
    SET
      erc_id = $1,
      manufacturer_id = $2,
      category_id = $3,
      status_id = $4,
      checked_by_user_id = $5,
      assigned_to_user_id = $6,
      checked_on = $7,
      calibrated_on = $8,
      inst_sno = $9,
      inst_model = $10,
      curr_location = $11,
      bcode_verification = $12,
      efficiency = $13,
      resolution = $14,
      calib_factor = $15,
      sensitivity = $16,
      datasheet = $17,
      remark = $18,
      updated_at = NOW()
    WHERE inst_id = $19
    RETURNING *
  `, [
    intOrNull(req.body.erc_id),
    manufacturerId,
    categoryId,
    intOrNull(req.body.status_id),
    intOrNull(req.body.checked_by_user_id),
    intOrNull(req.body.assigned_to_user_id),
    emptyToNull(req.body.checked_on),
    emptyToNull(req.body.calibrated_on),
    emptyToNull(req.body.inst_sno),
    emptyToNull(req.body.inst_model),
    emptyToNull(req.body.curr_location),
    emptyToNull(req.body.bcode_verification),
    intOrNull(req.body.efficiency),
    emptyToNull(req.body.resolution),
    emptyToNull(req.body.calib_factor),
    emptyToNull(req.body.sensitivity),
    emptyToNull(req.body.datasheet),
    emptyToNull(req.body.remark),
    req.params.id
  ]);

  if (!result.rows.length) {
    return res.status(404).json({ error: "Instrument not found" });
  }

  res.json(result.rows[0]);
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || "Internal server error" });
});

app.listen(config.port, () => {
  console.log(`Server running at http://localhost:${config.port}`);
});
