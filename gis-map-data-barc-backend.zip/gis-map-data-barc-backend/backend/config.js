module.exports = {
  port: 5000,
  jwtSecret: "change_this_secret",
  db: {
    host: "localhost",
    port: 5432,
    database: "gis_db",
    user: "postgres",
    password: "fw0r"
  }
};