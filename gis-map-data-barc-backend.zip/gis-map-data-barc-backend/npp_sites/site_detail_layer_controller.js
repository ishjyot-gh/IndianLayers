window.NppSiteDetailLayerController = (function () {
  const { layerZoomRules } = window.NppSiteDetailConfig;
  const { formatLabel } = window.NppSiteDetailFormat;
  const {
    appendLayerPanelItem,
    renderLayerPanel
  } = window.NppSiteDetailPanel;
  const {
    createGenericPopup,
    createSectorPopup,
    getFeatureLabel,
    getSectorDetails,
    isSectorLayerKey
  } = window.NppSiteDetailPopups;
  const {
    getPointStyleForSiteLayer,
    getStyleForSiteLayer
  } = window.NppSiteDetailStyles;

  function create(map) {
    const loadedSiteLayers = [];
    const labelController = window.NppSiteDetailLabels.create(map, loadedSiteLayers);
    let selectedSectorLayer = null;
    let selectedSectorStyle = null;

    function resolveSiteLayers(site, layerSource) {
      if (Array.isArray(layerSource)) {
        return layerSource.map(normalizeApiLayerConfig).filter(Boolean);
      }

      const layersCatalog = layerSource || {};
      const layerSetNames = site.layer_sets || [];
      const catalogLayers = layersCatalog.layers || [];
      const resolvedLayers = [];

      function addLayer(layerEntry) {
        const key = typeof layerEntry === "string" ? layerEntry : layerEntry.key;

        if (!key || resolvedLayers.some(layer => layer.key === key)) {
          return;
        }

        const normalizedKey = normalizeLayerKey(key);
        const configuredLayer = catalogLayers.find(layer => layer.key === normalizedKey || layer.key === key);
        const fallbackLayer = {
          key: normalizedKey,
          name: formatLabel(normalizedKey),
          category: "Site Layers",
          geometry: "geojson"
        };

        if (typeof layerEntry === "string") {
          resolvedLayers.push(configuredLayer || fallbackLayer);
          return;
        }

        resolvedLayers.push({
          ...(configuredLayer || fallbackLayer),
          ...layerEntry,
          key: normalizedKey,
          name: layerEntry.name || configuredLayer?.name || fallbackLayer.name,
          category: layerEntry.category || configuredLayer?.category || fallbackLayer.category
        });
      }

      layerSetNames.forEach(setName => {
        const setLayers = layersCatalog.layer_sets?.[setName] || [];

        setLayers.forEach(addLayer);
      });

      getDirectLayerEntries(site).forEach(addLayer);

      return resolvedLayers.map(normalizeApiLayerConfig).filter(Boolean);
    }

    function normalizeApiLayerConfig(layerConfig) {
      if (!layerConfig || !layerConfig.key) return null;

      const key = normalizeLayerKey(layerConfig.key);

      return {
        ...layerConfig,
        key,
        name: layerConfig.name || layerConfig.display_name || formatLabel(key),
        category: layerConfig.category || "Site Layers",
        geometry: layerConfig.geometry || layerConfig.geometry_type || "geojson"
      };
    }

    function getDirectLayerEntries(site) {
      const directLayers = site.layers || site.site_layers || [];

      if (Array.isArray(directLayers)) {
        return directLayers;
      }

      if (!directLayers || typeof directLayers !== "object") {
        return [];
      }

      return Object.entries(directLayers).map(([key, file]) => ({
        key: normalizeLayerKey(key),
        file
      }));
    }

    function normalizeLayerKey(key) {
      const aliases = {
        settlepoints: "settle_point",
        settlement_points: "settle_point",
        settlement_point: "settle_point"
      };

      return aliases[key] || key;
    }

    async function loadSiteLayers(site, layerConfigs) {
      if (!site.id || !layerConfigs.length) return;

      const groupedLayers = {};
      const allSiteLayers = [];

      for (const layerConfig of layerConfigs) {
        const url = `/api/sites/${site.id}/layers/${encodeURIComponent(layerConfig.key)}`;

        try {
          const data = await fetchJson(url);

          const layer = L.geoJSON(data, {
            style: getStyleForSiteLayer(layerConfig.key),
            pointToLayer(feature, latlng) {
              return L.circleMarker(latlng, getPointStyleForSiteLayer(layerConfig.key));
            },
            onEachFeature(feature, leafletLayer) {
              bindFeatureInteractions(feature, leafletLayer, layerConfig);
            }
          });

          if (isSectorLayerKey(layerConfig.key)) {
            placeSectorLabels(site, layer);
          }

          const rule = layerZoomRules[layerConfig.key] || {
            defaultVisible: true,
            minZoom: 0,
            labelZoom: 13
          };

          const loadedItem = {
            key: layerConfig.key,
            name: layerConfig.name,
            category: layerConfig.category,
            layer,
            rule,
            userEnabled: rule.defaultVisible
          };

          loadedSiteLayers.push(loadedItem);

          if (rule.defaultVisible && map.getZoom() >= (rule.minZoom ?? 0)) {
            layer.addTo(map);
          }

          allSiteLayers.push(layer);

          if (!groupedLayers[layerConfig.category]) {
            groupedLayers[layerConfig.category] = [];
          }

          groupedLayers[layerConfig.category].push({
            name: layerConfig.name,
            layer,
            loadedItem
          });
        } catch (error) {
          console.warn(`Skipping ${layerConfig.name}:`, error);
        }
      }

      renderLayerPanel(groupedLayers, labelController.scheduleLayerDetailUpdate);
      fitSiteLayers(allSiteLayers);
    }

    function bindFeatureInteractions(feature, leafletLayer, layerConfig) {
      const properties = feature.properties || {};

      leafletLayer.bindPopup(createGenericPopup(properties, layerConfig.name));

      if (isSectorLayerKey(layerConfig.key)) {
        bindSectorInteraction(leafletLayer, layerConfig, properties);
      } else {
        leafletLayer.on("click", event => {
          focusFeature(leafletLayer, layerConfig, event);
        });
      }

      const labelText = getFeatureLabel(properties, layerConfig.key);

      if (labelText) {
        leafletLayer.nppLabelText = labelText;
        leafletLayer.bindTooltip(labelText, {
          permanent: false,
          direction: isSectorLayerKey(layerConfig.key) ? "center" : "right",
          offset: isSectorLayerKey(layerConfig.key) ? [0, 0] : [8, 0],
          className: isSectorLayerKey(layerConfig.key) ? "map-label map-label-sector" : "map-label"
        });

        leafletLayer.on("mouseover", () => {
          labelController.showFeatureLabel(leafletLayer);
        });

        leafletLayer.on("mouseout", () => {
          labelController.scheduleLayerDetailUpdate();
        });
      }
    }

    function fitSiteLayers(siteLayers) {
      if (siteLayers.length === 0) return;

      const bounds = L.featureGroup(siteLayers).getBounds();

      if (bounds.isValid()) {
        map.fitBounds(bounds, {
          padding: [30, 30],
          maxZoom: 12
        });
      }
    }

    function addGeneratedSectors(site) {
      if (loadedSiteLayers.some(item => (item.key === "sector" || item.key === "sectors") && hasFeatureLayers(item.layer))) {
        return;
      }

      const radiusKm = site.sector_radius_km || 16;
      const sectorCount = site.sector_count || 16;
      const angleStep = 360 / sectorCount;

      const sectorLayerGroup = L.layerGroup();

      for (let i = 0; i < sectorCount; i++) {
        const startAngle = i * angleStep;
        const endAngle = startAngle + angleStep;
        const sectorName = String.fromCharCode(65 + i);

        const polygonCoords = createSectorPolygon(site.lat, site.lng, radiusKm, startAngle, endAngle);

        const sector = L.polygon(polygonCoords, {
          className: "layer-sector",
          pane: "siteAreas",
          bubblingMouseEvents: false
        });
        sector.nppLabelText = sectorName;
        sector.nppLabelCentered = true;
        sector.nppLabelLatLng = destinationPoint(site.lat, site.lng, radiusKm * 0.62, getAngleCenter(startAngle, endAngle));
        sector.nppSectorDetails = {
          sectorName,
          radiusKm,
          startAngle,
          endAngle
        };

        sector.bindPopup(createSectorPopup({}, sector.nppSectorDetails));

        sector.bindTooltip(sector.nppLabelText, {
          permanent: false,
          direction: "center",
          offset: [0, 0],
          className: "map-label map-label-sector"
        });

        sector.on("click", event => {
          focusSector(sector, sector.nppSectorDetails, event);
        });

        sector.addTo(sectorLayerGroup);
        sector.bringToBack();
      }

      const rule = layerZoomRules.generated_sectors;
      const loadedItem = {
        key: "generated_sectors",
        name: "Generated Sectors",
        category: "Emergency",
        layer: sectorLayerGroup,
        rule,
        userEnabled: true
      };

      loadedSiteLayers.push(loadedItem);
      sectorLayerGroup.addTo(map);
      sectorLayerGroup.eachLayer(layer => {
        if (typeof layer.bringToBack === "function") {
          layer.bringToBack();
        }
      });

      appendLayerPanelItem("Emergency", {
        name: loadedItem.name,
        layer: sectorLayerGroup,
        loadedItem
      }, labelController.scheduleLayerDetailUpdate);
    }

    function hasFeatureLayers(layer) {
      if (!layer || typeof layer.getLayers !== "function") {
        return false;
      }

      return layer.getLayers().length > 0;
    }

    function createSectorPolygon(centerLat, centerLng, radiusKm, startAngle, endAngle) {
      const points = [[centerLat, centerLng]];
      const steps = 12;

      for (let i = 0; i <= steps; i++) {
        const angle = startAngle + ((endAngle - startAngle) * i) / steps;
        points.push(destinationPoint(centerLat, centerLng, radiusKm, angle));
      }

      points.push([centerLat, centerLng]);
      return points;
    }

    function destinationPoint(lat, lng, distanceKm, bearingDeg) {
      const earthRadiusKm = 6371;
      const bearing = bearingDeg * Math.PI / 180;

      const lat1 = lat * Math.PI / 180;
      const lng1 = lng * Math.PI / 180;
      const angularDistance = distanceKm / earthRadiusKm;

      const lat2 = Math.asin(
        Math.sin(lat1) * Math.cos(angularDistance) +
        Math.cos(lat1) * Math.sin(angularDistance) * Math.cos(bearing)
      );

      const lng2 = lng1 + Math.atan2(
        Math.sin(bearing) * Math.sin(angularDistance) * Math.cos(lat1),
        Math.cos(angularDistance) - Math.sin(lat1) * Math.sin(lat2)
      );

      return [
        lat2 * 180 / Math.PI,
        lng2 * 180 / Math.PI
      ];
    }

    function bindSectorInteraction(leafletLayer, layerConfig, properties) {
      const details = getSectorDetails(properties, layerConfig);
      leafletLayer.nppSectorDetails = details;
      leafletLayer.nppLabelText = details.sectorName;
      leafletLayer.nppLabelCentered = true;
      leafletLayer.bindPopup(createSectorPopup(properties, details));
      leafletLayer.on("click", event => {
        focusSector(leafletLayer, details, event);
      });
    }

    function placeSectorLabels(site, sectorLayer) {
      const outerSectorByName = new Map();

      sectorLayer.eachLayer(featureLayer => {
        const details = featureLayer.nppSectorDetails;

        if (!details?.sectorName) {
          featureLayer.nppSuppressLabel = true;
          return;
        }

        const radiusMeters = getSectorRadiusMeters(details);
        const currentOuter = outerSectorByName.get(details.sectorName);

        if (!currentOuter || radiusMeters > currentOuter.radiusMeters) {
          outerSectorByName.set(details.sectorName, {
            featureLayer,
            radiusMeters
          });
        }
      });

      sectorLayer.eachLayer(featureLayer => {
        const details = featureLayer.nppSectorDetails;
        const outerSector = details?.sectorName ? outerSectorByName.get(details.sectorName) : null;

        if (!outerSector || outerSector.featureLayer !== featureLayer) {
          featureLayer.nppSuppressLabel = true;
          return;
        }

        featureLayer.nppSuppressLabel = false;
        featureLayer.nppLabelCentered = true;

        if (Number.isFinite(outerSector.radiusMeters) && outerSector.radiusMeters > 0) {
          const labelDistanceKm = (outerSector.radiusMeters * 0.72) / 1000;
          featureLayer.nppLabelLatLng = destinationPoint(
            site.lat,
            site.lng,
            labelDistanceKm,
            getAngleCenter(details.startAngle, details.endAngle)
          );
        }
      });
    }

    function getSectorRadiusMeters(details) {
      const radiusMeters = Number(details.radiusMeters);

      if (Number.isFinite(radiusMeters) && radiusMeters > 0) {
        return radiusMeters;
      }

      const radiusKm = Number(details.radiusKm);

      if (Number.isFinite(radiusKm) && radiusKm > 0) {
        return radiusKm * 1000;
      }

      return 0;
    }

    function getAngleCenter(startAngle, endAngle) {
      const start = Number(startAngle);
      const end = Number(endAngle);

      if (!Number.isFinite(start) || !Number.isFinite(end)) {
        return 0;
      }

      return start + ((end - start) / 2);
    }

    function focusSector(sectorLayer, details, event) {
      stopLeafletEvent(event);
      highlightSector(sectorLayer);
      sectorLayer.openPopup();

      if (typeof sectorLayer.getBounds === "function") {
        const bounds = sectorLayer.getBounds();

        if (bounds.isValid()) {
          const nextZoom = Math.max(map.getZoom(), Math.min(map.getZoom() + 1, 14));

          map.flyToBounds(bounds.pad(0.16), {
            padding: [42, 42],
            maxZoom: nextZoom,
            duration: 0.35
          });
        }
      }

      labelController.showFeatureLabel(sectorLayer);
    }

    function highlightSector(sectorLayer) {
      if (selectedSectorLayer && selectedSectorLayer !== sectorLayer && typeof selectedSectorLayer.setStyle === "function") {
        selectedSectorLayer.setStyle(selectedSectorStyle || {
          weight: 2,
          fillOpacity: 0.12
        });
      }

      selectedSectorLayer = sectorLayer;
      selectedSectorStyle = {
        weight: sectorLayer.options?.weight || 2,
        fillOpacity: sectorLayer.options?.fillOpacity ?? 0.12
      };

      if (typeof sectorLayer.setStyle === "function") {
        sectorLayer.setStyle({
          weight: 4,
          fillOpacity: 0.2
        });
      }

      if (typeof sectorLayer.bringToFront === "function") {
        sectorLayer.bringToFront();
      }
    }

    function focusFeature(featureLayer, layerConfig, event) {
      stopLeafletEvent(event);

      const focusLatLng = getFeatureFocusLatLng(featureLayer, event);

      if (focusLatLng) {
        const labelZoom = layerZoomRules[layerConfig.key]?.labelZoom || map.getZoom();
        const targetZoom = Math.min(
          getMaxFocusZoom(layerConfig.key),
          Math.max(map.getZoom() + 1, labelZoom)
        );

        map.flyTo(focusLatLng, targetZoom, {
          duration: 0.3
        });
      }

      featureLayer.openPopup(focusLatLng || event?.latlng);
      labelController.showFeatureLabel(featureLayer);
    }

    function getFeatureFocusLatLng(featureLayer, event) {
      if (event?.latlng) {
        return event.latlng;
      }

      if (typeof featureLayer.getLatLng === "function") {
        return featureLayer.getLatLng();
      }

      if (typeof featureLayer.getBounds === "function") {
        const bounds = featureLayer.getBounds();

        if (bounds.isValid()) {
          return bounds.getCenter();
        }
      }

      return null;
    }

    function getMaxFocusZoom(layerKey) {
      if (["hospital", "landmark", "railway_station", "settlement_point", "settle_point"].includes(layerKey)) {
        return 17;
      }

      if (["road", "railway_track", "river_line", "canal_line"].includes(layerKey)) {
        return 16;
      }

      return 15;
    }

    function stopLeafletEvent(event) {
      if (event?.originalEvent) {
        L.DomEvent.stop(event.originalEvent);
      }
    }

    async function fetchJson(url) {
      return window.NppApi.json(url);
    }

    function sendBackgroundLayersToBack() {
      loadedSiteLayers.forEach(item => {
        if (!["sector", "sectors", "generated_sectors"].includes(item.key)) {
          return;
        }

        item.layer.eachLayer(featureLayer => {
          if (typeof featureLayer.bringToBack === "function") {
            featureLayer.bringToBack();
          }
        });
      });
    }

    return {
      addGeneratedSectors,
      loadSiteLayers,
      resolveSiteLayers,
      scheduleLayerDetailUpdate: labelController.scheduleLayerDetailUpdate,
      sendBackgroundLayersToBack
    };
  }

  return {
    create
  };
})();
