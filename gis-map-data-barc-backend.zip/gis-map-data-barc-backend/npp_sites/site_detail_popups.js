window.NppSiteDetailPopups = (function () {
  const sectorNameFields = [
    "SECTOR_NAM",
    "SECTOR_NAME",
    "Sector_Name",
    "sector_name",
    "Sector_Nam",
    "sector_nam",
    "SECTOR",
    "Sector",
    "sector",
    "NAME",
    "Name",
    "name"
  ];

  function createGenericPopup(properties, layerName) {
    const nameFields = [
      "NAME",
      "Name",
      "name",
      "SETTLEMENT_NAME",
      "Settlement_Name",
      "settlement_name",
      "SETTLE_NAME",
      "SETTLE_NAM",
      "SETTLE_POI",
      "NAME_3",
      "NAME_2",
      "NAME_1",
      "DISTRICT",
      "District",
      "STATE",
      "State",
      "VILLAGE",
      "Village",
      "TOWN",
      "Town",
      "HOSP_NAME",
      "Hospital",
      "LANDMARK",
      "Landmark",
      "STATION",
      "Station",
      "SETTLEMENT",
      "SETTLE_POI",
      "TYPE",
      "Type",
      "type",
      "SECTOR",
      "SECTOR_NAM",
      "Sector_Nam",
      "sector_nam"
    ];

    const title = getPopupTitle(properties, layerName);
    const renderedFields = new Set(nameFields);
    const detailRows = [];

    addPopupDetail(detailRows, "Type", getFirstMeaningfulPropertyValue(properties, ["TYPE", "Type", "type", "ENGTYPE_3", "ENGTYPE_2"]));
    addPopupDetail(detailRows, "Village", getFirstMeaningfulPropertyValue(properties, ["VILLAGE", "Village", "village"]));
    addPopupDetail(detailRows, "Town", getFirstMeaningfulPropertyValue(properties, ["TOWN", "Town", "town"]));
    addPopupDetail(detailRows, "District", getFirstMeaningfulPropertyValue(properties, ["DISTRICT", "District", "district", "NAME_3"]));
    addPopupDetail(detailRows, "State", getFirstMeaningfulPropertyValue(properties, ["STATE", "State", "state", "NAME_1"]));

    Object.entries(properties).forEach(([field, value]) => {
      if (detailRows.length >= 2 || renderedFields.has(field) || !shouldRenderPropertyValue(value)) {
        return;
      }

      addPopupDetail(detailRows, formatPopupField(field), value);
    });

    let html = `<b>${title}</b><br><span class="popup-layer-name">${layerName}</span><br>`;

    detailRows.slice(0, 2).forEach(([label, value]) => {
      html += `${label}: ${value}<br>`;
    });

    return html;
  }

  function addPopupDetail(rows, label, value) {
    if (!shouldRenderPropertyValue(value)) return;
    if (rows.some(([, existingValue]) => String(existingValue).trim() === String(value).trim())) return;

    rows.push([label, value]);
  }

  function getPopupTitle(properties, layerName) {
    const layerKey = normalizeLayerName(layerName);
    const preferredTitle = getFirstMeaningfulPropertyValue(properties, [
      "NAME",
      "Name",
      "name",
      "SETTLEMENT_NAME",
      "Settlement_Name",
      "settlement_name",
      "SETTLE_NAME",
      "SETTLE_NAM",
      "sector_nam",
      "SECTOR_NAM"
    ]);

    if (preferredTitle) {
      return preferredTitle;
    }

    if (layerKey.includes("settlement")) {
      const settlementId = getFirstPropertyValue(properties, ["SETTLEMENT", "settlement", "SETTLE_POI", "settle_poi"]);
      return settlementId ? `Settlement ${settlementId}` : "Settlement";
    }

    return layerName || "Map feature";
  }

  function normalizeLayerName(layerName) {
    return String(layerName || "").toLowerCase().replace(/[^a-z0-9]+/g, "_");
  }

  function formatPopupField(field) {
    return String(field)
      .replace(/_/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/\b\w/g, character => character.toUpperCase());
  }

  function shouldRenderPropertyValue(value) {
    if (value === undefined || value === null || value === "") return false;
    return isMeaningfulLabel(String(value));
  }

  function getFirstMeaningfulPropertyValue(properties, fields) {
    for (const field of fields) {
      const value = properties[field];

      if (shouldRenderPropertyValue(value)) {
        return String(value).trim();
      }
    }

    return "";
  }

  function getSectorDetails(properties, layerConfig) {
    const rawName = getFirstPropertyValue(properties, sectorNameFields);

    return {
      sectorName: normalizeSectorName(rawName) || layerConfig.name || "Unknown",
      radiusKm: getFirstPropertyValue(properties, ["RADIUS_KM", "radius_km"]),
      radiusMeters: getFirstPropertyValue(properties, ["RADIUS", "Radius", "radius"]),
      startAngle: getFirstPropertyValue(properties, ["START_ANGLE", "start_angle", "angle_star", "ANGLE_STAR", "BEARING_FROM"]),
      endAngle: getFirstPropertyValue(properties, ["END_ANGLE", "end_angle", "angle_end", "ANGLE_END", "BEARING_TO"])
    };
  }

  function getFirstPropertyValue(properties, fields) {
    for (const field of fields) {
      const value = properties[field];

      if (value !== undefined && value !== null && String(value).trim() !== "") {
        return String(value).trim();
      }
    }

    return "";
  }

  function normalizeSectorName(value) {
    const text = String(value || "").trim();

    if (!text) return "";

    const sectorMatch = text.match(/(?:sector\s*)?([A-Z])\b/i);

    if (sectorMatch) {
      return sectorMatch[1].toUpperCase();
    }

    return isMeaningfulLabel(text) ? text : "";
  }

  function createSectorPopup(properties, details) {
    const rows = [
      ["Sector", details.sectorName],
      ["Coverage radius", formatRadius(details)]
    ];

    const nearbyFields = [
      ["Name", getFirstPropertyValue(properties, ["NAME", "Name", "name"])],
      ["Village", getFirstPropertyValue(properties, ["VILLAGE", "Village", "village"])],
      ["Town", getFirstPropertyValue(properties, ["TOWN", "Town", "town"])],
      ["District", getFirstPropertyValue(properties, ["DISTRICT", "District", "district"])],
      ["State", getFirstPropertyValue(properties, ["STATE", "State", "state"])]
    ];

    let html = `<b>Sector ${details.sectorName}</b><br>`;

    [...rows, ...nearbyFields].filter(([, value]) => value).slice(0, 3).forEach(([label, value]) => {
      html += `${label}: ${value}<br>`;
    });

    return html;
  }

  function getFeatureLabel(properties, layerKey) {
    if (isSectorLayerKey(layerKey)) {
      const sectorName = normalizeSectorName(getFirstPropertyValue(properties, sectorNameFields));

      return sectorName || "";
    }

    if (["settlement", "settlements", "settlement_point", "settle_point"].includes(layerKey)) {
      const settlementName = getFirstMeaningfulPropertyValue(properties, [
        "NAME",
        "Name",
        "name",
        "SETTLEMENT_NAME",
        "Settlement_Name",
        "settlement_name",
        "SETTLE_NAME",
        "SETTLE_NAM"
      ]);
      const settlementId = getFirstPropertyValue(properties, ["SETTLEMENT", "settlement", "SETTLE_POI", "settle_poi"]);

      return settlementName || (settlementId ? `Settlement ${settlementId}` : "");
    }

    const labelFields = [
      "NAME",
      "Name",
      "name",
      "SETTLEMENT_NAME",
      "Settlement_Name",
      "settlement_name",
      "SETTLE_NAME",
      "SETTLE_NAM",
      "SETTLE_POI",
      "NAME_3",
      "NAME_2",
      "NAME_1",
      "DISTRICT",
      "District",
      "STATE",
      "State",
      "VILLAGE",
      "Village",
      "TOWN",
      "Town",
      "SETTLEMENT",
      "SETTLE_POI",
      "HOSP_NAME",
      "Hospital",
      "LANDMARK",
      "Landmark",
      "STATION",
      "Station"
    ];

    for (const field of labelFields) {
      if (properties[field] !== undefined && properties[field] !== null && properties[field] !== "") {
        const label = String(properties[field]).trim();

        if (isMeaningfulLabel(label)) {
          return label;
        }
      }
    }

    return "";
  }

  function isSectorLayerKey(key) {
    return ["sector", "sectors", "generated_sectors"].includes(key);
  }

  function formatRadius(details) {
    if (details.radiusKm) {
      return `${details.radiusKm} km`;
    }

    if (details.radiusMeters) {
      return `${details.radiusMeters} m`;
    }

    return "";
  }

  function isMeaningfulLabel(label) {
    const text = String(label || "").trim();

    if (text.length < 2) return false;
    if (/^(no\s*)?name$/i.test(text)) return false;
    if (/^(unknown|unnamed|null|na|n\/a|not available)$/i.test(text)) return false;
    if (!/[A-Za-z]/.test(text)) return false;
    if (/^[\d\s*#./\\-]+$/.test(text)) return false;

    const alphanumericChars = text.match(/[A-Za-z0-9]/g) || [];
    const letterChars = text.match(/[A-Za-z]/g) || [];

    return letterChars.length / Math.max(alphanumericChars.length, 1) >= 0.35;
  }

  return {
    createGenericPopup,
    createSectorPopup,
    getFeatureLabel,
    getFirstPropertyValue,
    getSectorDetails,
    isSectorLayerKey,
    normalizeSectorName
  };
})();
