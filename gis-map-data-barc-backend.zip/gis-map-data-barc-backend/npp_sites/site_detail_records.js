window.NppSiteDetailRecords = (function () {
  const state = {
    siteId: null,
    contacts: [],
    instruments: [],
    ercLocations: [],
    lookups: {
      manufacturers: [],
      categories: [],
      statuses: []
    }
  };

  async function requestJson(url, options) {
    return window.NppApi.json(url, options);
  }

  function formToObject(form) {
    const data = {};

    Array.from(new FormData(form).entries()).forEach(([key, value]) => {
      data[key] = value;
    });

    form.querySelectorAll("input[type='checkbox']").forEach(input => {
      data[input.name] = input.checked;
    });

    return data;
  }

  function showMessage(elementId, message, isError) {
    const element = document.getElementById(elementId);

    if (!element) return;

    element.textContent = message || "";
    element.classList.toggle("is-error", Boolean(isError));
  }

  function valueOrDash(value) {
    return value === undefined || value === null || value === "" ? "-" : value;
  }

  function toDateInputValue(value) {
    if (!value) return "";
    return String(value).slice(0, 10);
  }

  function setFormValues(form, values) {
    Array.from(form.elements).forEach(element => {
      if (!element.name) return;

      if (element.type === "checkbox") {
        element.checked = values[element.name] !== false;
      } else if (element.type === "date") {
        element.value = toDateInputValue(values[element.name]);
      } else {
        element.value = values[element.name] ?? "";
      }
    });
  }

  function resetAndShowForm(formId, titleId, title) {
    const form = document.getElementById(formId);

    closeRecordForms();
    form.reset();
    form.hidden = false;

    if (titleId) {
      document.getElementById(titleId).textContent = title;
    }
  }

  function closeRecordForms() {
    document.querySelectorAll(".record-form").forEach(form => {
      form.hidden = true;
    });
  }

  function populateSelect(select, rows, getValue, getLabel, placeholder) {
    select.replaceChildren();

    const emptyOption = document.createElement("option");
    emptyOption.value = "";
    emptyOption.textContent = placeholder;
    select.appendChild(emptyOption);

    rows.forEach(row => {
      const option = document.createElement("option");
      option.value = getValue(row);
      option.textContent = getLabel(row);
      select.appendChild(option);
    });
  }

  function populateInstrumentSelects() {
    const form = document.getElementById("instrumentForm");

    populateSelect(
      form.elements.erc_id,
      state.ercLocations,
      row => row.erc_id,
      row => [row.location, row.unit, `ERC ${row.erc_id}`].filter(Boolean).join(" - "),
      "Select ERC location"
    );

    populateSelect(
      form.elements.status_id,
      state.lookups.statuses,
      row => row.status_id,
      row => row.status_des,
      "No status"
    );

    populateSelect(
      form.elements.manufacturer_id,
      state.lookups.manufacturers,
      row => row.manufacturer_id,
      row => row.manufacturer_name || `Manufacturer ${row.manufacturer_id}`,
      "No manufacturer"
    );

    populateSelect(
      form.elements.category_id,
      state.lookups.categories,
      row => row.instrument_category_id,
      row => row.monitor_type || `Category ${row.instrument_category_id}`,
      "No category"
    );
  }

  function renderContacts() {
    const container = document.getElementById("contactsList");
    container.replaceChildren();

    if (!state.contacts.length) {
      const empty = document.createElement("p");
      empty.className = "empty-records";
      empty.textContent = "No contacts saved.";
      container.appendChild(empty);
      return;
    }

    const groupedContacts = state.contacts.reduce((groups, contact) => {
      const key = contact.contact_category || "Other Contact Details";
      groups[key] = groups[key] || [];
      groups[key].push(contact);
      return groups;
    }, {});

    Object.entries(groupedContacts).forEach(([category, contacts]) => {
      const group = document.createElement("div");
      group.className = "record-group";

      const title = document.createElement("h3");
      title.textContent = category;
      group.appendChild(title);

      contacts.forEach(contact => {
        const item = document.createElement("article");
        item.className = "record-item";

        const header = document.createElement("div");
        header.className = "record-item-header";

        const name = document.createElement("strong");
        name.textContent = valueOrDash(contact.name || contact.designation || contact.dae_unit);

        const editButton = document.createElement("button");
        editButton.type = "button";
        editButton.textContent = "Edit";
        editButton.addEventListener("click", () => editContact(contact));

        header.append(name, editButton);

        const meta = document.createElement("p");
        meta.textContent = [
          contact.dae_unit,
          contact.std_code && `STD ${contact.std_code}`,
          contact.designation
        ].filter(Boolean).join(" | ");

        const phone = document.createElement("p");
        phone.textContent = [
          contact.office_tel_fax && `Office ${contact.office_tel_fax}`,
          contact.head_tel_fax && `Head ${contact.head_tel_fax}`,
          contact.residence_mobile && `Res/Mob ${contact.residence_mobile}`
        ].filter(Boolean).join(" | ");

        item.append(header, meta, phone);
        group.appendChild(item);
      });

      container.appendChild(group);
    });
  }

  function renderInstruments() {
    const container = document.getElementById("instrumentsList");
    container.replaceChildren();

    if (!state.ercLocations.length) {
      const empty = document.createElement("p");
      empty.className = "empty-records";
      empty.textContent = "Add an ERC location before adding instruments.";
      container.appendChild(empty);
      return;
    }

    if (!state.instruments.length) {
      const empty = document.createElement("p");
      empty.className = "empty-records";
      empty.textContent = "No instruments saved.";
      container.appendChild(empty);
      return;
    }

    state.instruments.forEach(instrument => {
      const item = document.createElement("article");
      item.className = "record-item";

      const header = document.createElement("div");
      header.className = "record-item-header";

      const title = document.createElement("strong");
      title.textContent = [instrument.inst_sno, instrument.inst_model].filter(Boolean).join(" - ") || `Instrument ${instrument.inst_id}`;

      const editButton = document.createElement("button");
      editButton.type = "button";
      editButton.textContent = "Edit";
      editButton.addEventListener("click", () => editInstrument(instrument));

      header.append(title, editButton);

      const meta = document.createElement("p");
      meta.textContent = [
        instrument.status_des,
        instrument.manufacturer_name,
        instrument.monitor_type
      ].filter(Boolean).join(" | ");

      const location = document.createElement("p");
      location.textContent = [
        instrument.erc_location,
        instrument.erc_unit,
        instrument.curr_location
      ].filter(Boolean).join(" | ");

      item.append(header, meta, location);
      container.appendChild(item);
    });
  }

  function editContact(contact) {
    resetAndShowForm("contactForm", "contactFormTitle", "Edit Contact");
    setFormValues(document.getElementById("contactForm"), contact);
  }

  function editInstrument(instrument) {
    resetAndShowForm("instrumentForm", "instrumentFormTitle", "Edit Instrument");
    populateInstrumentSelects();
    setFormValues(document.getElementById("instrumentForm"), instrument);
  }

  async function loadRecords() {
    const [contacts, instruments, ercLocations, lookups] = await Promise.all([
      requestJson(`/api/sites/${state.siteId}/contacts`),
      requestJson(`/api/sites/${state.siteId}/instruments`),
      requestJson(`/api/sites/${state.siteId}/erc-locations`),
      requestJson("/api/instrument-lookups")
    ]);

    state.contacts = contacts;
    state.instruments = instruments;
    state.ercLocations = ercLocations;
    state.lookups = lookups;

    populateInstrumentSelects();
    renderContacts();
    renderInstruments();
  }

  function bindFormEvents() {
    document.querySelectorAll("[data-cancel-form]").forEach(button => {
      button.addEventListener("click", () => {
        document.getElementById(button.dataset.cancelForm).hidden = true;
      });
    });

    document.getElementById("addContactButton").addEventListener("click", () => {
      resetAndShowForm("contactForm", "contactFormTitle", "Add Contact");
      document.getElementById("contactForm").elements.applies_to_all_sites.checked = true;
    });

    document.getElementById("addErcButton").addEventListener("click", () => {
      resetAndShowForm("ercForm", null, "");
    });

    document.getElementById("addInstrumentButton").addEventListener("click", () => {
      if (!state.ercLocations.length) {
        resetAndShowForm("ercForm", null, "");
        showMessage("instrumentMessage", "Create an ERC location first, then add instruments.", false);
        return;
      }

      resetAndShowForm("instrumentForm", "instrumentFormTitle", "Add Instrument");
      populateInstrumentSelects();
    });

    document.getElementById("ercForm").addEventListener("submit", async event => {
      event.preventDefault();

      try {
        await requestJson(`/api/sites/${state.siteId}/erc-locations`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formToObject(event.currentTarget))
        });
        event.currentTarget.hidden = true;
        showMessage("instrumentMessage", "ERC location saved.", false);
        await loadRecords();
      } catch (error) {
        showMessage("instrumentMessage", error.message, true);
      }
    });

    document.getElementById("contactForm").addEventListener("submit", async event => {
      event.preventDefault();

      const data = formToObject(event.currentTarget);
      const id = data.id;
      const url = id ? `/api/contacts/${id}` : `/api/sites/${state.siteId}/contacts`;
      const method = id ? "PUT" : "POST";

      try {
        await requestJson(url, {
          method,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        });
        event.currentTarget.hidden = true;
        showMessage("contactMessage", "Contact saved.", false);
        await loadRecords();
      } catch (error) {
        showMessage("contactMessage", error.message, true);
      }
    });

    document.getElementById("instrumentForm").addEventListener("submit", async event => {
      event.preventDefault();

      const data = formToObject(event.currentTarget);
      const id = data.inst_id;
      const url = id ? `/api/instruments/${id}` : `/api/sites/${state.siteId}/instruments`;
      const method = id ? "PUT" : "POST";

      try {
        await requestJson(url, {
          method,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        });
        event.currentTarget.hidden = true;
        showMessage("instrumentMessage", "Instrument saved.", false);
        await loadRecords();
      } catch (error) {
        showMessage("instrumentMessage", error.message, true);
      }
    });
  }

  async function init(siteId) {
    state.siteId = siteId;
    bindFormEvents();
    await loadRecords();
  }

  return {
    init
  };
})();
