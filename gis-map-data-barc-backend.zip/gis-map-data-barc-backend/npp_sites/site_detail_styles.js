window.NppSiteDetailStyles = (function () {
  function getStyleForSiteLayer(key) {
    const classMap = {
      district_boundary: "layer-district-boundary",
      taluk_boundary: "layer-taluk-boundary",
      road: "layer-road",
      railway_track: "layer-railway-track",
      river_line: "layer-river-line",
      canal_line: "layer-canal-line",
      water_bodies: "layer-water-bodies",
      settlement: "layer-settlement",
      settlements: "layer-settlement",
      hospital: "layer-hospital",
      landmark: "layer-landmark",
      sector: "layer-sector",
      sectors: "layer-sector"
    };

    return {
      className: classMap[key] || "layer-default",
      pane: getPaneForSiteLayer(key),
      bubblingMouseEvents: false
    };
  }

  function getPointStyleForSiteLayer(key) {
    const classMap = {
      settlement_point: "marker-settlement-point",
      settle_point: "marker-settlement-point",
      railway_station: "marker-railway-station",
      hospital: "marker-hospital",
      landmark: "marker-landmark"
    };

    return {
      radius: 5,
      className: classMap[key] || "marker-default",
      pane: "sitePoints",
      bubblingMouseEvents: false
    };
  }

  function getPaneForSiteLayer(key) {
    const areaLayers = [
      "district_boundary",
      "taluk_boundary",
      "water_bodies",
      "settlement",
      "settlements",
      "sector",
      "sectors"
    ];
    const lineLayers = [
      "road",
      "railway_track",
      "river_line",
      "canal_line"
    ];

    if (areaLayers.includes(key)) return "siteAreas";
    if (lineLayers.includes(key)) return "siteLines";
    return "siteAreas";
  }

  return {
    getPointStyleForSiteLayer,
    getStyleForSiteLayer
  };
})();
