let siteMap;

const {
  createSiteLayerPanes
} = window.NppSiteDetailConfig;
const {
  getSiteIdFromUrl,
  renderSiteDetails
} = window.NppSiteDetailFormat;

async function fetchJson(url) {
  return window.NppApi.json(url);
}

async function fetchOptionalJson(url) {
  return window.NppApi.optionalJson(url);
}

function renderMissingSite() {
  document.getElementById("siteName").textContent = "Site not found";
  document.getElementById("siteDescription").textContent = "No matching site was found.";
}

function renderSiteHeader(site) {
  document.getElementById("siteName").textContent = site.name;
  document.getElementById("siteDescription").textContent = site.description || "";
  document.getElementById("siteStatus").textContent = site.status || "Operational";
}

async function initSitePage() {
  if (!window.NppAuth.getToken()) {
    window.NppAuth.showLogin(window.location.href);
    return;
  }

  const siteId = getSiteIdFromUrl();
  const [sites, currentSite, apiLayers] = await Promise.all([
    fetchJson("/api/sites"),
    fetchOptionalJson(`/api/sites/${siteId}`),
    fetchJson(`/api/sites/${siteId}/layers`)
  ]);

  if (!currentSite) {
    renderMissingSite();
    return;
  }

  renderSiteHeader(currentSite);
  renderSiteDetails(currentSite);
  await window.NppSiteDetailRecords.init(siteId);

  siteMap = L.map("siteMap").setView([currentSite.lat, currentSite.lng], 9);

  const overlays = {};
  const layerControl = L.control.layers(null, overlays, {
    collapsed: false,
    position: "bottomleft"
  }).addTo(siteMap);
  const visibleLayerNames = window.NppSitesCommon.getVisibleLayerNames();
  const markLayersReady = window.NppSitesCommon.bindLayerStatePersistence(siteMap, overlays);
  const siteLayerController = window.NppSiteDetailLayerController.create(siteMap);

  window.NppSitesCommon.createSiteMarkerPane(siteMap);
  createSiteLayerPanes(siteMap);
  window.NppSitesCommon.addTileLayer(siteMap);

  await window.NppSitesCommon.loadStandardLayers({
    map: siteMap,
    layerControl,
    overlays,
    visibleLayerNames,
    sites,
    dataRoot: "../data",
    selectedSiteId: currentSite.id,
    detailHrefForSite: site => `./site.html?id=${site.id}`
  });

  const resolvedLayers = siteLayerController.resolveSiteLayers(currentSite, apiLayers);

  await siteLayerController.loadSiteLayers(currentSite, resolvedLayers);

  siteLayerController.addGeneratedSectors(currentSite);

  siteLayerController.sendBackgroundLayersToBack();
  siteLayerController.scheduleLayerDetailUpdate();
  siteMap.on("zoomend", siteLayerController.scheduleLayerDetailUpdate);
  siteMap.on("moveend", siteLayerController.scheduleLayerDetailUpdate);
  markLayersReady();
}

initSitePage().catch(error => {
  console.error("Could not initialize site page:", error);
  document.getElementById("siteName").textContent = "Unable to load site";
  document.getElementById("siteDescription").textContent = "Check the browser console for details.";
});
