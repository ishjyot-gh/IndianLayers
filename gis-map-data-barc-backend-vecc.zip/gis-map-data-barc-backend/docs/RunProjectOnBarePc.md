# Check Docker
docker --version
docker compose version

# Install Docker On Ubuntu/Linux
sudo apt update
sudo apt install -y docker.io docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER

# Then log out and log in again, or reboot.

# Check Again
docker --version
docker compose version

# Run Packaged Project Zip
unzip gis-map-data-barc-backend-release.zip
cd gis-map-data-barc-backend-release
docker compose up --build

# Open:
http://localhost:5000/

# Demo login:
# email: admin@example.local
# password: Admin@12345

// If other dependencies there then :
# go to project folder
cd gis-map-data-barc-backend-release

# install root npm dependencies
npm install
npm start

# If express / pg are missing

cd backend
npm install express pg bcryptjs jsonwebtoken

# For psql already there

Option 1 (Recommended)

Ask the owner/admin to do one of these:

CREATE USER ishjyot_user WITH PASSWORD 'your_password';
CREATE DATABASE ishjyot_gis_db OWNER ishjyot_user;
\c ishjyot_gis_db
CREATE EXTENSION IF NOT EXISTS postgis;

Then from project folder:

// Only if backup_dump did not work (so schema w/o data for demo):
psql -U ishjyot_user -d ishjyot_gis_db -f db/init/001_schema.sql

npm install //skip

npm run start

And your .env must match:

DB_NAME=ishjyot_gis_db
DB_USER=ishjyot_user
DB_PASSWORD=your_password

# For data inside db
$env:PGPASSWORD="your_password"
pg_dump -U postgres -h localhost -p 5432 -d gis_db -Fc -f gis_db_backup.dump

This creates:
gis_db_backup.dump

$env:PGPASSWORD="your_password"
pg_restore -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db --no-owner --no-privileges gis_db_backup.dump

# Fix psql not recognized in powershell

$pgBin = "C:\Program Files\PostgreSQL\17\bin"
$env:Path += ";$pgBin"
psql --version

// If it works
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -notlike "*$pgBin*") {
[Environment]::SetEnvironmentVariable("Path", "$userPath;$pgBin", "User")
}

// In vscode
SELECT version();

// On an internet PC, download the PostgreSQL 17 x64 PostGIS bundle from:

// https://download.osgeo.org/postgis/windows/pg17/

// Download the file like:

// postgis-bundle-pg17x64-setup-*.exe

// Copy the .exe installer to the offline PC with USB.

// Run it as Administrator and point it to the same PostgreSQL install, e.g.: C:\Program Files\PostgreSQL\16

// Open PowerShell and verify:
psql -U postgres -h localhost

# If psql cmds don't work goto pg shell
Then inside the ishjyot_gis_db=> shell, run:
\i 'D:/BARC/gis-map-data-barc-backend/db/init/001_schema.sql'
Use forward slashes /, not backslashes. If your project is somewhere else, change the path.
To apply the VECC migration too:
\i 'D:/BARC/gis-map-data-barc-backend/db/migrations/20260714_vecc_dae_unit.sql'
Option B: Run pg_restore without PATH
Open PowerShell or CMD and use the full path:
& "C:\Program Files\PostgreSQL\17\bin\pg_restore.exe" -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db --no-owner --no-privileges "D:\BARC\gis-map-data-barc-backend\gis_db_backup.dump"
If using CMD instead of PowerShell:
"C:\Program Files\PostgreSQL\17\bin\pg_restore.exe" -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db --no-owner --no-privileges "D:\BARC\gis-map-data-barc-backend\gis_db_backup.dump"
Option C: Run psql without PATH
PowerShell:
& "C:\Program Files\PostgreSQL\17\bin\psql.exe" -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db -f "D:\BARC\gis-map-data-barc-backend\db\init\001_schema.sql"
CMD:
"C:\Program Files\PostgreSQL\17\bin\psql.exe" -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db -f "D:\BARC\gis-map-data-barc-backend\db\init\001_schema.sql"
Use pg_restore only for .dump made with pg_dump -Fc. Use psql / \i for .sql files.