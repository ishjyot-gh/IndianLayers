# GIS Map Project Flow, Backend DB, and Events

This document reflects the current app after the RERC contacts/instruments cleanup.

## 1. Stack And Entry Points

```text
Frontend: plain HTML/CSS/JavaScript + Leaflet
Backend: Express
Database: PostgreSQL + PostGIS
Auth: JWT stored in sessionStorage
```

Main files:

```text
index.html                         Main map page
auth.js                            Login/signup/logout
api.js                             Shared authenticated fetch wrapper
styles.css                         Shared UI styling

npp_sites/map.js                   Main map startup
npp_sites/map_common.js            Shared Leaflet overlays and site markers
npp_sites/site.html                Protected site detail page
npp_sites/site_detail.js           Site detail startup, layer decisions, resizable panel
npp_sites/site_detail_records.js   Contacts and instruments UI
npp_sites/site_detail_layer_controller.js
                                   Site-specific GIS layer loading for non-RERC sites

backend/server.js                  Express routes and DB writes
backend/db.js                      PostgreSQL pool
backend/config.js                  .env config

db/init/001_schema.sql             Fresh DB schema and seed records
db/migrations/20260712_rerc_contacts_common.sql
                                   Existing DB migration for contacts/instrument cleanup
```

## 2. Startup Flow

```text
1. npm start runs node backend/server.js.
2. backend/config.js loads .env.
3. backend/db.js creates the pg Pool.
4. Express serves static frontend files from the project root.
5. Browser opens http://localhost:5000/.
6. index.html loads auth.js, api.js, Leaflet, map_common.js, and map.js.
```

`npm start` does not create tables. Use `db/init/001_schema.sql`, migrations, or a restored dump first.

## 3. Main Map Flow

The main map loads:

```http
GET /api/sites
```

Returned marker fields include:

```text
id, name, folder, site_kind, state, zone, reactor_type,
installed_capacity_mw, units, operator, status, detail_status,
description, lat, lng
```

Marker grouping:

```text
site_kind != 'rerc' -> NPP Sites overlay
site_kind = 'rerc'  -> DAE-RERC Units overlay
```

Clicking a marker opens the protected detail page:

```text
npp_sites/site.html?id=<site_id>
```

## 4. Auth Flow

Login route:

```http
POST /api/auth/login
```

Signup route:

```http
POST /api/auth/signup
```

Auth behavior:

```text
JWT is stored in sessionStorage.
Closing the tab/window clears the login session.
api.js attaches Authorization: Bearer <jwt>.
401 responses clear auth and reopen login.
```

Roles:

```text
viewer -> read protected pages and records
editor -> add/edit/delete contacts and instruments
admin  -> same record permissions as editor
```

## 5. Site Detail Flow

`npp_sites/site_detail.js` does this:

```text
1. Require a session token.
2. Read site ID from URL.
3. Fetch all sites for marker context.
4. Fetch current site details.
5. Detect RERC with site.site_kind === 'rerc'.
6. Hide Site Layers for RERC pages.
7. Add wider default sidebar class for RERC pages.
8. Enable sidebar drag resize on desktop.
9. Render site data.
10. Initialize contacts/instruments records module.
11. Initialize Leaflet map.
12. Load public India/state/district/site marker overlays.
13. For non-RERC pages only, load protected site-specific PostGIS layers.
```

RERC pages:

```text
Show site data, contacts, and instruments.
Hide the Site Layers section.
Do not render protected site-specific GIS layers.
Use a wider default side panel because fewer layer controls are shown.
```

The side panel can be resized from its inner edge. The width is saved in:

```text
localStorage: nppSites.siteDetailSidebarWidth
```

## 6. Contacts

Tables:

```text
contacts
site_contact_links
```

Current contact rule:

```text
contacts.applies_to_all_sites = TRUE
  -> common contact visible on all site detail pages

contacts.applies_to_all_sites = FALSE + site_contact_links row
  -> site-specific contact visible only for linked site_id
```

RERC contacts are now site-linked when DAE unit, city, or STD code is provided. They are not forced to common.

Contact fetch route:

```http
GET /api/sites/:id/contacts
```

Contact fetch behavior:

```sql
SELECT DISTINCT c.*
FROM contacts c
LEFT JOIN site_contact_links scl ON scl.contact_id = c.id
WHERE c.applies_to_all_sites = TRUE
   OR scl.site_id = $1
ORDER BY c.contact_category, c.dae_unit, c.name, c.id;
```

Contact write routes:

```http
POST   /api/sites/:id/contacts
PUT    /api/contacts/:id
DELETE /api/contacts/:id
```

Contact form fields:

```text
category
name
dae_unit
city (stored as contacts.unit)
std_code
telephone 1, telephone 2
mobile 1, mobile 2
email 1, email 2, email 3
fax_no
remarks
```

Removed from the visible form:

```text
address
designation
show as common contact checkbox
```

Required fields:

```text
category
name
email 1
telephone 1
```

If the category is one of the DAE-RERC categories, at least one of DAE unit, city, or STD code is required.

RERC lookup route:

```http
GET /api/rerc-units
```

The frontend uses this for DAE unit/city/STD datalist options. If two of the three fields identify one RERC tuple, the third field is auto-filled and locked.

Duplicate protection:

```text
POST /api/sites/:id/contacts checks category + name + email + dae_unit + city + std_code.
If an identical contact already exists for that site/common scope, the existing row is returned.
```

## 7. Instruments And Site Linking

Tables:

```text
erc_locations
instruments
manufacturers
instrument_categories
instrument_status
users
```

Important rule:

```text
erc_locations is now an internal instrument-location master.
The UI does not expose Add ERC / Edit ERC / Delete ERC.
Only actual RERC site-backed rows are seeded for RERC sites 101-123.
Demo ERC rows 1001-1003 and their demo instruments were removed.
```

Current instrument relationship:

```text
sites.id
  -> erc_locations.site_id
  -> instruments.erc_id

sites.id
  -> instruments.site_id
```

`instruments.site_id` is the direct owning-site link. `instruments.erc_id` remains for compatibility and for the existing instrument-location relationship.

Instrument routes:

```http
GET    /api/sites/:id/erc-locations
GET    /api/sites/:id/instruments
POST   /api/sites/:id/instruments
PUT    /api/instruments/:id
DELETE /api/instruments/:id
GET    /api/instrument-lookups
```

The ERC-location CRUD routes still exist in the backend for compatibility, but the site detail UI no longer exposes them.

RERC location behavior:

```text
GET /api/sites/:id/erc-locations ensures a RERC site has one site-backed instrument-location row.
For site 101, the row is Alwaye - IREL - STD 0484.
For site 102, the row is Bengaluru - AMD - STD 080.
... up to site 123.
```

Instrument save behavior:

```text
POST /api/sites/:id/instruments:
1. Ensures the RERC instrument-location row exists when site_kind = 'rerc'.
2. Verifies selected erc_id belongs to the same site_id.
3. Creates manufacturer/category rows when new names are provided.
4. Inserts instruments with both site_id and erc_id.
```

Instrument edit behavior:

```text
PUT /api/instruments/:id updates erc_id and refreshes instruments.site_id from erc_locations.site_id.
```

Instrument fetch behavior:

```text
GET /api/sites/:id/instruments returns rows where:
COALESCE(instruments.site_id, erc_locations.site_id) = :id
```

This keeps old rows working while making new rows directly site-linked.

## 8. GIS Layers

Public overlays are local GeoJSON files:

```text
data/india.geojson
data/states.geojson
data/districts.geojson
```

Protected site-specific layers use:

```text
layer_catalog
site_layers
geo_features
```

Layer routes:

```http
GET /api/sites/:id/layers
GET /api/sites/:id/layers/:layerKey
```

Relationships:

```text
sites.id -> site_layers.site_id
layer_catalog.layer_key -> site_layers.layer_key
geo_features.site_id + geo_features.layer_key -> rendered features
```

RERC pages skip protected site-specific layers.

## 9. Core Tables

### users

Stores login users and instrument user lookups.

Key columns:

```text
id PK, name, email UNIQUE, password_hash, role, emp_no,
designation, section, division, location, created_at
```

### sites

Stores NPP and DAE-RERC site master rows.

Key columns:

```text
id PK, name, folder, site_kind, state, zone, reactor_type,
installed_capacity_mw, units, operator, status, detail_status,
description, latitude, longitude
```

### erc_locations

Internal instrument-location master.

Key columns:

```text
erc_id PK
site_id FK -> sites.id
erc_state
location
unit
std_code
```

### instruments

Stores instruments.

Key columns:

```text
inst_id PK
site_id FK -> sites.id
erc_id FK -> erc_locations.erc_id
manufacturer_id FK
category_id FK
status_id FK
checked_by_user_id FK
assigned_to_user_id FK
inst_sno
inst_model
curr_location
calibration/technical fields
```

### contacts

Stores common and site-specific contacts.

Key columns:

```text
id PK
contact_category
dae_unit
std_code
unit
name
office_tel_fax
head_tel_fax
residence_mobile
mobile_2
email
email_2
email_3
fax_no
remarks
applies_to_all_sites
```

### site_contact_links

Links site-specific contacts.

```text
site_id FK -> sites.id
contact_id FK -> contacts.id
PRIMARY KEY (site_id, contact_id)
```

### layer_catalog, site_layers, geo_features

PostGIS layer catalog, site enablement table, and geometry store.

## 10. Ordered UI Events

### Open Site Detail

```text
1. User opens site.html?id=<site_id>.
2. Auth token is checked.
3. Site details are loaded.
4. Sidebar is resized/restored and RERC width class is applied.
5. Records module loads contacts, instruments, instrument locations, and lookups.
6. Leaflet map loads.
7. Non-RERC pages load protected PostGIS layers.
```

### Add Contact

```text
1. User clicks Add Contact.
2. Contact form opens.
3. User enters category/name/contact fields.
4. DAE unit/city/STD fields auto-fill the third value when two values identify one RERC tuple.
5. Frontend POSTs /api/sites/:id/contacts.
6. Backend validates required fields and duplicate scope.
7. Backend inserts common or site-linked contact.
8. Frontend closes form and shows Contact saved!
```

### Add Instrument

```text
1. User clicks Add Instrument.
2. Frontend opens instrument form if the site has a linked instrument location.
3. RERC pages normally have exactly one location, which is auto-selected.
4. Frontend POSTs /api/sites/:id/instruments.
5. Backend verifies erc_id belongs to the same site.
6. Backend inserts instruments.site_id and instruments.erc_id.
7. Frontend closes form and reloads instruments.
```

### Resize Detail Panel

```text
1. User drags the sidebar edge.
2. site_detail.js updates .site-sidebar width.
3. Leaflet invalidateSize() runs during/after resize.
4. Width is saved in localStorage.
```

## 11. Current Seed State

RERC sites:

```text
101-123 are DAE-RERC Unit site rows.
```

RERC instrument locations:

```text
23 rows in erc_locations, one for each RERC site 101-123.
```

Removed demo data:

```text
erc_locations 1001, 1002, 1003
demo instruments tied to those erc_ids
```

Contact seed placeholders:

```text
DAE-RERC Coordinator
DAE-RERC Alternate Coordinator
DAE-RERC Unit Head Details
```

These are site-linked when unit/city/STD identifies a RERC site.
