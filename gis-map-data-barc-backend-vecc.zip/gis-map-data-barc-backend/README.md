# GIS Map Backend

Express + PostGIS backend for the GIS map frontend.

## Run With Docker

Use this on a remote PC that does not already have Node.js, npm, PostgreSQL, or PostGIS installed. The only required dependency is Docker Desktop.

### Install Docker On Ubuntu/Linux

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER
```

After running those commands, log out and log back in, or reboot once.

Check Docker:

```bash
docker --version
docker compose version
```

### Start The Project

```powershell
docker compose up --build
```

Open:

```text
http://localhost:5000/
```

Health check:

```text
http://localhost:5000/api/health
```

The database container starts with the schema in `db/init/001_schema.sql`. It does not include sensitive GIS data folders.
The schema seeds non-sensitive demo site master records, one demo admin user, and a few sample ERC/instrument/contact records so a fresh database is usable immediately.

Demo login:

```text
email: admin@example.local
password: Admin@12345
```

## Package For Transfer

Create a zip that excludes installed dependencies, archive files, dumps, and secure import folders. The lightweight public boundary files in `data` are included so the map works after transfer:

```powershell
.\scripts\package-release.ps1
```

Output:

```text
dist\gis-map-data-barc-backend-release.zip
```

This package intentionally skips:

```text
secure_import_data
backend/node_modules
node_modules
*.zip
*.rar
*.dump
backup.dump
```

## Local Node Run

If Node.js and PostgreSQL/PostGIS are already installed locally:

```powershell
npm install
npm start
```

Local database settings can be changed with environment variables:

```text
PORT
DB_HOST
DB_PORT
DB_NAME
DB_USER
DB_PASSWORD
JWT_SECRET
```
