const fs = require("fs");
const path = require("path");
const pool = require("../db");

const projectRoot = path.join(__dirname, "..", "..");
const importRoot = path.join(projectRoot, "secure_import_data");

async function importGeoJson(siteId, folder, layerKey, fileName) {
  const filePath = path.join(importRoot, folder, fileName);

  if (!fs.existsSync(filePath)) {
    console.log(`Skipping missing file: ${filePath}`);
    return;
  }

  const raw = fs.readFileSync(filePath, "utf8");
  const geojson = JSON.parse(raw);

  if (!geojson.features || !Array.isArray(geojson.features)) {
    console.log(`Invalid GeoJSON: ${filePath}`);
    return;
  }

  console.log(`Importing ${folder}/${fileName} → ${geojson.features.length} features`);

  await pool.query(
    "DELETE FROM geo_features WHERE site_id = $1 AND layer_key = $2",
    [siteId, layerKey]
  );

  for (const feature of geojson.features) {
    if (!feature.geometry) continue;

    await pool.query(
      `
      INSERT INTO geo_features (site_id, layer_key, properties, geom)
      VALUES (
        $1,
        $2,
        $3,
        ST_SetSRID(ST_GeomFromGeoJSON($4), 4326)
      )
      `,
      [
        siteId,
        layerKey,
        feature.properties || {},
        JSON.stringify(feature.geometry)
      ]
    );
  }
}

async function main() {
  const result = await pool.query(`
    SELECT
      s.id AS site_id,
      s.folder,
      sl.layer_key,
      sl.file_name
    FROM site_layers sl
    JOIN sites s ON s.id = sl.site_id
    WHERE sl.is_enabled = TRUE
    ORDER BY s.id, sl.layer_key
  `);

  for (const row of result.rows) {
    await importGeoJson(
      row.site_id,
      row.folder,
      row.layer_key,
      row.file_name
    );
  }

  console.log("Import complete.");
  await pool.end();
}

main().catch(error => {
  console.error(error);
  pool.end();
});