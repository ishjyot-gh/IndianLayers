ALTER TABLE contacts
  ADD COLUMN IF NOT EXISTS email_2 TEXT,
  ADD COLUMN IF NOT EXISTS email_3 TEXT,
  ADD COLUMN IF NOT EXISTS mobile_2 TEXT,
  ADD COLUMN IF NOT EXISTS fax_no TEXT;

ALTER TABLE instruments
  ADD COLUMN IF NOT EXISTS site_id INTEGER REFERENCES sites(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_instruments_site_id
  ON instruments(site_id);

DELETE FROM instruments
WHERE erc_id IN (1001, 1002, 1003)
   OR inst_sno IN ('DEMO-TAPS-001', 'DEMO-MAPS-001', 'DEMO-KKNPP-001');

DELETE FROM erc_locations
WHERE erc_id IN (1001, 1002, 1003)
  AND site_id IN (1, 3, 7);

UPDATE instruments i
SET site_id = e.site_id
FROM erc_locations e
WHERE i.erc_id = e.erc_id
  AND i.site_id IS NULL;

CREATE INDEX IF NOT EXISTS idx_contacts_site_scope
  ON contacts(applies_to_all_sites, contact_category, dae_unit, unit, std_code);

WITH rerc_units(site_id, dae_unit, unit_name, std_code) AS (
  VALUES
    (101, 'IREL', 'Alwaye', '0484'),
    (102, 'AMD', 'Bengaluru', '080'),
    (103, 'AMD', 'Delhi', '011'),
    (104, 'IPR', 'Gandhinagar', '079'),
    (105, 'NFC', 'Hyderabad', '040'),
    (106, 'RRCAT', 'Indore', '0731'),
    (107, 'UCI', 'Jaduguda', '0657'),
    (108, 'AMD', 'Jaipur', '0141'),
    (109, 'VECC', 'Kolkata', '033'),
    (110, 'IREL', 'MK-TN', '04651'),
    (111, 'RMP', 'Mysuru', '0821'),
    (112, 'AMD', 'Nagpur', '0712'),
    (113, 'IREL', 'OSCOM', '06811'),
    (114, 'AMD', 'Shillong', '0364'),
    (115, 'UCI', 'Turamdih', '0657'),
    (116, 'BARC', 'Vizag', '0891'),
    (117, 'NRL-BARC', 'Srinagar', '0194'),
    (118, 'NPCIL', 'Kaiga', '08382'),
    (119, 'NPCIL', 'Kakrapar', '02626'),
    (120, 'NPCIL', 'Kota', '01475'),
    (121, 'NPCIL', 'Kudankulam', '04637'),
    (122, 'NPCIL', 'Narora', '05734'),
    (123, 'NPCIL', 'Tarapur', '02525')
)
UPDATE contacts c
SET applies_to_all_sites = FALSE,
    updated_at = NOW()
FROM rerc_units r
WHERE c.dae_unit = r.dae_unit
  AND c.unit = r.unit_name
  AND c.std_code = r.std_code
  AND c.contact_category IN (
    'DAE-RERC Coordinator',
    'DAE-RERC Alternate Coordinator',
    'DAE-RERC Unit Head Details'
  );

WITH rerc_units(site_id, dae_unit, unit_name, std_code) AS (
  VALUES
    (101, 'IREL', 'Alwaye', '0484'),
    (102, 'AMD', 'Bengaluru', '080'),
    (103, 'AMD', 'Delhi', '011'),
    (104, 'IPR', 'Gandhinagar', '079'),
    (105, 'NFC', 'Hyderabad', '040'),
    (106, 'RRCAT', 'Indore', '0731'),
    (107, 'UCI', 'Jaduguda', '0657'),
    (108, 'AMD', 'Jaipur', '0141'),
    (109, 'VECC', 'Kolkata', '033'),
    (110, 'IREL', 'MK-TN', '04651'),
    (111, 'RMP', 'Mysuru', '0821'),
    (112, 'AMD', 'Nagpur', '0712'),
    (113, 'IREL', 'OSCOM', '06811'),
    (114, 'AMD', 'Shillong', '0364'),
    (115, 'UCI', 'Turamdih', '0657'),
    (116, 'BARC', 'Vizag', '0891'),
    (117, 'NRL-BARC', 'Srinagar', '0194'),
    (118, 'NPCIL', 'Kaiga', '08382'),
    (119, 'NPCIL', 'Kakrapar', '02626'),
    (120, 'NPCIL', 'Kota', '01475'),
    (121, 'NPCIL', 'Kudankulam', '04637'),
    (122, 'NPCIL', 'Narora', '05734'),
    (123, 'NPCIL', 'Tarapur', '02525')
)
INSERT INTO site_contact_links (site_id, contact_id)
SELECT r.site_id, c.id
FROM rerc_units r
JOIN contacts c
  ON c.contact_category IN (
    'DAE-RERC Coordinator',
    'DAE-RERC Alternate Coordinator',
    'DAE-RERC Unit Head Details'
  )
 AND c.dae_unit = r.dae_unit
 AND c.unit = r.unit_name
 AND c.std_code = r.std_code
ON CONFLICT (site_id, contact_id) DO NOTHING;

UPDATE contacts
SET applies_to_all_sites = FALSE,
    updated_at = NOW()
WHERE email = 'demo.contact@example.local';

DELETE FROM contacts c
USING contacts keep
WHERE c.id > keep.id
  AND c.contact_category = keep.contact_category
  AND COALESCE(c.dae_unit, '') = COALESCE(keep.dae_unit, '')
  AND COALESCE(c.unit, '') = COALESCE(keep.unit, '')
  AND COALESCE(c.std_code, '') = COALESCE(keep.std_code, '')
  AND COALESCE(c.name, '') = COALESCE(keep.name, '')
  AND COALESCE(c.email, '') = COALESCE(keep.email, '');

DELETE FROM contacts
WHERE applies_to_all_sites = TRUE
  AND contact_category IN (
    'DAE-RERC Coordinator',
    'DAE-RERC Alternate Coordinator',
    'DAE-RERC Unit Head Details'
  )
  AND NULLIF(BTRIM(COALESCE(dae_unit, '')), '') IS NULL
  AND NULLIF(BTRIM(COALESCE(unit, '')), '') IS NULL
  AND NULLIF(BTRIM(COALESCE(std_code, '')), '') IS NULL
  AND NULLIF(BTRIM(COALESCE(name, '')), '') IS NULL
  AND NULLIF(BTRIM(COALESCE(email, '')), '') IS NULL;
