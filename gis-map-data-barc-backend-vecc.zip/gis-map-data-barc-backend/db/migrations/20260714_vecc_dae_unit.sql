UPDATE sites
SET operator = 'VECC'
WHERE id = 109
  AND site_kind = 'rerc'
  AND operator = 'BARC / VECC';

UPDATE erc_locations
SET unit = 'VECC'
WHERE site_id = 109
  AND unit = 'BARC / VECC';

UPDATE contacts
SET dae_unit = 'VECC',
    updated_at = NOW()
WHERE dae_unit = 'BARC / VECC';
