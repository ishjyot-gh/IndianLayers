window.NppApi = (function () {
  async function request(url, options = {}) {
    const headers = new Headers(options.headers || {});
    const token = window.NppAuth && window.NppAuth.getToken();

    if (token) {
      headers.set("Authorization", `Bearer ${token}`);
    }

    const response = await fetch(url, {
      ...options,
      headers
    });

    if (response.status === 401 && window.NppAuth) {
      window.NppAuth.handleUnauthorized();
    }

    return response;
  }

  async function json(url, options = {}) {
    const response = await request(url, options);

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || `${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async function optionalJson(url, options = {}) {
    const response = await request(url, options);

    if (response.status === 404) {
      return null;
    }

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || `${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  return {
    json,
    optionalJson,
    request
  };
})();

