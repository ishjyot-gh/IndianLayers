let siteMap;

const {
  createSiteLayerPanes
} = window.NppSiteDetailConfig;
const {
  getSiteIdFromUrl,
  renderSiteDetails
} = window.NppSiteDetailFormat;

async function fetchJson(url) {
  return window.NppApi.json(url);
}

async function fetchOptionalJson(url) {
  return window.NppApi.optionalJson(url);
}

function renderMissingSite() {
  document.getElementById("siteName").textContent = "Site not found";
  document.getElementById("siteDescription").textContent = "No matching site was found.";
}

function renderSiteHeader(site) {
  document.getElementById("siteName").textContent = site.name;
  const detailNote = site.detail_status === "populated" || site.site_kind === "rerc"
    ? ""
    : "Data yet to be populated.";
  document.getElementById("siteDescription").textContent = [site.description, detailNote].filter(Boolean).join(" ");
  document.getElementById("siteStatus").textContent = site.status || "Operational";
}

function setupResizableSidebar(isRercSite) {
  const layout = document.querySelector(".site-layout");
  const sidebar = document.querySelector(".site-sidebar");
  const handle = document.getElementById("sidebarResizeHandle");
  const storageKey = "nppSites.siteDetailSidebarWidth";

  if (!layout || !sidebar || !handle) return;

  layout.classList.toggle("is-rerc", isRercSite);

  const savedWidth = Number(localStorage.getItem(storageKey));
  if (Number.isFinite(savedWidth) && savedWidth > 0) {
    sidebar.style.width = `${savedWidth}px`;
  }

  function clampWidth(width) {
    const maxWidth = Math.max(360, window.innerWidth * 0.72);
    const minWidth = 320;
    return Math.min(Math.max(width, minWidth), maxWidth);
  }

  handle.addEventListener("mousedown", event => {
    event.preventDefault();
    document.body.classList.add("is-resizing-sidebar");

    function onMouseMove(moveEvent) {
      const width = clampWidth(window.innerWidth - moveEvent.clientX);
      sidebar.style.width = `${width}px`;
      if (siteMap) {
        siteMap.invalidateSize();
      }
    }

    function onMouseUp() {
      document.body.classList.remove("is-resizing-sidebar");
      localStorage.setItem(storageKey, String(Math.round(sidebar.getBoundingClientRect().width)));
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
      if (siteMap) {
        siteMap.invalidateSize();
      }
    }

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
  });
}

async function initSitePage() {
  if (!window.NppAuth.getToken()) {
    window.NppAuth.showLogin(window.location.href);
    return;
  }

  const siteId = getSiteIdFromUrl();
  const [sites, currentSite] = await Promise.all([
    fetchJson("/api/sites"),
    fetchOptionalJson(`/api/sites/${siteId}`)
  ]);

  if (!currentSite) {
    renderMissingSite();
    return;
  }

  const isRercSite = currentSite.site_kind === "rerc";
  const siteLayerSection = document.getElementById("siteLayerSection");
  setupResizableSidebar(isRercSite);

  if (siteLayerSection) {
    siteLayerSection.hidden = isRercSite;
  }

  renderSiteHeader(currentSite);
  renderSiteDetails(currentSite);
  await window.NppSiteDetailRecords.init(currentSite);

  siteMap = L.map("siteMap").setView([currentSite.lat, currentSite.lng], 9);

  const overlays = {};
  const layerControl = L.control.layers(null, overlays, {
    collapsed: false,
    position: "bottomleft"
  }).addTo(siteMap);
  const visibleLayerNames = window.NppSitesCommon.getVisibleLayerNames();
  const markLayersReady = window.NppSitesCommon.bindLayerStatePersistence(siteMap, overlays);
  const siteLayerController = isRercSite ? null : window.NppSiteDetailLayerController.create(siteMap);

  window.NppSitesCommon.createSiteMarkerPane(siteMap);
  createSiteLayerPanes(siteMap);
  window.NppSitesCommon.addTileLayer(siteMap);

  await window.NppSitesCommon.loadStandardLayers({
    map: siteMap,
    layerControl,
    overlays,
    visibleLayerNames,
    sites,
    dataRoot: "../data",
    includeRercUnits: isRercSite,
    selectedSiteId: currentSite.id,
    detailHrefForSite: site => `./site.html?id=${site.id}`
  });

  if (siteLayerController) {
    const apiLayers = await fetchJson(`/api/sites/${siteId}/layers`);
    const resolvedLayers = siteLayerController.resolveSiteLayers(currentSite, apiLayers);

    await siteLayerController.loadSiteLayers(currentSite, resolvedLayers);

    siteLayerController.addGeneratedSectors(currentSite);

    siteLayerController.sendBackgroundLayersToBack();
    siteLayerController.scheduleLayerDetailUpdate();
    siteMap.on("zoomend", siteLayerController.scheduleLayerDetailUpdate);
    siteMap.on("moveend", siteLayerController.scheduleLayerDetailUpdate);
  }
  markLayersReady();
}

initSitePage().catch(error => {
  console.error("Could not initialize site page:", error);
  document.getElementById("siteName").textContent = "Unable to load site";
  document.getElementById("siteDescription").textContent = "Check the browser console for details.";
});
