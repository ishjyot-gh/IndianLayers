window.NppSiteDetailRecords = (function () {
  const state = {
    siteId: null,
    site: null,
    contactsVisible: false,
    instrumentsVisible: false,
    activeContactCategory: null,
    contacts: [],
    instruments: [],
    ercLocations: [],
    rercUnits: [],
    lookups: {
      erc_locations: [],
      manufacturers: [],
      categories: [],
      statuses: []
    }
  };

  function canEditRecords() {
    const user = window.NppAuth && window.NppAuth.getUser();
    return Boolean(user && ["admin", "editor"].includes(user.role));
  }

  function applyRoleVisibility() {
    const canEdit = canEditRecords();

    document.querySelectorAll("[data-editor-only]").forEach(element => {
      element.hidden = !canEdit;
    });
  }

  async function requestJson(url, options) {
    return window.NppApi.json(url, options);
  }

  function formToObject(form) {
    const data = {};

    Array.from(new FormData(form).entries()).forEach(([key, value]) => {
      data[key] = value;
    });

    form.querySelectorAll("input[type='checkbox']").forEach(input => {
      data[input.name] = input.checked;
    });

    return data;
  }

  function showMessage(elementId, message, isError) {
    const element = document.getElementById(elementId);

    if (!element) return;

    element.textContent = message || "";
    element.classList.toggle("is-error", Boolean(isError));
    element.classList.toggle("is-success", Boolean(message && !isError));
  }

  function valueOrDash(value) {
    return value === undefined || value === null || value === "" ? "--" : value;
  }

  function joinOrDash(values) {
    const joined = values.filter(Boolean).join(", ");
    return joined || "--";
  }

  function isRercPage() {
    return state.site && state.site.site_kind === "rerc";
  }

  function toDateInputValue(value) {
    if (!value) return "";
    return String(value).slice(0, 10);
  }

  function setFormValues(form, values) {
    Array.from(form.elements).forEach(element => {
      if (!element.name) return;

      if (element.type === "checkbox") {
        element.checked = values[element.name] !== false;
      } else if (element.type === "date") {
        element.value = toDateInputValue(values[element.name]);
      } else {
        element.value = values[element.name] ?? "";
      }
    });
  }

  function uniqueValues(rows, field) {
    return [...new Set(rows.map(row => row[field]).filter(Boolean))].sort();
  }

  function populateDatalist(id, values) {
    const datalist = document.getElementById(id);
    if (!datalist) return;

    datalist.replaceChildren();
    values.forEach(value => {
      const option = document.createElement("option");
      option.value = value;
      datalist.appendChild(option);
    });
  }

  function populateContactLookups() {
    populateDatalist("daeUnitOptions", uniqueValues(state.rercUnits, "dae_unit"));
    populateDatalist("cityOptions", uniqueValues(state.rercUnits, "city"));
    populateDatalist("stdCodeOptions", uniqueValues(state.rercUnits, "std_code"));
  }

  function normalizeLookupValue(value) {
    return String(value || "").trim().toLowerCase();
  }

  function matchRercUnits(form) {
    const daeUnit = normalizeLookupValue(form.elements.dae_unit.value);
    const city = normalizeLookupValue(form.elements.unit.value);
    const stdCode = normalizeLookupValue(form.elements.std_code.value);

    return state.rercUnits.filter(row => {
      return (!daeUnit || normalizeLookupValue(row.dae_unit) === daeUnit)
        && (!city || normalizeLookupValue(row.city) === city)
        && (!stdCode || normalizeLookupValue(row.std_code) === stdCode);
    });
  }

  function syncContactLocationFields(form) {
    const fieldMap = {
      dae_unit: form.elements.dae_unit,
      city: form.elements.unit,
      std_code: form.elements.std_code
    };
    Object.values(fieldMap).forEach(field => {
      if (!field) return;
      field.readOnly = false;
      field.classList.remove("is-locked");
    });

    const matches = matchRercUnits(form);
    if (matches.length !== 1) return;

    const match = matches[0];
    const values = {
      dae_unit: match.dae_unit || "",
      city: match.city || "",
      std_code: match.std_code || ""
    };

    Object.entries(fieldMap).forEach(([key, field]) => {
      if (!field || field.value.trim()) return;
      field.value = values[key];
      field.classList.add("is-locked");
    });
  }

  function resetAndShowForm(formId, titleId, title) {
    const form = document.getElementById(formId);

    closeRecordForms();
    form.reset();
    form.querySelectorAll("input[type='hidden']").forEach(input => {
      input.value = "";
      input.defaultValue = "";
    });
    form.hidden = false;

    if (titleId) {
      document.getElementById(titleId).textContent = title;
    }

    if (formId === "contactForm") {
      syncContactLocationFields(form);
    }
  }

  async function deleteRecord(url, messageElementId, successMessage) {
    if (!window.confirm("Delete this record?")) return;

    try {
      await requestJson(url, { method: "DELETE" });
      showMessage(messageElementId, successMessage, false);
      await loadRecords();
    } catch (error) {
      showMessage(messageElementId, error.message, true);
    }
  }

  function appendRecordActions(header, actions) {
    const actionWrap = document.createElement("div");
    actionWrap.className = "record-actions";

    actions.forEach(action => {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = action.label;
      button.addEventListener("click", action.onClick);
      actionWrap.appendChild(button);
    });

    header.appendChild(actionWrap);
  }

  function closeRecordForms() {
    document.querySelectorAll(".record-form").forEach(form => {
      form.hidden = true;
    });
  }

  function populateSelect(select, rows, getValue, getLabel, placeholder) {
    select.replaceChildren();

    const emptyOption = document.createElement("option");
    emptyOption.value = "";
    emptyOption.textContent = placeholder;
    select.appendChild(emptyOption);

    rows.forEach(row => {
      const option = document.createElement("option");
      option.value = getValue(row);
      option.textContent = getLabel(row);
      select.appendChild(option);
    });
  }

  function populateInstrumentSelects() {
    const form = document.getElementById("instrumentForm");
    const locationRows = state.lookups.erc_locations?.length ? state.lookups.erc_locations : state.ercLocations;

    populateSelect(
      form.elements.erc_id,
      locationRows,
      row => row.erc_id,
      row => [row.location, row.unit, row.std_code && `STD ${row.std_code}`].filter(Boolean).join(" - ") || `ERC ${row.erc_id}`,
      "Select instrument location"
    );

    if (locationRows.length === 1) {
      form.elements.erc_id.value = locationRows[0].erc_id;
    }

    populateSelect(
      form.elements.status_id,
      state.lookups.statuses,
      row => row.status_id,
      row => row.status_des,
      "No status"
    );

    populateSelect(
      form.elements.manufacturer_id,
      state.lookups.manufacturers,
      row => row.manufacturer_id,
      row => row.manufacturer_name || `Manufacturer ${row.manufacturer_id}`,
      "No manufacturer"
    );

    populateSelect(
      form.elements.category_id,
      state.lookups.categories,
      row => row.instrument_category_id,
      row => row.monitor_type || `Category ${row.instrument_category_id}`,
      "No category"
    );
  }

  function renderContacts() {
    const container = document.getElementById("contactsList");
    const tabs = document.getElementById("contactTabs");
    updateContactVisibility();
    if (!container || !tabs) return;

    container.replaceChildren();
    tabs.replaceChildren();
    const categoryOrder = [
      "DAE-RERC Coordinator",
      "DAE-RERC Alternate Coordinator",
      "DAE-RERC Unit Head Details",
      "Other Contact Details"
    ];

    if (!state.contacts.length) {
      const empty = document.createElement("p");
      empty.className = "empty-records";
      empty.textContent = "No contacts saved.";
      container.appendChild(empty);
      return;
    }

    const groupedContacts = state.contacts.reduce((groups, contact) => {
      const key = contact.contact_category || "Other Contact Details";
      groups[key] = groups[key] || [];
      groups[key].push(contact);
      return groups;
    }, {});

    const sortedGroups = Object.entries(groupedContacts)
      .sort(([leftCategory], [rightCategory]) => {
        const leftIndex = categoryOrder.indexOf(leftCategory);
        const rightIndex = categoryOrder.indexOf(rightCategory);
        return (leftIndex === -1 ? 99 : leftIndex) - (rightIndex === -1 ? 99 : rightIndex);
      });

    if (!state.activeContactCategory || !groupedContacts[state.activeContactCategory]) {
      state.activeContactCategory = sortedGroups[0][0];
    }

    sortedGroups.forEach(([category, contacts]) => {
      const tab = document.createElement("button");
      tab.type = "button";
      tab.className = category === state.activeContactCategory ? "is-active" : "";
      tab.textContent = `${category} (${contacts.length})`;
      tab.addEventListener("click", () => {
        state.activeContactCategory = category;
        renderContacts();
      });
      tabs.appendChild(tab);
    });

    const visibleContacts = groupedContacts[state.activeContactCategory] || [];
    const table = document.createElement("table");
    table.className = "record-table contact-table";

    const thead = document.createElement("thead");
    thead.innerHTML = `
      <tr>
        <th>Actions</th>
        <th>Name</th>
        <th>Unit / STD</th>
        <th>Head Tel No.</th>
        <th>Tel No. / Fax No.</th>
        <th>Residence / Mobile</th>
        <th>Email</th>
        <th>Remarks</th>
      </tr>
    `;
    table.appendChild(thead);

    const tbody = document.createElement("tbody");
    visibleContacts.forEach(contact => {
      const tr = document.createElement("tr");
      const actionCell = document.createElement("td");
      actionCell.className = "record-table-actions";

      appendRecordActions(actionCell, [
        { label: "Edit", onClick: () => editContact(contact) },
        { label: "Delete", onClick: () => deleteRecord(`/api/contacts/${contact.id}`, "contactMessage", "Contact deleted.") }
      ]);

      [
        valueOrDash(contact.name || contact.designation),
        joinOrDash([contact.dae_unit, contact.unit, contact.std_code && `STD ${contact.std_code}`]),
        joinOrDash([contact.head_tel_fax]),
        joinOrDash([contact.office_tel_fax, contact.fax_no && `Fax ${contact.fax_no}`]),
        joinOrDash([contact.residence_mobile, contact.mobile_2]),
        joinOrDash([contact.email, contact.email_2, contact.email_3]),
        valueOrDash(contact.remarks)
      ].forEach(value => {
        const td = document.createElement("td");
        td.textContent = value;
        tr.appendChild(td);
      });

      tr.prepend(actionCell);
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    container.appendChild(table);
  }

  function updateContactVisibility() {
    const modal = document.getElementById("contactsModal");
    const button = document.getElementById("toggleContactsButton");

    if (modal) {
      modal.hidden = !state.contactsVisible;
    }

    if (button) {
      button.textContent = "Show All Contacts";
    }
  }

  function renderInstruments() {
    const container = document.getElementById("instrumentsList");
    updateInstrumentVisibility();
    if (!container) return;

    container.replaceChildren();

    if (!state.instruments.length) {
      const empty = document.createElement("p");
      empty.className = "empty-records";
      empty.textContent = "No instruments saved.";
      container.appendChild(empty);
      return;
    }

    const tableWrap = document.createElement("div");
    tableWrap.className = "contact-table-wrap instrument-table-wrap";
    const table = document.createElement("table");
    table.className = "record-table instrument-table";
    const thead = document.createElement("thead");
    thead.innerHTML = `
      <tr>
        <th>Actions</th>
        <th>Serial No.</th>
        <th>Model</th>
        <th>Location</th>
        <th>Status</th>
        <th>Manufacturer</th>
        <th>Category</th>
        <th>Current Location</th>
      </tr>
    `;
    table.appendChild(thead);

    const tbody = document.createElement("tbody");
    state.instruments.forEach(instrument => {
      const tr = document.createElement("tr");
      const actionCell = document.createElement("td");
      actionCell.className = "record-table-actions";

      appendRecordActions(actionCell, [
        { label: "Edit", onClick: () => editInstrument(instrument) },
        { label: "Delete", onClick: () => deleteRecord(`/api/instruments/${instrument.inst_id}`, "instrumentMessage", "Instrument deleted.") }
      ]);

      [
        valueOrDash(instrument.inst_sno),
        valueOrDash(instrument.inst_model),
        joinOrDash([instrument.erc_location, instrument.erc_unit]),
        valueOrDash(instrument.status_des),
        valueOrDash(instrument.manufacturer_name),
        valueOrDash(instrument.monitor_type),
        valueOrDash(instrument.curr_location)
      ].forEach(value => {
        const td = document.createElement("td");
        td.textContent = value;
        tr.appendChild(td);
      });

      tr.prepend(actionCell);
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    tableWrap.appendChild(table);
    container.appendChild(tableWrap);
  }

  function updateInstrumentVisibility() {
    const container = document.getElementById("instrumentsList");
    const button = document.getElementById("toggleInstrumentsButton");

    if (container) {
      container.hidden = !state.instrumentsVisible;
    }

    if (button) {
      button.textContent = state.instrumentsVisible ? "Hide Instruments" : "Show Instruments";
    }
  }

  function editContact(contact) {
    state.contactsVisible = false;
    updateContactVisibility();
    resetAndShowForm("contactForm", "contactFormTitle", "Edit Contact");
    const form = document.getElementById("contactForm");
    setFormValues(form, contact);
    syncContactLocationFields(form);
  }

  function editInstrument(instrument) {
    resetAndShowForm("instrumentForm", "instrumentFormTitle", "Edit Instrument");
    populateInstrumentSelects();
    setFormValues(document.getElementById("instrumentForm"), instrument);
  }

  async function loadRecords() {
    const [contacts, instruments, ercLocations, lookups, rercUnits] = await Promise.all([
      requestJson(`/api/sites/${state.siteId}/contacts`),
      requestJson(`/api/sites/${state.siteId}/instruments`),
      requestJson(`/api/sites/${state.siteId}/erc-locations`),
      requestJson("/api/instrument-lookups"),
      requestJson("/api/rerc-units")
    ]);

    state.contacts = contacts;
    state.instruments = instruments;
    state.ercLocations = ercLocations;
    state.lookups = lookups;
    state.rercUnits = rercUnits;

    populateContactLookups();
    populateInstrumentSelects();
    renderContacts();
    renderInstruments();
  }

  function bindFormEvents() {
    applyRoleVisibility();
    const contactForm = document.getElementById("contactForm");

    document.querySelectorAll("[data-cancel-form]").forEach(button => {
      button.addEventListener("click", () => {
        const form = document.getElementById(button.dataset.cancelForm);
        if (form) form.hidden = true;
      });
    });

    document.getElementById("addContactButton").addEventListener("click", () => {
      resetAndShowForm("contactForm", "contactFormTitle", "Add Contact");
    });

    document.getElementById("toggleContactsButton").addEventListener("click", () => {
      state.contactsVisible = true;
      updateContactVisibility();
    });

    document.getElementById("closeContactsModalButton").addEventListener("click", () => {
      state.contactsVisible = false;
      updateContactVisibility();
    });

    document.getElementById("toggleInstrumentsButton").addEventListener("click", () => {
      state.instrumentsVisible = !state.instrumentsVisible;
      updateInstrumentVisibility();
    });

    document.getElementById("addInstrumentButton").addEventListener("click", async () => {
      await loadRecords();
      state.instrumentsVisible = false;
      updateInstrumentVisibility();
      showMessage("instrumentMessage", "", false);
      resetAndShowForm("instrumentForm", "instrumentFormTitle", "Add Instrument");
      populateInstrumentSelects();
    });

    contactForm.addEventListener("submit", async event => {
      event.preventDefault();

      const form = event.currentTarget;
      const data = formToObject(form);
      const id = data.id;
      const url = id ? `/api/contacts/${id}` : `/api/sites/${state.siteId}/contacts`;
      const method = id ? "PUT" : "POST";
      data.site_id = state.siteId;
      const submitButton = form.querySelector("button[type='submit']");

      try {
        if (submitButton) submitButton.disabled = true;
        await requestJson(url, {
          method,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        });
        form.hidden = true;
        state.contactsVisible = true;
        await loadRecords();
        showMessage("contactMessage", id ? "Contact updated successfully." : "Contact added successfully.", false);
      } catch (error) {
        showMessage("contactMessage", error.message, true);
      } finally {
        if (submitButton) submitButton.disabled = false;
      }
    });

    ["dae_unit", "unit", "std_code"].forEach(name => {
      contactForm.elements[name].addEventListener("input", () => syncContactLocationFields(contactForm));
      contactForm.elements[name].addEventListener("change", () => syncContactLocationFields(contactForm));
    });

    document.getElementById("instrumentForm").addEventListener("submit", async event => {
      event.preventDefault();

      const form = event.currentTarget;
      const data = formToObject(form);
      const id = data.inst_id;
      const url = id ? `/api/instruments/${id}` : `/api/sites/${state.siteId}/instruments`;
      const method = id ? "PUT" : "POST";
      const submitButton = form.querySelector("button[type='submit']");

      try {
        if (submitButton) submitButton.disabled = true;
        await requestJson(url, {
          method,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        });
        form.hidden = true;
        state.instrumentsVisible = true;
        await loadRecords();
        showMessage("instrumentMessage", id ? "Instrument updated successfully." : "Instrument added successfully.", false);
      } catch (error) {
        showMessage("instrumentMessage", error.message, true);
      } finally {
        if (submitButton) submitButton.disabled = false;
      }
    });
  }

  async function init(site) {
    state.site = site;
    state.siteId = site.id;
    state.contactsVisible = false;
    state.instrumentsVisible = false;
    bindFormEvents();
    updateContactVisibility();
    updateInstrumentVisibility();
    await loadRecords();
  }

  return {
    init
  };
})();
