window.NppSiteDetailLabels = (function () {
  const { maxVisibleLabels } = window.NppSiteDetailConfig;

  function create(map, loadedSiteLayers) {
    const visibleLabelLayers = new Set();
    let labelUpdateFrame = null;

    function scheduleLayerDetailUpdate() {
      if (labelUpdateFrame !== null) {
        cancelAnimationFrame(labelUpdateFrame);
      }

      labelUpdateFrame = requestAnimationFrame(() => {
        labelUpdateFrame = null;
        updateLayersByZoom();
      });
    }

    function updateLayersByZoom() {
      const currentZoom = map.getZoom();
      const visibleLabelBoxes = [];
      const visibleLabelKeys = new Set();
      let labelCount = 0;

      visibleLabelLayers.forEach(featureLayer => {
        hideFeatureLabel(featureLayer);
      });
      visibleLabelLayers.clear();

      getOrderedLayersForLabels().forEach(item => {
        const minZoom = item.rule.minZoom ?? 0;
        const shouldShowLayer = item.userEnabled && currentZoom >= minZoom;

        if (shouldShowLayer && !map.hasLayer(item.layer)) {
          item.layer.addTo(map);
        }

        if (!shouldShowLayer && map.hasLayer(item.layer)) {
          map.removeLayer(item.layer);
        }

        if (!shouldShowLayer) {
          return;
        }

        item.layer.eachLayer(featureLayer => {
          if (labelCount >= maxVisibleLabels) {
            return;
          }

          if (featureLayer.nppSuppressLabel) {
            return;
          }

          const tooltip = featureLayer.getTooltip();

          if (!tooltip) return;

          const shouldShowLabel =
            currentZoom >= item.rule.labelZoom &&
            map.hasLayer(item.layer) &&
            hasSpaceForLabel(featureLayer, item, visibleLabelBoxes, visibleLabelKeys);

          if (shouldShowLabel) {
            showFeatureLabel(featureLayer);
            visibleLabelLayers.add(featureLayer);
            labelCount += 1;
          }
        });
      });
    }

    function getOrderedLayersForLabels() {
      return [...loadedSiteLayers].sort((first, second) => {
        return getLayerLabelPriority(second.key) - getLayerLabelPriority(first.key);
      });
    }

    function getLayerLabelPriority(layerKey) {
      if (["sector", "sectors", "generated_sectors"].includes(layerKey)) return 100;
      if (["district_boundary", "taluk_boundary"].includes(layerKey)) return 70;
      if (["settlement", "settlements", "settlement_point", "settle_point"].includes(layerKey)) return 60;
      if (["water_bodies", "river_line", "canal_line"].includes(layerKey)) return 50;
      if (["hospital", "landmark", "railway_station"].includes(layerKey)) return 40;
      if (["road", "railway_track"].includes(layerKey)) return 30;
      return 10;
    }

    function showFeatureLabel(featureLayer) {
      const tooltip = featureLayer.getTooltip();

      if (!tooltip) return;

      featureLayer.openTooltip();
      bindSectorLabelClick(featureLayer, tooltip);
    }

    function bindSectorLabelClick(featureLayer, tooltip) {
      const element = tooltip.getElement && tooltip.getElement();

      if (!element || !element.classList.contains("map-label-sector") || element.dataset.sectorClickBound === "true") {
        return;
      }

      element.dataset.sectorClickBound = "true";
      element.addEventListener("click", event => {
        L.DomEvent.stop(event);
        featureLayer.fire("click", {
          originalEvent: event,
          latlng: featureLayer.nppLabelLatLng || getFeatureLabelLatLng(featureLayer)
        });
      });
    }

    function getFeatureLabelLatLng(featureLayer) {
      if (typeof featureLayer.getLatLng === "function") {
        return featureLayer.getLatLng();
      }

      if (typeof featureLayer.getBounds === "function") {
        const bounds = featureLayer.getBounds();

        if (bounds.isValid()) {
          return bounds.getCenter();
        }
      }

      return null;
    }

    function hideFeatureLabel(featureLayer) {
      const tooltip = featureLayer.getTooltip();

      if (!tooltip) return;

      featureLayer.closeTooltip();
    }

    function hasSpaceForLabel(featureLayer, item, visibleLabelBoxes, visibleLabelKeys) {
      const labelPoint = getFeatureLabelPoint(featureLayer);

      if (!labelPoint) return false;

      const labelText = featureLayer.nppLabelText || featureLayer.getTooltip()?.getContent() || item.name;
      const labelKey = `${item.key}:${labelText}`;

      if (visibleLabelKeys.has(labelKey)) {
        return false;
      }

      const width = estimateLabelWidth(labelText);
      const height = featureLayer.nppLabelCentered ? 24 : 18;
      const gap = 4;
      const left = featureLayer.nppLabelCentered ? labelPoint.x - (width / 2) : labelPoint.x + 8;
      const box = {
        left: left - gap,
        top: labelPoint.y - (height / 2) - gap,
        right: left + width + gap,
        bottom: labelPoint.y + (height / 2) + gap
      };

      const mapSize = map.getSize();

      if (box.left < 0 || box.top < 0 || box.right > mapSize.x || box.bottom > mapSize.y) {
        return false;
      }

      if (visibleLabelBoxes.some(existingBox => boxesOverlap(box, existingBox))) {
        return false;
      }

      visibleLabelBoxes.push(box);
      visibleLabelKeys.add(labelKey);
      return true;
    }

    function getFeatureLabelPoint(featureLayer) {
      if (featureLayer.nppLabelLatLng) {
        return map.latLngToLayerPoint(featureLayer.nppLabelLatLng);
      }

      if (typeof featureLayer.getLatLng === "function") {
        return map.latLngToLayerPoint(featureLayer.getLatLng());
      }

      if (typeof featureLayer.getBounds === "function") {
        const bounds = featureLayer.getBounds();

        if (bounds.isValid()) {
          return map.latLngToLayerPoint(bounds.getCenter());
        }
      }

      return null;
    }

    function estimateLabelWidth(text) {
      if (String(text).length <= 2) {
        return 24;
      }

      return Math.min(180, Math.max(34, String(text).length * 6.4 + 12));
    }

    function boxesOverlap(firstBox, secondBox) {
      return !(
        firstBox.right < secondBox.left ||
        firstBox.left > secondBox.right ||
        firstBox.bottom < secondBox.top ||
        firstBox.top > secondBox.bottom
      );
    }

    return {
      scheduleLayerDetailUpdate,
      showFeatureLabel
    };
  }

  return {
    create
  };
})();
