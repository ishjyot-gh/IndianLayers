window.NppSiteDetailFormat = (function () {
  function getSiteIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return Number(params.get("id"));
  }

  function formatLabel(key) {
    const labels = {
      id: "ID",
      lat: "Latitude",
      lng: "Longitude",
      site_kind: "Record Type",
      detail_status: "Detail Status",
      reactor_type: "Reactor Type",
      installed_capacity_mw: "Installed Capacity (MW)"
    };

    return labels[key] || key.replace(/_/g, " ").replace(/\b\w/g, char => char.toUpperCase());
  }

  function formatValue(value) {
    if (value === undefined || value === null || value === "") return "Not available";
    if (Array.isArray(value)) return value.join(", ");
    return String(value);
  }

  function renderSiteDetails(site) {
    const detailList = document.getElementById("siteDetails");

    const preferredOrder = [
      "id",
      "state",
      "zone",
      "reactor_type",
      "operator",
      "installed_capacity_mw",
      "units",
      "status",
      "lat",
      "lng"
    ];

    const hiddenKeys = [
      "name",
      "description",
      "folder",
      "detail_status",
      "layers",
      "layer_sets",
      "site_layers",
      "has_site_layers",
      "generate_sectors",
      "sector_radius_km",
      "sector_count"
    ];

    const displayedKeys = preferredOrder.filter(key => key in site);
    const remainingKeys = Object.keys(site).filter(key =>
      !hiddenKeys.includes(key) && !displayedKeys.includes(key)
    );

    detailList.replaceChildren();

    [...displayedKeys, ...remainingKeys].forEach(key => {
      const term = document.createElement("dt");
      const description = document.createElement("dd");

      term.textContent = formatLabel(key);
      description.textContent = formatValue(site[key]);

      detailList.append(term, description);
    });
  }

  return {
    formatLabel,
    getSiteIdFromUrl,
    renderSiteDetails
  };
})();
