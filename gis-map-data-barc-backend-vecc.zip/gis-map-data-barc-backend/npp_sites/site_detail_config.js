window.NppSiteDetailConfig = (function () {
  const layerZoomRules = {
    sector: { defaultVisible: true, minZoom: 0, labelZoom: 9 },
    sectors: { defaultVisible: true, minZoom: 0, labelZoom: 9 },
    district_boundary: { defaultVisible: true, minZoom: 0, labelZoom: 10 },
    taluk_boundary: { defaultVisible: true, minZoom: 11, labelZoom: 12 },

    settlement: { defaultVisible: true, minZoom: 11, labelZoom: 12 },
    settlements: { defaultVisible: true, minZoom: 11, labelZoom: 12 },
    road: { defaultVisible: true, minZoom: 13, labelZoom: 14 },
    railway_track: { defaultVisible: true, minZoom: 13, labelZoom: 14 },
    river_line: { defaultVisible: true, minZoom: 12, labelZoom: 13 },
    canal_line: { defaultVisible: true, minZoom: 13, labelZoom: 14 },
    water_bodies: { defaultVisible: true, minZoom: 12, labelZoom: 13 },

    settlement_point: { defaultVisible: true, minZoom: 12, labelZoom: 13 },
    settle_point: { defaultVisible: true, minZoom: 12, labelZoom: 13 },
    hospital: { defaultVisible: true, minZoom: 14, labelZoom: 15 },
    landmark: { defaultVisible: true, minZoom: 14, labelZoom: 15 },
    railway_station: { defaultVisible: true, minZoom: 14, labelZoom: 15 },
    generated_sectors: { defaultVisible: true, minZoom: 0, labelZoom: 9 }
  };

  const maxVisibleLabels = 70;

  function createSiteLayerPanes(map) {
    const panes = [
      ["siteAreas", 430],
      ["siteLines", 520],
      ["sitePoints", 640]
    ];

    panes.forEach(([name, zIndex]) => {
      if (!map.getPane(name)) {
        map.createPane(name);
      }

      map.getPane(name).style.zIndex = zIndex;
    });
  }

  return {
    createSiteLayerPanes,
    layerZoomRules,
    maxVisibleLabels
  };
})();
