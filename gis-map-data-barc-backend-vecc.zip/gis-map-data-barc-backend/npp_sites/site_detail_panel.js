window.NppSiteDetailPanel = (function () {
  function renderLayerPanel(groupedLayers, onLayerToggle) {
    const panel = document.getElementById("siteLayerPanel");

    if (!panel) return;

    panel.innerHTML = "";

    Object.entries(groupedLayers).forEach(([category, layers]) => {
      layers.forEach(item => {
        appendLayerPanelItem(category, item, onLayerToggle);
      });
    });
  }

  function appendLayerPanelItem(category, item, onLayerToggle) {
    const panel = document.getElementById("siteLayerPanel");

    if (!panel) return;

    const layerList = getOrCreateLayerPanelList(panel, category);
    const label = document.createElement("label");
    label.className = "layer-checkbox";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = item.loadedItem.userEnabled;

    checkbox.addEventListener("change", () => {
      item.loadedItem.userEnabled = checkbox.checked;
      onLayerToggle();
    });

    label.append(checkbox, ` ${item.name}`);
    layerList.appendChild(label);
  }

  function getOrCreateLayerPanelList(panel, category) {
    const existingList = panel.querySelector(`[data-layer-category="${category}"]`);

    if (existingList) {
      return existingList;
    }

    const categoryBox = document.createElement("div");
    categoryBox.className = "layer-category";

    const button = document.createElement("button");
    button.type = "button";
    button.className = "layer-category-button";
    button.textContent = category;

    const layerList = document.createElement("div");
    layerList.className = "layer-list";
    layerList.dataset.layerCategory = category;
    layerList.style.display = "none";

    button.addEventListener("click", () => {
      layerList.style.display = layerList.style.display === "none" ? "block" : "none";
    });

    categoryBox.append(button, layerList);
    panel.appendChild(categoryBox);

    return layerList;
  }

  return {
    appendLayerPanelItem,
    renderLayerPanel
  };
})();
