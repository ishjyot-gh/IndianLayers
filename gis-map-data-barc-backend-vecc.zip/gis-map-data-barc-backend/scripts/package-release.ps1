param(
  [string]$OutputPath = ".\dist\gis-map-data-barc-backend-release.zip"
)

$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$outputFullPath = Join-Path $root $OutputPath
$staging = Join-Path $env:TEMP ("gis-map-data-barc-backend-release-" + [guid]::NewGuid())

$excludeDirs = @(
  ".git",
  ".idea",
  "node_modules",
  "backend\node_modules",
  "secure_import_data",
  "dist"
)

$excludeFiles = @(
  "*.zip",
  "*.rar",
  "*.dump",
  "backup.dump"
)

New-Item -ItemType Directory -Path $staging | Out-Null
New-Item -ItemType Directory -Path (Split-Path $outputFullPath -Parent) -Force | Out-Null

robocopy $root $staging /E /XD $excludeDirs /XF $excludeFiles | Out-Null

if (Test-Path $outputFullPath) {
  Remove-Item $outputFullPath -Force
}

Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $outputFullPath -Force
Remove-Item $staging -Recurse -Force

Write-Host "Created package: $outputFullPath"
