window.NppSitesCommon = (function () {
  const layerStateKey = "nppSites.visibleLayers";
  const defaultVisibleLayers = ["India", "States", "NPP Sites", "DAE-RERC Units"];

  function addTileLayer(map) {
    // L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    //   maxZoom: 19,
    //   attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    // }).addTo(map);
  }

  function createSiteMarkerPane(map) {
    map.createPane("siteMarkers");
    map.getPane("siteMarkers").style.zIndex = 650;
  }

  function getVisibleLayerNames() {
    try {
      const storedLayers = JSON.parse(localStorage.getItem(layerStateKey));

      if (Array.isArray(storedLayers)) {
        return storedLayers;
      }
    } catch (error) {
      console.warn("Could not read saved map layers:", error);
    }

    return defaultVisibleLayers;
  }

  function saveVisibleLayerNames(map, overlays) {
    const visibleLayers = Object.entries(overlays)
      .filter(([, layer]) => map.hasLayer(layer))
      .map(([name]) => name);

    localStorage.setItem(layerStateKey, JSON.stringify(visibleLayers));
  }

  function bindLayerStatePersistence(map, overlays) {
    let layersReady = false;

    map.on("overlayadd overlayremove", () => {
      if (layersReady) {
        saveVisibleLayerNames(map, overlays);
      }
    });

    return function markLayersReady() {
      layersReady = true;
      saveVisibleLayerNames(map, overlays);
    };
  }

  function boundaryPopupText(properties) {
    const name =
      properties.STATE ||
      properties.DISTRICT ||
      properties.District ||
      properties.NAME ||
      properties.Name ||
      properties.NAME_3 ||
      properties.NAME_2 ||
      properties.NAME_1 ||
      properties.NAME_0 ||
      "Unknown";

    const type =
      properties.TYPE ||
      properties.Type ||
      properties.ENGTYPE_3 ||
      properties.ENGTYPE_2 ||
      properties.ENGTYPE_1 ||
      "";

    return `
    <b>${name}</b><br/>
    ${type ? `${type}<br/>` : ""}
  `;
  }

  function styleForLayer(name) {
    const styles = {
      India: {
        weight: 2,
        fillOpacity: 0.04
      },
      States: {
        weight: 1.5,
        fillOpacity: 0.08
      },
      Districts: {
        color: "#2563eb",
        weight: 1.8,
        opacity: 0.9,
        fillOpacity: 0.04
      },
      Taluks: {
        color: "#1d4ed8",
        weight: 1.2,
        opacity: 0.85,
        fillOpacity: 0.025
      }
    };

    return styles[name] || { weight: 1, fillOpacity: 0.05 };
  }

  async function addGeoJsonLayer(options) {
    const { map, layerControl, overlays, name, url, visibleLayerNames } = options;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const layer = L.geoJSON(data, {
      style: styleForLayer(name),
      onEachFeature: function (feature, leafletLayer) {
        leafletLayer.bindPopup(boundaryPopupText(feature.properties || {}));
      }
    });

    overlays[name] = layer;
    layerControl.addOverlay(layer, name);

    if (visibleLayerNames.includes(name)) {
      layer.addTo(map);
    }

    return layer;
  }

  async function addBoundaryLayers(options) {
    const { dataRoot } = options;
    const boundaries = [
      ["India", "india.geojson"],
      ["States", "states.geojson"],
      ["Districts", "districts.geojson"],
      ["Taluks", "taluks.geojson"]
    ];

    for (const [name, fileName] of boundaries) {
      try {
        await addGeoJsonLayer({
          ...options,
          name,
          url: `${dataRoot}/${fileName}`
        });
      } catch (error) {
        console.warn(`Skipping ${name} layer:`, error);
      }
    }
  }

  function sitePopupText(site, detailHref) {
    const escapedHref = String(detailHref).replace(/'/g, "\\'");
    const isRercUnit = site.site_kind === "rerc";

    return `
      <b>${site.name}</b><br/>
      State: ${site.state || "Not available"}<br/>
      ${isRercUnit ? `Unit: ${site.operator || "Not available"}<br/>` : `Reactor Type: ${site.reactor_type || "Not available"}<br/>`}
      Operator: ${site.operator || "Not available"}<br/><br/>
      <button type="button" onclick="window.NppAuth ? window.NppAuth.openProtectedSite('${escapedHref}') : window.location.href='${escapedHref}'">
        Details
      </button>
    `;
  }

  function markerIconForSite(site, isSelected) {
    const isRercUnit = site.site_kind === "rerc";
    const className = [
      "site-pin",
      isRercUnit ? "site-pin-rerc" : "site-pin-npp",
      isSelected ? "is-selected" : ""
    ].filter(Boolean).join(" ");
    const size = isRercUnit ? 16 : 22;

    return L.divIcon({
      className,
      html: "<span></span>",
      iconSize: [size, size],
      iconAnchor: [size / 2, size],
      popupAnchor: [0, -Math.round(size * 0.85)]
    });
  }

  function labelForSite(site) {
    if (site.site_kind === "rerc") {
      const city = String(site.name || "").replace(/^DAE-RERC Unit - [^-]+\s*/i, "").trim();
      return [site.operator, city].filter(Boolean).join(", ");
    }

    const withoutPrefix = String(site.name || "")
      .replace(/^NPP\s*-\s*/i, "")
      .replace(/^Nuclear Power Plant\s*-\s*/i, "")
      .replace(/\b(atomic|nuclear)\s+power\s+(station|plant)\b/ig, "")
      .replace(/\b(generating|generation)\s+(station|plant)\b/ig, "")
      .replace(/\bpower\s+(station|plant)\b/ig, "")
      .replace(/\bstation\b/ig, "")
      .replace(/\bplant\b/ig, "")
      .trim();
    const parts = withoutPrefix.split(/\s*-\s*/).filter(Boolean);
    const label = parts[parts.length - 1] || withoutPrefix || site.name || "Site";

    return label.replace(/\s+/g, " ").trim();
  }

  function addMarkerLayer(options, layerName, markerSites) {
    const {
      map,
      layerControl,
      overlays,
      visibleLayerNames,
      detailHrefForSite,
      selectedSiteId
    } = options;
    const layer = L.layerGroup();
    const bounds = L.latLngBounds();
    let selectedMarker = null;

    markerSites.forEach(site => {
      const isSelected = site.id === selectedSiteId;
      const latLng = [site.lat, site.lng];
      const marker = L.marker(latLng, {
        icon: markerIconForSite(site, isSelected),
        pane: "siteMarkers"
      });

      marker.bindPopup(sitePopupText(site, detailHrefForSite(site)));
      marker.bindTooltip(labelForSite(site), {
        permanent: true,
        direction: "right",
        offset: [10, -18],
        className: site.site_kind === "rerc" ? "site-marker-label site-marker-label-rerc" : "site-marker-label site-marker-label-npp"
      });
      marker.addTo(layer);
      bounds.extend(latLng);

      if (isSelected) {
        selectedMarker = marker;
      }
    });

    overlays[layerName] = layer;
    layerControl.addOverlay(layer, layerName);

    if (visibleLayerNames.includes(layerName)) {
      layer.addTo(map);

      if (selectedMarker) {
        selectedMarker.openPopup();
      }
    }

    return {
      layer,
      bounds
    };
  }

  function createSiteLayer(options) {
    const { sites } = options;
    const siteBounds = L.latLngBounds();
    const includeRercUnits = options.includeRercUnits !== false;
    const nppLayer = addMarkerLayer(
      options,
      "NPP Sites",
      sites.filter(site => site.site_kind !== "rerc")
    );
    const markerBounds = [nppLayer.bounds];

    if (includeRercUnits) {
      const rercLayer = addMarkerLayer(
        options,
        "DAE-RERC Units",
        sites.filter(site => site.site_kind === "rerc")
      );
      markerBounds.push(rercLayer.bounds);
    }

    markerBounds.forEach(bounds => {
      if (bounds.isValid()) {
        siteBounds.extend(bounds.getNorthEast());
        siteBounds.extend(bounds.getSouthWest());
      }
    });

    return {
      layer: nppLayer.layer,
      bounds: siteBounds
    };
  }

  async function loadStandardLayers(options) {
    await addBoundaryLayers(options);
    return createSiteLayer(options);
  }

  return {
    addTileLayer,
    bindLayerStatePersistence,
    createSiteMarkerPane,
    getVisibleLayerNames,
    loadStandardLayers
  };
})();
