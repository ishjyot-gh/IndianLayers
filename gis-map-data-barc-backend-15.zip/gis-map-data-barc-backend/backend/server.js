const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const XLSX = require("xlsx");
const pool = require("./db");
const config = require("./config");

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024,
    files: 8
  }
});

app.use(express.json());

// serve frontend from project root
app.use(express.static(path.join(__dirname, "..")));

function emptyToNull(value) {
  if (value === undefined || value === null || String(value).trim() === "") {
    return null;
  }

  const trimmedValue = String(value).trim();

  if (
    trimmedValue === "\\N" ||
    trimmedValue.toUpperCase() === "NULL" ||
    /^#+$/.test(trimmedValue)
  ) {
    return null;
  }

  return trimmedValue;
}

function intOrNull(value) {
  const cleanedValue = emptyToNull(value);

  if (cleanedValue === null) {
    return null;
  }

  const parsedValue = Number(cleanedValue);

  if (!Number.isInteger(parsedValue)) {
    return null;
  }

  return parsedValue;
}

function dateOrNull(value) {
  const cleanedValue = emptyToNull(value);

  if (cleanedValue === null) {
    return null;
  }

  const serialValue = Number(cleanedValue);

  if (Number.isFinite(serialValue) && serialValue > 0) {
    const parsedDate = XLSX.SSF.parse_date_code(serialValue);

    if (parsedDate) {
      return [
        parsedDate.y,
        String(parsedDate.m).padStart(2, "0"),
        String(parsedDate.d).padStart(2, "0")
      ].join("-");
    }
  }

  const directDate = new Date(cleanedValue);

  if (!Number.isNaN(directDate.getTime())) {
    return directDate.toISOString().slice(0, 10);
  }

  return null;
}

async function getNextIntegerId(tableName, columnName, dbClient = pool) {
  const result = await dbClient.query(`SELECT COALESCE(MAX(${columnName}), 0) + 1 AS next_id FROM ${tableName}`);
  return result.rows[0].next_id;
}

async function linkContactToSite(siteId, contactId) {
  await pool.query(`
    INSERT INTO site_contact_links (site_id, contact_id)
    VALUES ($1, $2)
    ON CONFLICT (site_id, contact_id) DO NOTHING
  `, [siteId, contactId]);
}

async function getSiteKind(siteId) {
  const result = await pool.query("SELECT site_kind FROM sites WHERE id = $1", [siteId]);
  return result.rows[0]?.site_kind || null;
}

async function getSite(siteId) {
  const result = await pool.query("SELECT * FROM sites WHERE id = $1", [siteId]);
  return result.rows[0] || null;
}

async function ensureRercInstrumentLocation(siteId) {
  const site = await getSite(siteId);

  if (!site || site.site_kind !== "rerc") {
    return null;
  }

  const existing = await pool.query(`
    SELECT *
    FROM erc_locations
    WHERE site_id = $1
    ORDER BY erc_id
    LIMIT 1
  `, [siteId]);

  if (existing.rows.length) {
    return existing.rows[0];
  }

  const rercUnit = await pool.query(`
    SELECT DISTINCT ON (s.id)
      s.id AS site_id,
      s.state AS erc_state,
      REGEXP_REPLACE(s.name, '^DAE-RERC Unit - [^-]+\\s*', '') AS location,
      s.operator AS unit
    FROM sites s
    WHERE s.id = $1
      AND s.site_kind = 'rerc'
  `, [siteId]);

  if (!rercUnit.rows.length) {
    return null;
  }

  const nextId = await getNextIntegerId("erc_locations", "erc_id");
  const created = await pool.query(`
    INSERT INTO erc_locations (
      erc_id,
      site_id,
      erc_state,
      location,
      unit
    )
    VALUES ($1, $2, $3, $4, $5)
    RETURNING *
  `, [
    nextId,
    siteId,
    rercUnit.rows[0].erc_state,
    rercUnit.rows[0].location,
    rercUnit.rows[0].unit
  ]);

  return created.rows[0];
}

function hasContactLocation(data) {
  return Boolean(emptyToNull(data.dae_unit) || emptyToNull(data.unit) || emptyToNull(data.std_code));
}

function isOtherContactCategory(category) {
  return (emptyToNull(category) || "Other Contact Details") === "Other Contact Details";
}

function normalizeContactPayload(body, site) {
  const category = emptyToNull(body.contact_category) || "Other Contact Details";
  const hasExplicitLocation = hasContactLocation(body);
  const isCommon = isOtherContactCategory(category);

  const data = {
    contact_category: category,
    dae_unit: emptyToNull(body.dae_unit),
    std_code: emptyToNull(body.std_code),
    unit: emptyToNull(body.unit),
    name: emptyToNull(body.name),
    designation: null,
    office_tel_fax: emptyToNull(body.office_tel_fax),
    head_tel_fax: emptyToNull(body.head_tel_fax),
    residence_mobile: emptyToNull(body.residence_mobile),
    email: emptyToNull(body.email),
    email_2: emptyToNull(body.email_2),
    email_3: emptyToNull(body.email_3),
    mobile_2: emptyToNull(body.mobile_2),
    fax_no: emptyToNull(body.fax_no),
    address: null,
    remarks: emptyToNull(body.remarks),
    applies_to_all_sites: isCommon
  };

  if (site?.site_kind === "rerc" && hasExplicitLocation) {
    data.dae_unit = data.dae_unit || site.operator || null;
  }

  return data;
}

function validateContact(data) {
  if (!data.name) {
    return "Name is required.";
  }

  if (!data.email) {
    return "At least one email is required.";
  }

  if (!data.office_tel_fax) {
    return "At least one telephone number is required.";
  }

  if (data.contact_category !== "Other Contact Details" && !hasContactLocation(data)) {
    return "DAE unit, city, or STD code is required for DAE-RERC contact categories.";
  }

  return null;
}

function validateInstrumentPayload(data) {
  if (!intOrNull(data.erc_id)) {
    return "Instrument location is required.";
  }

  if (!emptyToNull(data.inst_sno)) {
    return "Serial number is required.";
  }

  if (!emptyToNull(data.inst_model)) {
    return "Model is required.";
  }

  return null;
}

function validateInstrumentImportPayload(data) {
  if (!intOrNull(data.erc_id)) {
    return "Instrument location is required.";
  }

  if (!emptyToNull(data.inst_model)) {
    return "Model is required.";
  }

  return null;
}

async function findDuplicateContact(siteId, data, contactIdToIgnore = null) {
  const result = await pool.query(`
    SELECT c.*
    FROM contacts c
    WHERE ($1::BIGINT IS NULL OR c.id <> $1::BIGINT)
      AND c.contact_category = $2
      AND COALESCE(c.name, '') = COALESCE($3, '')
      AND COALESCE(c.email, '') = COALESCE($4, '')
      AND COALESCE(c.dae_unit, '') = COALESCE($5, '')
      AND COALESCE(c.unit, '') = COALESCE($6, '')
      AND COALESCE(c.std_code, '') = COALESCE($7, '')
    ORDER BY c.id
    LIMIT 1
  `, [
    contactIdToIgnore,
    data.contact_category,
    data.name,
    data.email,
    data.dae_unit,
    data.unit,
    data.std_code
  ]);

  return result.rows[0] || null;
}

async function linkContactToMatchingRercSites(contactId, contact) {
  await pool.query("DELETE FROM site_contact_links WHERE contact_id = $1", [contactId]);

  if (contact.applies_to_all_sites) {
    return;
  }

  const result = await pool.query(`
    SELECT DISTINCT s.id
    FROM sites s
    LEFT JOIN erc_locations e ON e.site_id = s.id
    WHERE s.site_kind = 'rerc'
      AND ($1::TEXT IS NULL OR LOWER(CASE WHEN s.operator = 'BARC / VECC' THEN 'VECC' ELSE COALESCE(s.operator, '') END) = LOWER($1))
      AND ($2::TEXT IS NULL OR LOWER(COALESCE(e.location, REGEXP_REPLACE(s.name, '^DAE-RERC Unit - [^-]+\\s*', ''))) = LOWER($2))
      AND ($3::TEXT IS NULL OR LOWER(COALESCE(e.std_code, '')) = LOWER($3))
  `, [contact.dae_unit, contact.unit, contact.std_code]);

  await Promise.all(result.rows.map(row => linkContactToSite(row.id, contactId)));
}

function publicUser(row) {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
    emp_no: row.emp_no,
    designation: row.designation,
    section: row.section,
    division: row.division,
    location: row.location
  };
}

function createToken(user) {
  return jwt.sign(
    {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    },
    config.jwtSecret,
    { expiresIn: "8h" }
  );
}

async function ensureDemoAdminUser() {
  await pool.query(`
    INSERT INTO users (
      name,
      email,
      password_hash,
      role,
      emp_no,
      designation,
      section,
      division,
      location
    ) VALUES (
      'Demo Admin',
      'admin@example.local',
      '$2b$10$/tDy7pj5FAdxaZ2mROs4ie0gLjcugwEU1IlGLGwVh0Db9HF37.3EO',
      'admin',
      10001,
      'Demo Administrator',
      'Emergency Preparedness',
      'BARC',
      'Mumbai'
    )
    ON CONFLICT (email) DO NOTHING
  `);
}

function requireAuth(req, res, next) {
  const authHeader = req.get("Authorization") || "";
  const [scheme, token] = authHeader.split(" ");

  if (scheme !== "Bearer" || !token) {
    return res.status(401).json({ error: "Login required" });
  }

  try {
    req.user = jwt.verify(token, config.jwtSecret);
    next();
  } catch (error) {
    return res.status(401).json({ error: "Invalid or expired login" });
  }
}

function requireRole(roles) {
  return function roleMiddleware(req, res, next) {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Insufficient permissions" });
    }

    next();
  };
}

async function getOrCreateManufacturerId(body) {
  const existingId = intOrNull(body.manufacturer_id);

  if (existingId) {
    return existingId;
  }

  if (!body.manufacturer_name) {
    return null;
  }

  const manufacturerId = await getNextIntegerId("manufacturers", "manufacturer_id");
  const result = await pool.query(`
    INSERT INTO manufacturers (
      manufacturer_id,
      manufacturer_name,
      address,
      phone_number,
      fax_number,
      email,
      supplier_name_and_address
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7)
    RETURNING manufacturer_id
  `, [
    manufacturerId,
    body.manufacturer_name,
    emptyToNull(body.manufacturer_address),
    emptyToNull(body.manufacturer_phone_number),
    emptyToNull(body.manufacturer_fax_number),
    emptyToNull(body.manufacturer_email),
    emptyToNull(body.supplier_name_and_address)
  ]);

  return result.rows[0].manufacturer_id;
}

async function getOrCreateCategoryId(body) {
  const existingId = intOrNull(body.category_id);

  if (existingId) {
    return existingId;
  }

  if (!body.monitor_type) {
    return null;
  }

  const categoryId = await getNextIntegerId("instrument_categories", "instrument_category_id");
  const result = await pool.query(`
    INSERT INTO instrument_categories (
      instrument_category_id,
      monitor_type,
      ranges,
      efficiency,
      resolution,
      calib_factor,
      sensitivity,
      remarks
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    RETURNING instrument_category_id
  `, [
    categoryId,
    body.monitor_type,
    emptyToNull(body.category_ranges),
    intOrNull(body.category_efficiency),
    emptyToNull(body.category_resolution),
    emptyToNull(body.category_calib_factor),
    emptyToNull(body.category_sensitivity),
    emptyToNull(body.category_remarks)
  ]);

  return result.rows[0].instrument_category_id;
}

function normalizeImportKey(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

const importAliases = {
  manufacturers: {
    manufacturer_id: ["manufacturer_id", "manf_id", "manufa_id", "manufacturerid", "manfid", "manufa"],
    manufacturer_name: ["manufacturer_name", "manufacturer", "manufa_name", "manufacturername", "manufaname"],
    address: ["address"],
    phone_number: ["phone_number", "phone_no", "phone_num", "phone_n", "phone", "telephone"],
    fax_number: ["fax_number", "fax_num", "fax_no", "fax"],
    email: ["email"],
    supplier_name_and_address: ["supplier_name_and_address", "supplier_name_and_addres", "supplier", "supplieraddress"]
  },
  categories: {
    instrument_category_id: ["instrument_category_id", "category_id", "cat_id", "catid"],
    monitor_type: ["monitor_type", "monitor", "monitor_type_name", "type"],
    ranges: ["ranges", "range"],
    efficiency: ["efficiency", "efficienc"],
    resolution: ["resolution", "resoluti"],
    calib_factor: ["calib_factor", "calib_fa", "calibration_factor"],
    sensitivity: ["sensitivity", "sensitivi"],
    remarks: ["remarks", "remark"]
  },
  instruments: {
    inst_id: ["inst_id", "instrument_id", "instid"],
    site_id: ["site_id", "siteid"],
    erc_id: ["erc_id", "ercid"],
    manufacturer_id: ["manufacturer_id", "manf_id", "manfid", "manufa"],
    category_id: ["category_id", "cat_id", "catid"],
    status_id: ["status_id", "statusid"],
    status: ["status", "status_des", "status_description"],
    checked_by_user_id: ["checked_by_user_id", "checked_by", "checkedby", "checked"],
    assigned_to_user_id: ["assigned_to_user_id", "assigned_to", "assignedto", "assigned"],
    checked_on: ["checked_on", "checkedon"],
    calibrated_on: ["calibrated_on", "calibration_on", "calibrati", "calibratedon"],
    inst_sno: ["inst_sno", "inst_sno.", "inst_serial_no", "serial_no", "serial", "instsno"],
    inst_model: ["inst_model", "model", "instmod", "inst_mod"],
    curr_location: ["curr_location", "current_location", "curr_loc", "currentloc"],
    bcode_verification: ["bcode_verification", "barcode_verification", "bcode_ve", "bcode"],
    efficiency: ["efficiency", "efficienc"],
    resolution: ["resolution", "resoluti"],
    calib_factor: ["calib_factor", "calib_fa", "calibration_factor"],
    sensitivity: ["sensitivity", "sensitivi"],
    datasheet: ["datasheet", "data_sheet"],
    remark: ["remark", "remarks"]
  }
};

function getImportValue(row, tableName, fieldName) {
  const aliases = importAliases[tableName][fieldName].map(normalizeImportKey);

  for (const [key, value] of Object.entries(row)) {
    if (aliases.includes(normalizeImportKey(key))) {
      return value;
    }
  }

  return null;
}

function inferImportTable(row, fileName, sheetName) {
  const sourceName = normalizeImportKey(`${fileName || ""} ${sheetName || ""}`);
  const hasInstrumentLocation = getImportValue(row, "instruments", "erc_id") !== null;
  const hasInstrumentIdentity = getImportValue(row, "instruments", "inst_sno") !== null
    || getImportValue(row, "instruments", "inst_model") !== null
    || getImportValue(row, "instruments", "inst_id") !== null;

  if (hasInstrumentLocation && hasInstrumentIdentity) {
    return "instruments";
  }

  if (
    getImportValue(row, "manufacturers", "manufacturer_id") !== null
    && getImportValue(row, "manufacturers", "manufacturer_name") !== null
    && !hasInstrumentLocation
  ) {
    return "manufacturers";
  }

  if (
    getImportValue(row, "categories", "instrument_category_id") !== null
    && getImportValue(row, "categories", "monitor_type") !== null
    && !hasInstrumentLocation
  ) {
    return "categories";
  }

  if (sourceName.includes("manufact")) return "manufacturers";
  if (sourceName.includes("categor") || sourceName.includes("cat")) return "categories";
  if (sourceName.includes("instrument") || sourceName.includes("inst")) return "instruments";

  const scores = Object.entries(importAliases).map(([tableName, fieldMap]) => {
    const score = Object.keys(fieldMap).reduce((total, fieldName) => {
      return getImportValue(row, tableName, fieldName) !== null ? total + 1 : total;
    }, 0);
    return { tableName, score };
  }).sort((left, right) => right.score - left.score);

  return scores[0]?.score ? scores[0].tableName : null;
}

function parseImportWorkbook(file) {
  const workbook = XLSX.read(file.buffer, {
    type: "buffer",
    cellDates: true,
    raw: false
  });
  const parsedSheets = [];

  workbook.SheetNames.forEach(sheetName => {
    const rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
      defval: "",
      raw: false
    }).filter(row => {
      return Object.values(row).some(value => emptyToNull(value) !== null);
    });

    if (!rows.length) {
      return;
    }

    const tableName = inferImportTable(rows[0], file.originalname, sheetName);

    if (!tableName) {
      parsedSheets.push({ tableName: null, sheetName, rows });
      return;
    }

    parsedSheets.push({ tableName, sheetName, rows });
  });

  return parsedSheets;
}

function importField(row, tableName, fieldName) {
  return emptyToNull(getImportValue(row, tableName, fieldName));
}

async function getStatusIdFromImport(value, client = pool) {
  const parsedId = intOrNull(value);

  if (parsedId) {
    return parsedId;
  }

  const status = emptyToNull(value);

  if (!status) {
    return null;
  }

  const result = await client.query(
    "SELECT status_id FROM instrument_status WHERE LOWER(status_des) = LOWER($1) LIMIT 1",
    [status]
  );

  if (result.rows.length) {
    return result.rows[0].status_id;
  }

  for (let attempt = 0; attempt < 3; attempt += 1) {
    const nextStatusId = await getNextIntegerId("instrument_status", "status_id", client);

    try {
      const created = await client.query(`
        INSERT INTO instrument_status (status_id, status_des)
        VALUES ($1, $2)
        RETURNING status_id
      `, [nextStatusId, status]);

      return created.rows[0].status_id;
    } catch (error) {
      if (error.code !== "23505") {
        throw error;
      }

      const retryResult = await client.query(
        "SELECT status_id FROM instrument_status WHERE LOWER(status_des) = LOWER($1) LIMIT 1",
        [status]
      );

      if (retryResult.rows.length) {
        return retryResult.rows[0].status_id;
      }
    }
  }

  throw new Error(`Could not create instrument status: ${status}`);
}

async function ensureImportedManufacturer(row, client) {
  const manufacturerId = intOrNull(importField(row, "manufacturers", "manufacturer_id"));
  const manufacturerName = importField(row, "manufacturers", "manufacturer_name");

  if (!manufacturerId && !manufacturerName) {
    return null;
  }

  if (manufacturerId) {
    const result = await client.query(`
      INSERT INTO manufacturers (
        manufacturer_id,
        manufacturer_name,
        address,
        phone_number,
        fax_number,
        email,
        supplier_name_and_address
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      ON CONFLICT (manufacturer_id) DO UPDATE SET
        manufacturer_name = COALESCE(EXCLUDED.manufacturer_name, manufacturers.manufacturer_name),
        address = COALESCE(EXCLUDED.address, manufacturers.address),
        phone_number = COALESCE(EXCLUDED.phone_number, manufacturers.phone_number),
        fax_number = COALESCE(EXCLUDED.fax_number, manufacturers.fax_number),
        email = COALESCE(EXCLUDED.email, manufacturers.email),
        supplier_name_and_address = COALESCE(EXCLUDED.supplier_name_and_address, manufacturers.supplier_name_and_address)
      RETURNING manufacturer_id
    `, [
      manufacturerId,
      manufacturerName,
      importField(row, "manufacturers", "address"),
      importField(row, "manufacturers", "phone_number"),
      importField(row, "manufacturers", "fax_number"),
      importField(row, "manufacturers", "email"),
      importField(row, "manufacturers", "supplier_name_and_address")
    ]);

    return result.rows[0].manufacturer_id;
  }

  const existing = await client.query(
    "SELECT manufacturer_id FROM manufacturers WHERE LOWER(manufacturer_name) = LOWER($1) LIMIT 1",
    [manufacturerName]
  );

  if (existing.rows.length) {
    return existing.rows[0].manufacturer_id;
  }

  const result = await client.query(`
    INSERT INTO manufacturers (
      manufacturer_name,
      address,
      phone_number,
      fax_number,
      email,
      supplier_name_and_address
    )
    VALUES ($1, $2, $3, $4, $5, $6)
    RETURNING manufacturer_id
  `, [
    manufacturerName,
    importField(row, "manufacturers", "address"),
    importField(row, "manufacturers", "phone_number"),
    importField(row, "manufacturers", "fax_number"),
    importField(row, "manufacturers", "email"),
    importField(row, "manufacturers", "supplier_name_and_address")
  ]);

  return result.rows[0].manufacturer_id;
}

async function ensureImportedCategory(row, client) {
  const categoryId = intOrNull(importField(row, "categories", "instrument_category_id"));
  const monitorType = importField(row, "categories", "monitor_type");

  if (!categoryId && !monitorType) {
    return null;
  }

  if (categoryId) {
    const result = await client.query(`
      INSERT INTO instrument_categories (
        instrument_category_id,
        monitor_type,
        ranges,
        efficiency,
        resolution,
        calib_factor,
        sensitivity,
        remarks
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      ON CONFLICT (instrument_category_id) DO UPDATE SET
        monitor_type = COALESCE(EXCLUDED.monitor_type, instrument_categories.monitor_type),
        ranges = COALESCE(EXCLUDED.ranges, instrument_categories.ranges),
        efficiency = COALESCE(EXCLUDED.efficiency, instrument_categories.efficiency),
        resolution = COALESCE(EXCLUDED.resolution, instrument_categories.resolution),
        calib_factor = COALESCE(EXCLUDED.calib_factor, instrument_categories.calib_factor),
        sensitivity = COALESCE(EXCLUDED.sensitivity, instrument_categories.sensitivity),
        remarks = COALESCE(EXCLUDED.remarks, instrument_categories.remarks)
      RETURNING instrument_category_id
    `, [
      categoryId,
      monitorType,
      importField(row, "categories", "ranges"),
      intOrNull(importField(row, "categories", "efficiency")),
      importField(row, "categories", "resolution"),
      importField(row, "categories", "calib_factor"),
      importField(row, "categories", "sensitivity"),
      importField(row, "categories", "remarks")
    ]);

    return result.rows[0].instrument_category_id;
  }

  const existing = await client.query(
    "SELECT instrument_category_id FROM instrument_categories WHERE LOWER(monitor_type) = LOWER($1) LIMIT 1",
    [monitorType]
  );

  if (existing.rows.length) {
    return existing.rows[0].instrument_category_id;
  }

  const result = await client.query(`
    INSERT INTO instrument_categories (
      monitor_type,
      ranges,
      efficiency,
      resolution,
      calib_factor,
      sensitivity,
      remarks
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7)
    RETURNING instrument_category_id
  `, [
    monitorType,
    importField(row, "categories", "ranges"),
    intOrNull(importField(row, "categories", "efficiency")),
    importField(row, "categories", "resolution"),
    importField(row, "categories", "calib_factor"),
    importField(row, "categories", "sensitivity"),
    importField(row, "categories", "remarks")
  ]);

  return result.rows[0].instrument_category_id;
}

async function resolveImportErcId(row, siteId, client) {
  const importedErcId = intOrNull(importField(row, "instruments", "erc_id"));

  if (importedErcId) {
    const existing = await client.query(
      "SELECT erc_id FROM erc_locations WHERE erc_id = $1",
      [importedErcId]
    );

    if (existing.rows.length) {
      return importedErcId;
    }
  }

  const locations = await client.query(
    "SELECT erc_id FROM erc_locations WHERE site_id = $1 ORDER BY erc_id",
    [siteId]
  );

  return locations.rows.length === 1 ? locations.rows[0].erc_id : null;
}

async function importInstrumentRow(row, siteId, client) {
  const ercId = await resolveImportErcId(row, siteId, client);

  if (!ercId) {
    return { skipped: true, reason: "Missing or unknown erc_id" };
  }

  const data = {
    inst_id: intOrNull(importField(row, "instruments", "inst_id")),
    erc_id: ercId,
    manufacturer_id: intOrNull(importField(row, "instruments", "manufacturer_id")),
    category_id: intOrNull(importField(row, "instruments", "category_id")),
    status_id: intOrNull(importField(row, "instruments", "status_id")) || await getStatusIdFromImport(importField(row, "instruments", "status"), client),
    checked_by_user_id: intOrNull(importField(row, "instruments", "checked_by_user_id")),
    assigned_to_user_id: intOrNull(importField(row, "instruments", "assigned_to_user_id")),
    checked_on: dateOrNull(importField(row, "instruments", "checked_on")),
    calibrated_on: dateOrNull(importField(row, "instruments", "calibrated_on")),
    inst_sno: importField(row, "instruments", "inst_sno"),
    inst_model: importField(row, "instruments", "inst_model"),
    curr_location: importField(row, "instruments", "curr_location"),
    bcode_verification: importField(row, "instruments", "bcode_verification"),
    efficiency: intOrNull(importField(row, "instruments", "efficiency")),
    resolution: importField(row, "instruments", "resolution"),
    calib_factor: importField(row, "instruments", "calib_factor"),
    sensitivity: importField(row, "instruments", "sensitivity"),
    datasheet: importField(row, "instruments", "datasheet"),
    remark: importField(row, "instruments", "remark")
  };

  if (data.manufacturer_id) {
    await client.query(`
      INSERT INTO manufacturers (manufacturer_id)
      VALUES ($1)
      ON CONFLICT (manufacturer_id) DO NOTHING
    `, [data.manufacturer_id]);
  }

  if (data.category_id) {
    await client.query(`
      INSERT INTO instrument_categories (instrument_category_id)
      VALUES ($1)
      ON CONFLICT (instrument_category_id) DO NOTHING
    `, [data.category_id]);
  }

  for (const userField of ["checked_by_user_id", "assigned_to_user_id"]) {
    if (!data[userField]) {
      continue;
    }

    const userResult = await client.query(
      "SELECT id FROM users WHERE id = $1",
      [data[userField]]
    );

    if (!userResult.rows.length) {
      data[userField] = null;
    }
  }

  const validationError = validateInstrumentImportPayload(data);

  if (validationError) {
    return { skipped: true, reason: validationError };
  }

  const location = await client.query(
    "SELECT site_id FROM erc_locations WHERE erc_id = $1",
    [data.erc_id]
  );
  const resolvedSiteId = intOrNull(location.rows[0]?.site_id) || intOrNull(siteId);
  const values = [
    resolvedSiteId,
    data.erc_id,
    data.manufacturer_id,
    data.category_id,
    data.status_id,
    data.checked_by_user_id,
    data.assigned_to_user_id,
    data.checked_on,
    data.calibrated_on,
    data.inst_sno,
    data.inst_model,
    data.curr_location,
    data.bcode_verification,
    data.efficiency,
    data.resolution,
    data.calib_factor,
    data.sensitivity,
    data.datasheet,
    data.remark
  ];

  const existing = data.inst_sno ? await client.query(`
    SELECT inst_id
    FROM instruments
    WHERE erc_id = $1
      AND LOWER(inst_sno) = LOWER($2)
      AND LOWER(inst_model) = LOWER($3)
    LIMIT 1
  `, [data.erc_id, data.inst_sno, data.inst_model]) : { rows: [] };

  if (existing.rows.length) {
    await client.query(`
      UPDATE instruments
      SET
        site_id = $1,
        erc_id = $2,
        manufacturer_id = $3,
        category_id = $4,
        status_id = $5,
        checked_by_user_id = $6,
        assigned_to_user_id = $7,
        checked_on = $8,
        calibrated_on = $9,
        inst_sno = $10,
        inst_model = $11,
        curr_location = $12,
        bcode_verification = $13,
        efficiency = $14,
        resolution = $15,
        calib_factor = $16,
        sensitivity = $17,
        datasheet = $18,
        remark = $19,
        updated_at = NOW()
      WHERE inst_id = $20
    `, [...values, existing.rows[0].inst_id]);

    return { updated: true };
  }

  let insertId = data.inst_id;

  if (insertId) {
    const idResult = await client.query(
      "SELECT inst_id FROM instruments WHERE inst_id = $1",
      [insertId]
    );

    if (idResult.rows.length) {
      insertId = null;
    }
  }

  if (!insertId) {
    insertId = await getNextIntegerId("instruments", "inst_id", client);
  }

  await client.query(`
    INSERT INTO instruments (
      inst_id,
      site_id,
      erc_id,
      manufacturer_id,
      category_id,
      status_id,
      checked_by_user_id,
      assigned_to_user_id,
      checked_on,
      calibrated_on,
      inst_sno,
      inst_model,
      curr_location,
      bcode_verification,
      efficiency,
      resolution,
      calib_factor,
      sensitivity,
      datasheet,
      remark
    )
    VALUES ($20, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)
  `, [...values, insertId]);

  return { inserted: true };
}

async function syncInstrumentIdentitySequence(client) {
  await client.query(`
    SELECT setval(
      pg_get_serial_sequence('instruments', 'inst_id'),
      GREATEST((SELECT COALESCE(MAX(inst_id), 0) FROM instruments), 1),
      TRUE
    )
    WHERE pg_get_serial_sequence('instruments', 'inst_id') IS NOT NULL
  `);
}

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    await ensureDemoAdminUser();

    const result = await pool.query(
      `SELECT id, name, email, password_hash, role, emp_no, designation, section, division, location
       FROM users
       WHERE lower(email) = lower($1)`,
      [email]
    );

    if (!result.rows.length) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const user = result.rows[0];
    const passwordMatches = await bcrypt.compare(password, user.password_hash);

    if (!passwordMatches) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const safeUser = publicUser(user);
    res.json({
      token: createToken(safeUser),
      user: safeUser
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/signup", async (req, res, next) => {
  try {
    const {
      name,
      email,
      password,
      emp_no,
      designation,
      section,
      division,
      location
    } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const result = await pool.query(`
      INSERT INTO users (
        name,
        email,
        password_hash,
        role,
        emp_no,
        designation,
        section,
        division,
        location
      )
      VALUES ($1, lower($2), $3, 'viewer', $4, $5, $6, $7, $8)
      RETURNING id, name, email, role, emp_no, designation, section, division, location
    `, [
      name || email,
      email,
      passwordHash,
      intOrNull(emp_no),
      emptyToNull(designation),
      emptyToNull(section),
      emptyToNull(division),
      emptyToNull(location)
    ]);

    const safeUser = publicUser(result.rows[0]);
    res.status(201).json({
      token: createToken(safeUser),
      user: safeUser
    });
  } catch (error) {
    if (error.code === "23505") {
      return res.status(400).json({ error: "Email or employee number already exists" });
    }

    next(error);
  }
});

app.get("/api/auth/me", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, name, email, role, emp_no, designation, section, division, location
       FROM users
       WHERE id = $1`,
      [req.user.id]
    );

    if (!result.rows.length) {
      return res.status(401).json({ error: "Invalid or expired login" });
    }

    res.json({ user: publicUser(result.rows[0]) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/logout", (req, res) => {
  res.json({ status: "ok" });
});

// public site markers
app.get("/api/sites", async (req, res) => {
  const result = await pool.query(`
    SELECT
      id,
      name,
      folder,
      site_kind,
      state,
      zone,
      reactor_type,
      installed_capacity_mw,
      units,
      operator,
      status,
      detail_status,
      description,
      latitude AS lat,
      longitude AS lng
    FROM sites
    ORDER BY id
  `);

  res.json(result.rows);
});

// protected site detail
app.get("/api/sites/:id", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT
      id,
      name,
      folder,
      site_kind,
      state,
      zone,
      reactor_type,
      installed_capacity_mw,
      units,
      operator,
      status,
      detail_status,
      description,
      latitude AS lat,
      longitude AS lng
    FROM sites
    WHERE id = $1
  `, [req.params.id]);

  if (!result.rows.length) {
    return res.status(404).json({ error: "Site not found" });
  }

  res.json(result.rows[0]);
});

// protected layer list
app.get("/api/sites/:id/layers", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT
      lc.layer_key AS key,
      lc.display_name AS name,
      lc.category,
      lc.geometry_type
    FROM site_layers sl
    JOIN layer_catalog lc ON lc.layer_key = sl.layer_key
    WHERE sl.site_id = $1 AND sl.is_enabled = TRUE
    ORDER BY lc.category, lc.display_name
  `, [req.params.id]);

  res.json(result.rows);
});

// protected GeoJSON layer
app.get("/api/sites/:id/layers/:layerKey", requireAuth, async (req, res) => {
  const { id, layerKey } = req.params;

  const result = await pool.query(`
    SELECT jsonb_build_object(
      'type', 'FeatureCollection',
      'features', COALESCE(jsonb_agg(
        jsonb_build_object(
          'type', 'Feature',
          'properties', properties,
          'geometry', ST_AsGeoJSON(geom)::jsonb
        )
      ), '[]'::jsonb)
    ) AS geojson
    FROM geo_features
    WHERE site_id = $1 AND layer_key = $2
  `, [id, layerKey]);

  res.json(result.rows[0].geojson);
});

app.get("/api/sites/:id/contacts", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT c.*
    FROM contacts c
    ORDER BY c.contact_category, c.dae_unit, c.name, c.id
  `);

  res.json(result.rows);
});

app.get("/api/rerc-units", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT DISTINCT ON (s.id)
      s.id AS site_id,
      CASE WHEN s.operator = 'BARC / VECC' THEN 'VECC' ELSE s.operator END AS dae_unit,
      COALESCE(e.location, REGEXP_REPLACE(s.name, '^DAE-RERC Unit - [^-]+\\s*', '')) AS city,
      e.std_code
    FROM sites s
    LEFT JOIN erc_locations e ON e.site_id = s.id
    WHERE s.site_kind = 'rerc'
      AND s.id >= 101
    ORDER BY s.id, e.erc_id
  `);

  res.json(result.rows);
});

app.post("/api/sites/:id/contacts", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const siteId = req.params.id;
  const site = await getSite(siteId);

  if (!site) {
    return res.status(404).json({ error: "Site not found" });
  }

  const contact = normalizeContactPayload(req.body, site);
  const validationError = validateContact(contact);

  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  const duplicate = await findDuplicateContact(siteId, contact);

  if (duplicate) {
    await linkContactToMatchingRercSites(duplicate.id, duplicate);

    return res.status(200).json(duplicate);
  }

  const result = await pool.query(`
    INSERT INTO contacts (
      contact_category,
      dae_unit,
      std_code,
      unit,
      name,
      designation,
      office_tel_fax,
      head_tel_fax,
      residence_mobile,
      email,
      email_2,
      email_3,
      mobile_2,
      fax_no,
      address,
      remarks,
      applies_to_all_sites
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
    RETURNING *
  `, [
    contact.contact_category,
    contact.dae_unit,
    contact.std_code,
    contact.unit,
    contact.name,
    contact.designation,
    contact.office_tel_fax,
    contact.head_tel_fax,
    contact.residence_mobile,
    contact.email,
    contact.email_2,
    contact.email_3,
    contact.mobile_2,
    contact.fax_no,
    contact.address,
    contact.remarks,
    contact.applies_to_all_sites
  ]);

  await linkContactToMatchingRercSites(result.rows[0].id, contact);

  res.status(201).json(result.rows[0]);
});

app.put("/api/contacts/:id", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const targetSiteId = intOrNull(req.body.site_id);
  const targetSite = targetSiteId ? await getSite(targetSiteId) : null;
  const contact = normalizeContactPayload(req.body, targetSite);
  const validationError = validateContact(contact);

  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  if (targetSiteId) {
    const duplicate = await findDuplicateContact(targetSiteId, contact, req.params.id);

    if (duplicate) {
      return res.status(409).json({ error: "A matching contact already exists for this site." });
    }
  }

  const result = await pool.query(`
    UPDATE contacts
    SET
      contact_category = $1,
      dae_unit = $2,
      std_code = $3,
      unit = $4,
      name = $5,
      designation = $6,
      office_tel_fax = $7,
      head_tel_fax = $8,
      residence_mobile = $9,
      email = $10,
      email_2 = $11,
      email_3 = $12,
      mobile_2 = $13,
      fax_no = $14,
      address = $15,
      remarks = $16,
      applies_to_all_sites = $17,
      updated_at = NOW()
    WHERE id = $18
    RETURNING *
  `, [
    contact.contact_category,
    contact.dae_unit,
    contact.std_code,
    contact.unit,
    contact.name,
    contact.designation,
    contact.office_tel_fax,
    contact.head_tel_fax,
    contact.residence_mobile,
    contact.email,
    contact.email_2,
    contact.email_3,
    contact.mobile_2,
    contact.fax_no,
    contact.address,
    contact.remarks,
    contact.applies_to_all_sites,
    req.params.id
  ]);

  if (!result.rows.length) {
    return res.status(404).json({ error: "Contact not found" });
  }

  await linkContactToMatchingRercSites(result.rows[0].id, contact);

  res.json(result.rows[0]);
});

app.delete("/api/contacts/:id", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const result = await pool.query(
    "DELETE FROM contacts WHERE id = $1 RETURNING id",
    [req.params.id]
  );

  if (!result.rows.length) {
    return res.status(404).json({ error: "Contact not found" });
  }

  res.json({ status: "deleted" });
});

app.get("/api/sites/:id/erc-locations", requireAuth, async (req, res) => {
  await ensureRercInstrumentLocation(req.params.id);

  const result = await pool.query(`
    SELECT *
    FROM erc_locations
    WHERE site_id = $1
    ORDER BY location, unit, erc_id
  `, [req.params.id]);

  res.json(result.rows);
});

app.post("/api/sites/:id/erc-locations", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const ercId = await getNextIntegerId("erc_locations", "erc_id");
  const result = await pool.query(`
    INSERT INTO erc_locations (
      erc_id,
      site_id,
      erc_state,
      location,
      unit,
      std_code,
      coordinator,
      phone_number_o,
      phone_number_h,
      mobile_number
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
    RETURNING *
  `, [
    ercId,
    req.params.id,
    emptyToNull(req.body.erc_state),
    emptyToNull(req.body.location),
    emptyToNull(req.body.unit),
    emptyToNull(req.body.std_code),
    emptyToNull(req.body.coordinator),
    emptyToNull(req.body.phone_number_o),
    emptyToNull(req.body.phone_number_h),
    emptyToNull(req.body.mobile_number)
  ]);

  res.status(201).json(result.rows[0]);
});

app.put("/api/erc-locations/:id", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const result = await pool.query(`
    UPDATE erc_locations
    SET
      erc_state = $1,
      location = $2,
      unit = $3,
      std_code = $4,
      coordinator = $5,
      phone_number_o = $6,
      phone_number_h = $7,
      mobile_number = $8
    WHERE erc_id = $9
    RETURNING *
  `, [
    emptyToNull(req.body.erc_state),
    emptyToNull(req.body.location),
    emptyToNull(req.body.unit),
    emptyToNull(req.body.std_code),
    emptyToNull(req.body.coordinator),
    emptyToNull(req.body.phone_number_o),
    emptyToNull(req.body.phone_number_h),
    emptyToNull(req.body.mobile_number),
    req.params.id
  ]);

  if (!result.rows.length) {
    return res.status(404).json({ error: "ERC location not found" });
  }

  res.json(result.rows[0]);
});

app.delete("/api/erc-locations/:id", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  let result;

  try {
    result = await pool.query(
      "DELETE FROM erc_locations WHERE erc_id = $1 RETURNING erc_id",
      [req.params.id]
    );
  } catch (error) {
    if (error.code === "23503") {
      return res.status(400).json({ error: "Delete instruments under this ERC location before deleting the ERC location." });
    }

    throw error;
  }

  if (!result.rows.length) {
    return res.status(404).json({ error: "ERC location not found" });
  }

  res.json({ status: "deleted" });
});

app.get("/api/instrument-lookups", requireAuth, async (req, res) => {
  const [ercLocations, manufacturers, categories, statuses, users] = await Promise.all([
    pool.query("SELECT * FROM erc_locations ORDER BY site_id, location, unit, erc_id"),
    pool.query("SELECT * FROM manufacturers ORDER BY manufacturer_name, manufacturer_id"),
    pool.query("SELECT * FROM instrument_categories ORDER BY monitor_type, instrument_category_id"),
    pool.query("SELECT * FROM instrument_status ORDER BY status_id"),
    pool.query("SELECT id, name, email, emp_no, first_name, last_name FROM users ORDER BY name, id")
  ]);

  res.json({
    erc_locations: ercLocations.rows,
    manufacturers: manufacturers.rows,
    categories: categories.rows,
    statuses: statuses.rows,
    users: users.rows
  });
});

app.get("/api/sites/:id/instruments", requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT
      i.*,
      COALESCE(i.site_id, e.site_id) AS site_id,
      e.location AS erc_location,
      e.unit AS erc_unit,
      e.erc_state,
      m.manufacturer_name,
      c.monitor_type,
      s.status_des,
      checked_user.name AS checked_by_name,
      assigned_user.name AS assigned_to_name
    FROM instruments i
    JOIN erc_locations e ON e.erc_id = i.erc_id
    LEFT JOIN manufacturers m ON m.manufacturer_id = i.manufacturer_id
    LEFT JOIN instrument_categories c ON c.instrument_category_id = i.category_id
    LEFT JOIN instrument_status s ON s.status_id = i.status_id
    LEFT JOIN users checked_user ON checked_user.id = i.checked_by_user_id
    LEFT JOIN users assigned_user ON assigned_user.id = i.assigned_to_user_id
    WHERE COALESCE(i.site_id, e.site_id) = $1
    ORDER BY i.inst_sno, i.inst_id
  `, [req.params.id]);

  res.json(result.rows);
});

app.post("/api/sites/:id/instruments", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  await ensureRercInstrumentLocation(req.params.id);

  const validationError = validateInstrumentPayload(req.body);

  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  const ercResult = await pool.query(
    "SELECT erc_id, site_id FROM erc_locations WHERE erc_id = $1",
    [req.body.erc_id]
  );

  if (!ercResult.rows.length) {
    return res.status(400).json({ error: "Select a valid instrument location before saving the instrument." });
  }

  const manufacturerId = await getOrCreateManufacturerId(req.body);
  const categoryId = await getOrCreateCategoryId(req.body);

  const result = await pool.query(`
    INSERT INTO instruments (
      site_id,
      erc_id,
      manufacturer_id,
      category_id,
      status_id,
      checked_by_user_id,
      assigned_to_user_id,
      checked_on,
      calibrated_on,
      inst_sno,
      inst_model,
      curr_location,
      bcode_verification,
      efficiency,
      resolution,
      calib_factor,
      sensitivity,
      datasheet,
      remark
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)
    RETURNING *
  `, [
    intOrNull(ercResult.rows[0].site_id) || intOrNull(req.params.id),
    intOrNull(req.body.erc_id),
    manufacturerId,
    categoryId,
    intOrNull(req.body.status_id),
    intOrNull(req.body.checked_by_user_id),
    intOrNull(req.body.assigned_to_user_id),
    emptyToNull(req.body.checked_on),
    emptyToNull(req.body.calibrated_on),
    emptyToNull(req.body.inst_sno),
    emptyToNull(req.body.inst_model),
    emptyToNull(req.body.curr_location),
    emptyToNull(req.body.bcode_verification),
    intOrNull(req.body.efficiency),
    emptyToNull(req.body.resolution),
    emptyToNull(req.body.calib_factor),
    emptyToNull(req.body.sensitivity),
    emptyToNull(req.body.datasheet),
    emptyToNull(req.body.remark)
  ]);

  res.status(201).json(result.rows[0]);
});

app.post("/api/sites/:id/instruments/import", requireAuth, requireRole(["admin", "editor"]), upload.array("files", 8), async (req, res, next) => {
  const client = await pool.connect();

  try {
    await ensureRercInstrumentLocation(req.params.id);

    if (!req.files || !req.files.length) {
      return res.status(400).json({ error: "Upload at least one CSV or Excel file." });
    }

    const parsedSheets = req.files.flatMap(file => parseImportWorkbook(file));
    const unknownSheets = parsedSheets.filter(sheet => !sheet.tableName);

    if (unknownSheets.length) {
      return res.status(400).json({
        error: `Could not identify table columns in: ${unknownSheets.map(sheet => sheet.sheetName).join(", ")}`
      });
    }

    const groups = parsedSheets.reduce((accumulator, sheet) => {
      accumulator[sheet.tableName].push(...sheet.rows);
      return accumulator;
    }, {
      manufacturers: [],
      categories: [],
      instruments: []
    });

    await client.query("BEGIN");

    for (const row of groups.manufacturers) {
      await ensureImportedManufacturer(row, client);
    }

    for (const row of groups.categories) {
      await ensureImportedCategory(row, client);
    }

    let insertedInstruments = 0;
    let updatedInstruments = 0;
    const skippedRows = [];

    for (const row of groups.instruments) {
      const result = await importInstrumentRow(row, req.params.id, client);

      if (result.inserted) {
        insertedInstruments += 1;
      } else if (result.updated) {
        updatedInstruments += 1;
      } else {
        skippedRows.push(result.reason || "Row skipped");
      }
    }

    await syncInstrumentIdentitySequence(client);
    await client.query("COMMIT");

    res.status(201).json({
      imported: {
        manufacturers: groups.manufacturers.length,
        categories: groups.categories.length,
        instruments: insertedInstruments + updatedInstruments
      },
      inserted: {
        instruments: insertedInstruments
      },
      updated: {
        instruments: updatedInstruments
      },
      skipped: skippedRows.length,
      skipped_reasons: skippedRows.slice(0, 10)
    });
  } catch (error) {
    await client.query("ROLLBACK");
    next(error);
  } finally {
    client.release();
  }
});

app.put("/api/instruments/:id", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const validationError = validateInstrumentPayload(req.body);

  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  const ercResult = await pool.query(
    "SELECT erc_id FROM erc_locations WHERE erc_id = $1",
    [req.body.erc_id]
  );

  if (!ercResult.rows.length) {
    return res.status(400).json({ error: "Select a valid instrument location before saving the instrument." });
  }

  const manufacturerId = await getOrCreateManufacturerId(req.body);
  const categoryId = await getOrCreateCategoryId(req.body);

  const result = await pool.query(`
    UPDATE instruments
    SET
      site_id = (SELECT site_id FROM erc_locations WHERE erc_id = $1),
      erc_id = $1,
      manufacturer_id = $2,
      category_id = $3,
      status_id = $4,
      checked_by_user_id = $5,
      assigned_to_user_id = $6,
      checked_on = $7,
      calibrated_on = $8,
      inst_sno = $9,
      inst_model = $10,
      curr_location = $11,
      bcode_verification = $12,
      efficiency = $13,
      resolution = $14,
      calib_factor = $15,
      sensitivity = $16,
      datasheet = $17,
      remark = $18,
      updated_at = NOW()
    WHERE inst_id = $19
    RETURNING *
  `, [
    intOrNull(req.body.erc_id),
    manufacturerId,
    categoryId,
    intOrNull(req.body.status_id),
    intOrNull(req.body.checked_by_user_id),
    intOrNull(req.body.assigned_to_user_id),
    emptyToNull(req.body.checked_on),
    emptyToNull(req.body.calibrated_on),
    emptyToNull(req.body.inst_sno),
    emptyToNull(req.body.inst_model),
    emptyToNull(req.body.curr_location),
    emptyToNull(req.body.bcode_verification),
    intOrNull(req.body.efficiency),
    emptyToNull(req.body.resolution),
    emptyToNull(req.body.calib_factor),
    emptyToNull(req.body.sensitivity),
    emptyToNull(req.body.datasheet),
    emptyToNull(req.body.remark),
    req.params.id
  ]);

  if (!result.rows.length) {
    return res.status(404).json({ error: "Instrument not found" });
  }

  res.json(result.rows[0]);
});

app.delete("/api/instruments/:id", requireAuth, requireRole(["admin", "editor"]), async (req, res) => {
  const result = await pool.query(
    "DELETE FROM instruments WHERE inst_id = $1 RETURNING inst_id",
    [req.params.id]
  );

  if (!result.rows.length) {
    return res.status(404).json({ error: "Instrument not found" });
  }

  res.json({ status: "deleted" });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || "Internal server error" });
});

app.listen(config.port, () => {
  console.log(`Server running at http://localhost:${config.port}`);
});
