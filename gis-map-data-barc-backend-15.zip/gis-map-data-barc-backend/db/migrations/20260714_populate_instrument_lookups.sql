BEGIN;

DELETE FROM manufacturers
WHERE manufacturer_id = 1001
  AND manufacturer_name = 'Demo Instruments Pvt Ltd'
  AND NOT EXISTS (
    SELECT 1
    FROM instruments
    WHERE instruments.manufacturer_id = manufacturers.manufacturer_id
  );

DELETE FROM instrument_categories
WHERE instrument_category_id = 1001
  AND monitor_type = 'Survey Meter'
  AND NOT EXISTS (
    SELECT 1
    FROM instruments
    WHERE instruments.category_id = instrument_categories.instrument_category_id
  );

INSERT INTO instrument_categories (
  instrument_category_id,
  monitor_type,
  ranges,
  efficiency,
  resolution,
  calib_factor,
  sensitivity,
  remarks
) VALUES
  (1, 'Radiation', NULL, NULL, NULL, NULL, NULL, NULL),
  (2, 'Alpha Con', NULL, NULL, NULL, NULL, NULL, NULL),
  (3, 'Beta-Gam', NULL, NULL, NULL, NULL, NULL, NULL),
  (4, 'Portable S', NULL, NULL, NULL, NULL, NULL, NULL),
  (5, 'Dosimeter', NULL, NULL, NULL, NULL, NULL, NULL),
  (6, 'Air Sample', NULL, NULL, NULL, NULL, NULL, NULL),
  (7, 'Alpha Cou', NULL, NULL, NULL, NULL, NULL, NULL),
  (8, 'Beta-Gam', NULL, NULL, NULL, NULL, NULL, NULL),
  (9, 'Others', NULL, NULL, NULL, NULL, NULL, NULL)
ON CONFLICT (instrument_category_id) DO UPDATE SET
  monitor_type = EXCLUDED.monitor_type,
  ranges = EXCLUDED.ranges,
  efficiency = EXCLUDED.efficiency,
  resolution = EXCLUDED.resolution,
  calib_factor = EXCLUDED.calib_factor,
  sensitivity = EXCLUDED.sensitivity,
  remarks = EXCLUDED.remarks;

INSERT INTO manufacturers (
  manufacturer_id,
  manufacturer_name,
  address,
  phone_number,
  fax_number,
  email,
  supplier_name_and_address
) VALUES
  (1, 'PLA Electr', 'M/s PLA E', '022251168', '2.23E+09', 'pla@plaelectro.com', NULL),
  (2, 'Pulsecho', 'No 110, Ni', '022240710', '2.22E+09', 'pulsecho@vsnl.com', NULL),
  (3, 'Mirion Te', 'M/s Mirion Technologies,Radiation Moni', NULL, NULL, NULL, 'Local Supplier: Electronic Enterprises (India) Pvt. Ltd.216, Regal Industrial Estate, Acharya Donde Marg, Post Bag No. 6367, Sewri, Mumbai-400015'),
  (4, 'Electronic', 'Electronic', '022241346', '022241333', 'info@eeipl.in', NULL),
  (5, 'Intech Do', 'M/s Intec', '011268164', '1.14E+09', 'sales@intechdosimeters.com', NULL),
  (6, 'Polimaste', '51, Skorin', '3.75E+11', '3.75E+11', 'polimaster@polimaster.com,', NULL),
  (7, 'Spectra Lab', NULL, NULL, NULL, NULL, NULL),
  (8, 'Automess', 'Daimlerst', '4.96E+11', '4.96E+11', 'info@automess.de', NULL),
  (9, 'Atomtex', '5 Gikalo St', '3.75E+11', '3.75E+11', 'info@atomtex.com, info@atomtex.info', NULL),
  (10, 'Staplex', 'The StaplexÂ° Company, 777 Fifth Avenue, Brooklyn, New York 11232-1695,USA', NULL, NULL, NULL, NULL),
  (11, 'Arrow Tech. Inc', NULL, NULL, NULL, NULL, NULL),
  (12, 'Thermo S', 'Thermo Fi', '499131998', '4.99E+11', 'info.rmp.c', 'M/s Sweta Electronics, Sai Prashad, HS Plot No-81, Rajyo Padhey Nagar, Kollapur, Maharashtra-416012'),
  (13, 'F&J Speci', NULL, NULL, NULL, NULL, NULL),
  (14, 'Para Elect', NULL, NULL, NULL, NULL, NULL),
  (15, 'PEA Electr', NULL, NULL, NULL, NULL, NULL),
  (16, 'MGP Instr', NULL, NULL, NULL, NULL, NULL),
  (17, 'Mega Loud', NULL, NULL, NULL, NULL, NULL),
  (18, 'Carlton', NULL, NULL, NULL, NULL, NULL)
ON CONFLICT (manufacturer_id) DO UPDATE SET
  manufacturer_name = EXCLUDED.manufacturer_name,
  address = EXCLUDED.address,
  phone_number = EXCLUDED.phone_number,
  fax_number = EXCLUDED.fax_number,
  email = EXCLUDED.email,
  supplier_name_and_address = EXCLUDED.supplier_name_and_address;

COMMIT;
