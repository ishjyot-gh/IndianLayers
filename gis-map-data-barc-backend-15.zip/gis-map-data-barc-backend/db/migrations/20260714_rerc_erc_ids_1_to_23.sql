WITH rerc_map(old_erc_id, new_erc_id, site_id) AS (
  VALUES
    (1101, 1, 101),
    (1102, 2, 102),
    (1103, 3, 103),
    (1104, 4, 104),
    (1105, 5, 105),
    (1106, 6, 106),
    (1107, 7, 107),
    (1108, 8, 108),
    (1109, 9, 109),
    (1110, 10, 110),
    (1111, 11, 111),
    (1112, 12, 112),
    (1113, 13, 113),
    (1114, 14, 114),
    (1115, 15, 115),
    (1116, 16, 116),
    (1117, 17, 117),
    (1118, 18, 118),
    (1119, 19, 119),
    (1120, 20, 120),
    (1121, 21, 121),
    (1122, 22, 122),
    (1123, 23, 123)
)
INSERT INTO erc_locations (
  erc_id,
  site_id,
  erc_state,
  location,
  unit,
  std_code,
  coordinator,
  phone_number_o,
  phone_number_h,
  mobile_number
)
SELECT
  m.new_erc_id,
  e.site_id,
  e.erc_state,
  e.location,
  e.unit,
  e.std_code,
  e.coordinator,
  e.phone_number_o,
  e.phone_number_h,
  e.mobile_number
FROM rerc_map m
JOIN erc_locations e ON e.erc_id = m.old_erc_id
WHERE NOT EXISTS (
  SELECT 1
  FROM erc_locations existing
  WHERE existing.erc_id = m.new_erc_id
);

WITH rerc_map(old_erc_id, new_erc_id) AS (
  VALUES
    (1101, 1),
    (1102, 2),
    (1103, 3),
    (1104, 4),
    (1105, 5),
    (1106, 6),
    (1107, 7),
    (1108, 8),
    (1109, 9),
    (1110, 10),
    (1111, 11),
    (1112, 12),
    (1113, 13),
    (1114, 14),
    (1115, 15),
    (1116, 16),
    (1117, 17),
    (1118, 18),
    (1119, 19),
    (1120, 20),
    (1121, 21),
    (1122, 22),
    (1123, 23)
)
UPDATE instruments i
SET
  erc_id = m.new_erc_id,
  site_id = e.site_id,
  updated_at = NOW()
FROM rerc_map m
JOIN erc_locations e ON e.erc_id = m.new_erc_id
WHERE i.erc_id = m.old_erc_id;

WITH rerc_map(old_erc_id) AS (
  VALUES
    (1101),
    (1102),
    (1103),
    (1104),
    (1105),
    (1106),
    (1107),
    (1108),
    (1109),
    (1110),
    (1111),
    (1112),
    (1113),
    (1114),
    (1115),
    (1116),
    (1117),
    (1118),
    (1119),
    (1120),
    (1121),
    (1122),
    (1123)
)
DELETE FROM erc_locations e
USING rerc_map m
WHERE e.erc_id = m.old_erc_id;
