from pathlib import Path
from xml.sax.saxutils import escape


OUT = Path(__file__).resolve().parent / "database_erd.svg"

W = 1900
H = 1380


TABLES = {
    "users": {
        "x": 1550,
        "y": 195,
        "w": 300,
        "cols": [
            ("PK", "id integer"),
            ("UQ", "email varchar unique"),
            ("UQ", "emp_no integer unique"),
            ("", "name varchar not null"),
            ("", "password_hash text not null"),
            ("", "role varchar default viewer"),
            ("", "created_at timestamp"),
            ("", "first_name / last_name"),
            ("", "user_type / designation"),
            ("", "section / division / location / extension"),
        ],
    },
    "sites": {
        "x": 675,
        "y": 155,
        "w": 430,
        "cols": [
            ("PK", "id integer"),
            ("UQ", "folder varchar unique not null"),
            ("", "name varchar not null"),
            ("", "site_kind text default npp"),
            ("", "state / zone / operator / status"),
            ("", "reactor_type / installed_capacity_mw / units"),
            ("", "description / detail_status"),
            ("", "latitude / longitude"),
            ("", "geom geometry"),
            ("NOTE", "Seeded: NPP 1-7, DAE-RERC 101-123"),
        ],
    },
    "erc_locations": {
        "x": 690,
        "y": 600,
        "w": 410,
        "cols": [
            ("PK", "erc_id integer"),
            ("FK", "site_id -> sites.id ON DELETE SET NULL"),
            ("", "erc_state / location / unit"),
            ("", "std_code"),
            ("", "coordinator"),
            ("", "phone_number_o / phone_number_h"),
            ("", "mobile_number"),
            ("NOTE", "Current RERC mapping: erc_id 1..23"),
        ],
    },
    "instruments": {
        "x": 1190,
        "y": 555,
        "w": 480,
        "cols": [
            ("PK", "inst_id bigint"),
            ("FK", "site_id -> sites.id ON DELETE CASCADE"),
            ("FK", "erc_id -> erc_locations.erc_id RESTRICT"),
            ("FK", "manufacturer_id -> manufacturers SET NULL"),
            ("FK", "category_id -> instrument_categories SET NULL"),
            ("FK", "status_id -> instrument_status SET NULL"),
            ("FK", "checked_by_user_id -> users SET NULL"),
            ("FK", "assigned_to_user_id -> users SET NULL"),
            ("", "checked_on / calibrated_on"),
            ("", "inst_sno nullable / inst_model"),
            ("", "curr_location / bcode_verification"),
            ("", "efficiency / resolution / calib_factor"),
            ("", "sensitivity / datasheet / remark"),
            ("", "created_at / updated_at"),
            ("NOTE", "Import can insert without serial; manual form validates it."),
        ],
    },
    "manufacturers": {
        "x": 1190,
        "y": 155,
        "w": 315,
        "cols": [
            ("PK", "manufacturer_id integer"),
            ("", "manufacturer_name varchar"),
            ("", "address / phone_number / fax_number"),
            ("", "email"),
            ("", "supplier_name_and_address"),
        ],
    },
    "instrument_categories": {
        "x": 1190,
        "y": 340,
        "w": 315,
        "cols": [
            ("PK", "instrument_category_id integer"),
            ("", "monitor_type"),
            ("", "ranges / efficiency"),
            ("", "resolution / calib_factor / sensitivity"),
            ("", "remarks"),
        ],
    },
    "instrument_status": {
        "x": 1550,
        "y": 430,
        "w": 300,
        "cols": [
            ("PK", "status_id integer"),
            ("", "status_des varchar"),
        ],
    },
    "contacts": {
        "x": 55,
        "y": 155,
        "w": 500,
        "cols": [
            ("PK", "id bigint"),
            ("", "contact_category text not null"),
            ("", "dae_unit / unit / std_code"),
            ("", "name / designation"),
            ("", "office_tel_fax / head_tel_fax"),
            ("", "residence_mobile / mobile_2"),
            ("", "email / email_2 / email_3"),
            ("", "fax_no / address / remarks"),
            ("", "applies_to_all_sites boolean default true"),
            ("", "created_at / updated_at"),
            ("NOTE", "Site scoping is stored through site_contact_links."),
        ],
    },
    "site_contact_links": {
        "x": 55,
        "y": 610,
        "w": 500,
        "cols": [
            ("PK/FK", "site_id -> sites.id ON DELETE CASCADE"),
            ("PK/FK", "contact_id -> contacts.id ON DELETE CASCADE"),
            ("NOTE", "Composite PK: (site_id, contact_id)"),
        ],
    },
    "layer_catalog": {
        "x": 55,
        "y": 910,
        "w": 390,
        "cols": [
            ("PK", "id integer"),
            ("UQ", "layer_key varchar unique not null"),
            ("", "display_name varchar not null"),
            ("", "category varchar"),
            ("", "geometry_type varchar"),
        ],
    },
    "site_layers": {
        "x": 545,
        "y": 910,
        "w": 390,
        "cols": [
            ("PK", "id integer"),
            ("FK", "site_id -> sites.id ON DELETE CASCADE"),
            ("FK", "layer_key -> layer_catalog.layer_key"),
            ("", "file_name varchar"),
            ("", "is_enabled boolean default true"),
        ],
    },
    "geo_features": {
        "x": 1055,
        "y": 1010,
        "w": 430,
        "cols": [
            ("PK", "id integer"),
            ("FK", "site_id -> sites.id ON DELETE CASCADE"),
            ("LOGIC", "layer_key varchar matches layer_catalog.layer_key"),
            ("", "properties jsonb"),
            ("", "geom geometry"),
            ("", "created_at timestamp"),
        ],
    },
}


RELATIONS = [
    ("sites", "erc_locations", "site_id", "solid"),
    ("sites", "instruments", "site_id", "solid"),
    ("erc_locations", "instruments", "erc_id", "solid"),
    ("manufacturers", "instruments", "manufacturer_id", "solid"),
    ("instrument_categories", "instruments", "category_id", "solid"),
    ("instrument_status", "instruments", "status_id", "solid"),
    ("users", "instruments", "checked_by / assigned_to", "solid"),
    ("sites", "site_contact_links", "site_id", "solid"),
    ("contacts", "site_contact_links", "contact_id", "solid"),
    ("sites", "site_layers", "site_id", "solid"),
    ("layer_catalog", "site_layers", "layer_key", "solid"),
    ("sites", "geo_features", "site_id", "solid"),
    ("layer_catalog", "geo_features", "layer_key logical", "dash"),
]


def table_height(cols):
    return 56 + (len(cols) * 27) + 28


def point(table, side):
    t = TABLES[table]
    h = table_height(t["cols"])
    if side == "right":
        return t["x"] + t["w"], t["y"] + h / 2
    if side == "left":
        return t["x"], t["y"] + h / 2
    if side == "bottom":
        return t["x"] + t["w"] / 2, t["y"] + h
    if side == "top":
        return t["x"] + t["w"] / 2, t["y"]
    return t["x"] + t["w"] / 2, t["y"] + h / 2


def relation_points(src, dst):
    sx, sy, sw = TABLES[src]["x"], TABLES[src]["y"], TABLES[src]["w"]
    dx, dy, dw = TABLES[dst]["x"], TABLES[dst]["y"], TABLES[dst]["w"]
    if sx + sw < dx:
        return point(src, "right"), point(dst, "left")
    if dx + dw < sx:
        return point(src, "left"), point(dst, "right")
    if sy < dy:
        return point(src, "bottom"), point(dst, "top")
    return point(src, "top"), point(dst, "bottom")


def badge(kind, x, y):
    colors = {
        "PK": ("#fff7ed", "#fb923c"),
        "FK": ("#eff6ff", "#60a5fa"),
        "PK/FK": ("#f5f3ff", "#8b5cf6"),
        "UQ": ("#ecfdf5", "#34d399"),
        "NOTE": ("#fef2f2", "#f87171"),
        "LOGIC": ("#f8fafc", "#94a3b8"),
    }
    if not kind:
        return ""
    fill, stroke = colors[kind]
    return (
        f'<rect x="{x}" y="{y - 15}" width="54" height="19" rx="4" fill="{fill}" stroke="{stroke}"/>'
        f'<text x="{x + 27}" y="{y - 2}" class="badge" text-anchor="middle">{escape(kind)}</text>'
    )


def render_table(name, t):
    x, y, w = t["x"], t["y"], t["w"]
    h = table_height(t["cols"])
    out = [
        f'<g id="{name}">',
        f'<rect class="box" x="{x}" y="{y}" width="{w}" height="{h}"/>',
        f'<rect class="head" x="{x}" y="{y}" width="{w}" height="40"/>',
        f'<text class="head-text" x="{x + 20}" y="{y + 26}">{escape(name)}</text>',
    ]
    cy = y + 67
    for kind, text in t["cols"]:
        out.append(badge(kind, x + 20, cy))
        text_x = x + (84 if kind else 22)
        cls = "note" if kind in {"NOTE", "LOGIC"} else "col"
        out.append(f'<text class="{cls}" x="{text_x}" y="{cy}">{escape(text)}</text>')
        cy += 27
    out.append("</g>")
    return "\n".join(out)


def render_relation(src, dst, label, style):
    (x1, y1), (x2, y2) = relation_points(src, dst)
    cls = "rel-dash" if style == "dash" else "rel"
    mx = (x1 + x2) / 2
    my = (y1 + y2) / 2
    return (
        f'<line class="{cls}" x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}"/>'
        f'<text class="rel-label" x="{mx:.1f}" y="{my - 7:.1f}">{escape(label)}</text>'
    )


def build():
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
        "<defs>",
        '<marker id="arrow" markerWidth="12" markerHeight="12" refX="10" refY="6" orient="auto"><path d="M2,2 L10,6 L2,10 Z" fill="#334155"/></marker>',
        "<style>",
        ".page{fill:#f8fafc}.title{font:700 34px Arial,sans-serif;fill:#0f172a}.subtitle{font:15px Arial,sans-serif;fill:#475569}",
        ".box{fill:#fff;stroke:#334155;stroke-width:2;rx:8}.head{fill:#1e293b;rx:8}.head-text{font:700 15px Arial,sans-serif;fill:#fff}",
        ".col{font:12.5px Consolas,monospace;fill:#172033}.note{font:12.5px Arial,sans-serif;fill:#475569}.badge{font:700 9px Arial,sans-serif;fill:#334155}",
        ".rel{stroke:#334155;stroke-width:2;marker-end:url(#arrow)}.rel-dash{stroke:#64748b;stroke-width:2;stroke-dasharray:7 6;marker-end:url(#arrow)}",
        ".rel-label{font:12px Arial,sans-serif;fill:#334155}.legend{font:12px Arial,sans-serif;fill:#334155}.foot{font:13px Arial,sans-serif;fill:#475569}",
        "</style>",
        "</defs>",
        f'<rect class="page" width="{W}" height="{H}"/>',
        '<text class="title" x="44" y="52">GIS Map Backend Database ERD</text>',
        '<text class="subtitle" x="44" y="80">Verified against live PostgreSQL database gis_db and gis_db_backup.dump on 2026-07-15.</text>',
        '<rect x="44" y="108" width="18" height="18" rx="3" fill="#fff7ed" stroke="#fb923c"/><text class="legend" x="70" y="122">Primary key</text>',
        '<rect x="170" y="108" width="18" height="18" rx="3" fill="#eff6ff" stroke="#60a5fa"/><text class="legend" x="196" y="122">Foreign key</text>',
        '<rect x="300" y="108" width="18" height="18" rx="3" fill="#ecfdf5" stroke="#34d399"/><text class="legend" x="326" y="122">Unique</text>',
        '<rect x="405" y="108" width="18" height="18" rx="3" fill="#f8fafc" stroke="#94a3b8"/><text class="legend" x="431" y="122">Logical relationship</text>',
    ]
    for src, dst, label, style in RELATIONS:
        parts.append(render_relation(src, dst, label, style))
    for name, table in TABLES.items():
        parts.append(render_table(name, table))
    parts.extend(
        [
            '<rect class="box" x="55" y="1280" width="1425" height="72"/>',
            '<rect class="head" x="55" y="1280" width="1425" height="30"/>',
            '<text class="head-text" x="77" y="1301">Accuracy notes</text>',
            '<text class="foot" x="77" y="1327">site_layers.layer_key has an actual FK to layer_catalog.layer_key. geo_features.layer_key is used by backend queries as a logical match, but the current DB has no FK constraint on that column.</text>',
            '<text class="foot" x="77" y="1347">Operational tables are contacts, instruments, and GIS layers; PostGIS metadata tables such as spatial_ref_sys/geometry_columns are intentionally omitted.</text>',
            "</svg>",
        ]
    )
    OUT.write_text("\n".join(parts), encoding="utf-8")
    print(OUT)


if __name__ == "__main__":
    build()
