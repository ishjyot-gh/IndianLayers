# GIS Map Data BARC Backend - Presentation Speaking Flow

Use this with `docs/GIS_Map_Project_Presentation_Improved.pptx`.
Keep each slide around 30-45 seconds. The slide text is intentionally short; use these notes for the spoken detail.

## Slide 1 - Problem Statement

Say:

> Operational site data is scattered across maps, files, and records. This project solves that by connecting locations, contacts, instruments, and GIS layers in one protected map-first workflow.

Mention:

- NPP and DAE-RERC locations need a single searchable view.
- Security and offline handoff are part of the requirement.

## Slide 2 - Objective

Say:

> The objective is to start from the map, open the correct site, and then work with verified operational records from the database.

Mention:

- NPP sites and DAE-RERC units are separate overlays.
- PostgreSQL/PostGIS is the source of truth.

## Slide 3 - System Architecture

Say:

> The frontend is HTML, CSS, JavaScript, and Leaflet. It talks to an Express API, which validates requests and reads or writes PostgreSQL and PostGIS data.

Mention:

- `api.js` attaches the JWT token.
- `server.js` enforces authentication and roles.

## Slide 4 - Main Map Flow

Say:

> The map is the entry point. `/api/sites` loads markers, layer toggles control the view, and marker clicks open the protected detail page for that site.

Mention:

- NPP and RERC markers serve different workflows.
- Detail pages require login.

## Slide 5 - Authentication And Roles

Say:

> Protected records use JWT-based login. The role controls what each user can do after login.

Roles:

- `viewer`: read protected data.
- `editor`: add, update, and delete records.
- `admin`: operational record permissions.

## Slide 6 - Site Detail Workflow

Say:

> The site detail page keeps the map and master data together. It loads site summary information, records, lookup values, and map context from the backend.

Mention:

- NPP pages can show protected GIS layers.
- RERC pages focus mainly on operational records.

## Slide 7 - Records Management

Say:

> Contacts and instruments are managed directly from the detail page, so users do not need to leave the site context.

Mention:

- Contacts use DAE Unit, City, and STD lookup values.
- Required contact fields and naming are normalized.

## Slide 8 - Instrument Import

Say:

> Instruments can be imported from CSV or Excel. The import handles legacy values, maps columns, and reports how many rows were inserted or updated.

Mention:

- `\N`, `NULL`, blanks, and date overflow values become NULL.
- Matching uses `erc_id + serial + model` when serial exists.

## Slide 9 - GIS Layer Flow

Say:

> Public boundaries are loaded as static GeoJSON. Protected site layers are modeled in the database through the layer catalog, site layer mapping, and PostGIS features.

Mention:

- Import source folder: `secure_import_data/<site-folder>/`.
- Layer key and file name must match DB mapping.

## Slide 10 - Offline Handoff

Say:

> The project is documented for transfer to a no-internet PC. Install prerequisites, copy the project and database dump, restore the database, configure `.env`, and run the server.

Mention:

- Handoff guide: `docs/RunProjectOnBarePc.md`.
- Include Node.js, PostgreSQL, PostGIS, and required installers.

## Slide 11 - Final Value

Say:

> The result is a working backend-backed GIS records system, not just a static map demo.

Close with:

- Map-first navigation.
- Real authentication and roles.
- Structured database relations.
- PostGIS-ready layer support.
- Import and offline handoff workflows.
