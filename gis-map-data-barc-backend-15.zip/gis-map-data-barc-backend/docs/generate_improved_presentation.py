from pathlib import Path

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt


ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
TEMP = Path(r"C:\Users\Ishjyot\AppData\Local\Temp")

OUT = DOCS / "GIS_Map_Project_Presentation_Improved.pptx"

IMG_NPP = TEMP / "ai-chat-attachment-11840142475857399846.png"
IMG_RERC = TEMP / "ai-chat-attachment-4629625904909698790.png"
IMG_SITE = TEMP / "ai-chat-attachment-10245793073558520706.png"
IMG_ACTIONS = TEMP / "ai-chat-attachment-16469906471088039372.png"
IMG_LAYER = TEMP / "ai-chat-attachment-5981520576343884220.png"

NAVY = RGBColor(9, 22, 48)
INK = RGBColor(22, 31, 46)
MUTED = RGBColor(96, 111, 131)
TEAL = RGBColor(20, 133, 109)
GREEN = RGBColor(28, 171, 101)
RED = RGBColor(231, 74, 69)
BLUE = RGBColor(50, 129, 255)
BG = RGBColor(247, 250, 253)
SOFT_BLUE = RGBColor(226, 239, 255)
SOFT_GREEN = RGBColor(224, 247, 235)
SOFT_RED = RGBColor(255, 233, 231)
WHITE = RGBColor(255, 255, 255)


def blank_slide(prs):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.background.fill
    bg.solid()
    bg.fore_color.rgb = BG
    return slide


def add_text(slide, text, x, y, w, h, size=24, bold=False, color=INK, align=PP_ALIGN.LEFT):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.clear()
    tf.margin_left = 0
    tf.margin_right = 0
    tf.margin_top = 0
    tf.margin_bottom = 0
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.name = "Aptos"
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    return box


def add_footer(slide, num):
    add_text(slide, "GIS Map Data BARC", 0.55, 7.05, 3.0, 0.25, 8.5, False, MUTED)
    add_text(slide, f"{num:02d}", 12.15, 7.03, 0.6, 0.25, 9, True, MUTED, PP_ALIGN.RIGHT)


def add_title(slide, eyebrow, title, subtitle=None):
    if eyebrow:
        add_pill(slide, eyebrow, 0.65, 0.45, 2.1, 0.34, SOFT_GREEN, TEAL, 10)
    add_text(slide, title, 0.65, 0.88, 7.2, 0.7, 31, True, NAVY)
    if subtitle:
        add_text(slide, subtitle, 0.67, 1.55, 7.2, 0.35, 13, False, MUTED)


def add_pill(slide, text, x, y, w, h, fill, color=TEAL, size=9):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill
    shape.line.fill.background()
    tf = shape.text_frame
    tf.clear()
    tf.margin_left = Inches(0.12)
    tf.margin_right = Inches(0.12)
    tf.margin_top = Inches(0.03)
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    r = p.add_run()
    r.text = text
    r.font.name = "Aptos"
    r.font.size = Pt(size)
    r.font.bold = True
    r.font.color.rgb = color
    return shape


def add_card(slide, x, y, w, h, fill=WHITE, line=RGBColor(214, 223, 235)):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill
    shape.line.color.rgb = line
    shape.line.width = Pt(1)
    shape.adjustments[0] = 0.08
    return shape


def add_bullets(slide, items, x, y, w, h, size=15, color=INK, bullet_color=TEAL, gap=0.46):
    for idx, item in enumerate(items):
        yy = y + idx * gap
        dot = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(yy + 0.08), Inches(0.12), Inches(0.12))
        dot.fill.solid()
        dot.fill.fore_color.rgb = bullet_color
        dot.line.fill.background()
        add_text(slide, item, x + 0.28, yy, w - 0.28, 0.35, size, False, color)


def add_image_cover(slide, image_path, x, y, w, h, radius=True):
    if not image_path.exists():
        add_card(slide, x, y, w, h, SOFT_BLUE)
        add_text(slide, "Screenshot missing", x + 0.25, y + h / 2 - 0.15, w - 0.5, 0.3, 14, True, MUTED, PP_ALIGN.CENTER)
        return None

    with Image.open(image_path) as img:
        img_w, img_h = img.size
    img_ratio = img_w / img_h
    box_ratio = w / h

    pic = slide.shapes.add_picture(str(image_path), Inches(x), Inches(y), width=Inches(w), height=Inches(h))
    if img_ratio > box_ratio:
        crop = 1 - (box_ratio / img_ratio)
        pic.crop_left = crop / 2
        pic.crop_right = crop / 2
    elif img_ratio < box_ratio:
        crop = 1 - (img_ratio / box_ratio)
        pic.crop_top = crop / 2
        pic.crop_bottom = crop / 2

    if radius:
        border = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
        border.fill.background()
        border.line.color.rgb = RGBColor(207, 218, 232)
        border.line.width = Pt(1.2)
        border.adjustments[0] = 0.06
    return pic


def add_flow(slide, labels, x, y, w, h):
    box_w = w / len(labels) - 0.18
    for i, (label, sub, color) in enumerate(labels):
        xx = x + i * (box_w + 0.24)
        add_card(slide, xx, y, box_w, h, WHITE)
        add_pill(slide, str(i + 1), xx + 0.18, y + 0.18, 0.35, 0.35, color, NAVY, 9)
        add_text(slide, label, xx + 0.25, y + 0.66, box_w - 0.5, 0.3, 14, True, NAVY, PP_ALIGN.CENTER)
        add_text(slide, sub, xx + 0.22, y + 1.08, box_w - 0.44, 0.55, 10.5, False, MUTED, PP_ALIGN.CENTER)
        if i < len(labels) - 1:
            add_text(slide, ">", xx + box_w + 0.04, y + 0.78, 0.18, 0.35, 16, True, MUTED, PP_ALIGN.CENTER)


def build():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # 1
    slide = blank_slide(prs)
    add_pill(slide, "Problem Statement", 0.65, 0.55, 2.2, 0.36, SOFT_RED, RED, 10)
    add_text(slide, "Operational site data is scattered across maps, files, and records.", 0.65, 1.05, 6.4, 1.25, 31, True, NAVY)
    add_bullets(
        slide,
        [
            "NPP and DAE-RERC locations need one searchable view.",
            "Contacts, instruments, and GIS layers are hard to connect.",
            "Secure access and offline handoff are required.",
        ],
        0.78,
        2.65,
        5.9,
        1.6,
        15,
        INK,
        RED,
    )
    add_card(slide, 0.75, 5.25, 5.8, 0.8, SOFT_BLUE)
    add_text(slide, "Project goal: a protected, map-first records system backed by PostgreSQL/PostGIS.", 1.0, 5.48, 5.3, 0.28, 13, True, NAVY)
    add_image_cover(slide, IMG_RERC, 7.15, 0.55, 5.55, 5.9)
    add_footer(slide, 1)

    # 2
    slide = blank_slide(prs)
    add_title(slide, "Objective", "Build one workflow around the map", "Users start from location, then move into verified site records.")
    add_image_cover(slide, IMG_NPP, 0.75, 2.1, 4.6, 4.55)
    add_card(slide, 5.8, 2.05, 6.7, 4.55)
    add_bullets(
        slide,
        [
            "Show NPP sites and DAE-RERC units as separate map overlays.",
            "Open protected site details directly from markers.",
            "Keep records consistent through database relations and validation.",
            "Prepare the project for transfer to a bare/offline PC.",
        ],
        6.15,
        2.72,
        5.95,
        2.2,
        15,
        INK,
        TEAL,
        0.58,
    )
    add_footer(slide, 2)

    # 3
    slide = blank_slide(prs)
    add_title(slide, "System Architecture", "Simple frontend, protected API, spatial database")
    add_flow(
        slide,
        [
            ("Browser", "HTML, CSS, JavaScript, Leaflet", SOFT_BLUE),
            ("Express API", "Auth, validation, record routes", SOFT_GREEN),
            ("PostgreSQL", "Structured operational tables", SOFT_BLUE),
            ("PostGIS", "Protected site geometry", SOFT_GREEN),
        ],
        0.78,
        2.15,
        11.9,
        2.0,
    )
    add_card(slide, 1.0, 5.08, 3.45, 0.88, WHITE)
    add_text(slide, "api.js", 1.25, 5.24, 0.8, 0.25, 13, True, NAVY)
    add_text(slide, "attaches JWT token", 2.0, 5.24, 1.9, 0.25, 12, False, MUTED)
    add_card(slide, 4.95, 5.08, 3.45, 0.88, WHITE)
    add_text(slide, "server.js", 5.2, 5.24, 0.9, 0.25, 13, True, NAVY)
    add_text(slide, "enforces auth and roles", 6.1, 5.24, 2.0, 0.25, 12, False, MUTED)
    add_card(slide, 8.9, 5.08, 3.45, 0.88, WHITE)
    add_text(slide, "DB", 9.15, 5.24, 0.4, 0.25, 13, True, NAVY)
    add_text(slide, "stores records and layers", 9.65, 5.24, 2.1, 0.25, 12, False, MUTED)
    add_footer(slide, 3)

    # 4
    slide = blank_slide(prs)
    add_title(slide, "Main Map Flow", "The map is the entry point")
    add_image_cover(slide, IMG_RERC, 0.72, 1.6, 7.35, 4.65)
    add_card(slide, 8.45, 1.75, 3.95, 3.95)
    add_bullets(
        slide,
        [
            "GET /api/sites loads markers.",
            "Layer toggles separate NPP and RERC views.",
            "Marker click opens site detail by ID.",
            "Protected pages require login.",
        ],
        8.8,
        2.35,
        3.25,
        2.0,
        14,
        INK,
        GREEN,
        0.55,
    )
    add_footer(slide, 4)

    # 5
    slide = blank_slide(prs)
    add_title(slide, "Authentication And Roles", "Protected data is not a static demo")
    add_card(slide, 0.85, 1.8, 3.45, 3.6, WHITE)
    add_text(slide, "viewer", 1.2, 2.18, 2.75, 0.35, 18, True, NAVY, PP_ALIGN.CENTER)
    add_text(slide, "Read protected site data", 1.2, 2.88, 2.75, 0.35, 13, False, MUTED, PP_ALIGN.CENTER)
    add_card(slide, 4.95, 1.8, 3.45, 3.6, WHITE)
    add_text(slide, "editor", 5.3, 2.18, 2.75, 0.35, 18, True, NAVY, PP_ALIGN.CENTER)
    add_text(slide, "Add, update, delete records", 5.3, 2.88, 2.75, 0.35, 13, False, MUTED, PP_ALIGN.CENTER)
    add_card(slide, 9.05, 1.8, 3.45, 3.6, WHITE)
    add_text(slide, "admin", 9.4, 2.18, 2.75, 0.35, 18, True, NAVY, PP_ALIGN.CENTER)
    add_text(slide, "Operational record permissions", 9.4, 2.88, 2.75, 0.35, 13, False, MUTED, PP_ALIGN.CENTER)
    add_pill(slide, "JWT in sessionStorage", 5.15, 5.95, 3.0, 0.42, SOFT_GREEN, TEAL, 11)
    add_footer(slide, 5)

    # 6
    slide = blank_slide(prs)
    add_title(slide, "Site Detail Workflow", "Map context and master data stay together")
    add_image_cover(slide, IMG_SITE, 0.65, 1.5, 7.15, 5.0)
    add_card(slide, 8.25, 1.75, 4.15, 4.45)
    add_bullets(
        slide,
        [
            "Loads site summary, zone, state, and status.",
            "NPP pages can show protected GIS layers.",
            "RERC pages focus on operational records.",
            "Sidebar keeps data visible beside the map.",
        ],
        8.62,
        2.35,
        3.35,
        2.35,
        14,
        INK,
        BLUE,
        0.55,
    )
    add_footer(slide, 6)

    # 7
    slide = blank_slide(prs)
    add_title(slide, "Records Management", "Contacts and instruments are handled from the detail page")
    add_card(slide, 0.8, 1.55, 4.95, 4.75, WHITE)
    add_image_cover(slide, IMG_ACTIONS, 1.2, 2.1, 4.15, 2.9)
    add_card(slide, 6.25, 1.55, 5.95, 4.75)
    add_bullets(
        slide,
        [
            "Contact forms use DAE Unit, City, and STD lookup values.",
            "Instrument form supports manual operational entry.",
            "VECC naming and required contact fields are normalized.",
        ],
        6.62,
        2.25,
        5.1,
        1.8,
        15,
        INK,
        TEAL,
        0.62,
    )
    add_footer(slide, 7)

    # 8
    slide = blank_slide(prs)
    add_title(slide, "Instrument Import", "Legacy CSV/Excel data can be absorbed safely")
    items = [
        ("Input", ".csv, .xls, .xlsx"),
        ("Cleanup", r"\N, NULL, blanks, ######## -> NULL"),
        ("Matching", "erc_id + serial + model when serial exists"),
        ("Result", "inserted vs updated counts returned"),
    ]
    y = 1.75
    for label, value in items:
        add_card(slide, 1.1, y, 11.1, 0.88, WHITE)
        add_pill(slide, label, 1.35, y + 0.21, 1.25, 0.38, SOFT_BLUE, BLUE, 10)
        add_text(slide, value, 2.95, y + 0.22, 8.7, 0.33, 15, True, NAVY)
        y += 1.08
    add_text(slide, "Manual form still keeps stricter serial/model validation.", 1.25, 6.15, 10.7, 0.3, 13, False, MUTED, PP_ALIGN.CENTER)
    add_footer(slide, 8)

    # 9
    slide = blank_slide(prs)
    add_title(slide, "GIS Layer Flow", "Public boundaries plus protected site layers")
    add_image_cover(slide, IMG_LAYER, 0.78, 1.55, 5.75, 4.9)
    add_flow(
        slide,
        [
            ("Static GeoJSON", "India, states, districts", SOFT_BLUE),
            ("Layer Catalog", "DB mapping and layer keys", SOFT_GREEN),
            ("Geo Features", "PostGIS geometry per site", SOFT_BLUE),
        ],
        6.9,
        2.2,
        5.5,
        1.85,
    )
    add_card(slide, 7.18, 4.75, 4.85, 0.8, SOFT_RED)
    add_text(slide, "Import source: secure_import_data/<site-folder>/", 7.48, 5.0, 4.25, 0.26, 12, True, NAVY, PP_ALIGN.CENTER)
    add_footer(slide, 9)

    # 10
    slide = blank_slide(prs)
    add_title(slide, "Offline Handoff", "Designed to run on a no-internet PC")
    add_flow(
        slide,
        [
            ("Install", "Node.js, PostgreSQL, PostGIS", SOFT_BLUE),
            ("Copy", "Project, node_modules, dump, installers", SOFT_GREEN),
            ("Restore", "Database and migrations", SOFT_BLUE),
            ("Run", ".env then npm start", SOFT_GREEN),
        ],
        0.8,
        2.15,
        11.7,
        2.0,
    )
    add_card(slide, 2.0, 5.2, 9.3, 0.75, WHITE)
    add_text(slide, "Handoff guide: docs/RunProjectOnBarePc.md", 2.25, 5.43, 8.8, 0.25, 13, True, NAVY, PP_ALIGN.CENTER)
    add_footer(slide, 10)

    # 11
    slide = blank_slide(prs)
    add_pill(slide, "Final Value", 0.65, 0.55, 1.8, 0.36, SOFT_GREEN, TEAL, 10)
    add_text(slide, "A working backend-backed GIS records system.", 0.65, 1.05, 6.5, 0.8, 30, True, NAVY)
    add_bullets(
        slide,
        [
            "Map-first navigation for NPP and DAE-RERC units.",
            "Authentication, roles, and backend validation.",
            "Normalized records with PostGIS-ready layer support.",
            "Import and offline handoff workflows documented.",
        ],
        0.8,
        2.32,
        5.85,
        2.3,
        15,
        INK,
        TEAL,
        0.6,
    )
    add_image_cover(slide, IMG_SITE, 7.15, 0.9, 5.5, 5.45)
    add_footer(slide, 11)

    prs.save(OUT)
    print(OUT)


if __name__ == "__main__":
    build()
