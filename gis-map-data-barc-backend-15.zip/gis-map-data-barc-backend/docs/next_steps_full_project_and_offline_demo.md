# Next Steps To Complete The GIS Website And Offline Demo

> Superseded for study/handoff by `docs/GIS_Map_Project_Self_Study_Guide.md`.
> This file is kept only as an older planning note.

Date prepared: 2026-07-04

## Current Project Stage

The project already has:

- Static Leaflet map frontend.
- Express backend.
- PostgreSQL/PostGIS schema.
- APIs for:
  - sites
  - site layers
  - GeoJSON features
  - contacts
  - ERC locations
  - instruments
  - lookup data
- Docker setup.
- Release zip script.

The biggest missing pieces are:

- Real login/signup/auth protection.
- Complete frontend screens/forms.
- Proper demo packaging.
- Clear offline/no-internet demo strategy.

## Important Decision

Do not rewrite the whole project now.

For final submission, continue with:

- Express backend
- PostgreSQL/PostGIS database
- Leaflet frontend
- Docker packaging

For no-dependency demo, create a separate static demo build only if needed.

Reason:

- The real project needs a backend and database because it has login, editing, linked data, and spatial layers.
- A browser-only JavaScript project cannot securely support real login, multi-user editing, database constraints, PostGIS queries, or durable server-side data.
- But a static demo version can look and behave almost the same for presentation purposes using exported JSON files and browser localStorage.

## Day 1 Priority: Authentication

### Backend Tasks

Add dependencies in `backend/package.json`:

- `bcryptjs`
- `jsonwebtoken`

Create auth utilities:

- hash passwords using bcrypt
- compare passwords
- create JWT token
- verify JWT token
- extract user from `Authorization: Bearer <token>`

Add API routes:

- `POST /api/auth/signup`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `POST /api/auth/logout`

Recommended signup fields:

- name
- email
- password
- emp_no
- designation
- section
- division
- location

Recommended login fields:

- email
- password

JWT payload should include:

- user id
- name
- email
- role

Add middleware:

- `requireAuth`
- `requireRole(["admin", "editor"])`

Protect these APIs:

- `GET /api/sites/:id`
- `GET /api/sites/:id/layers`
- `GET /api/sites/:id/layers/:layerKey`
- `GET /api/sites/:id/contacts`
- `POST /api/sites/:id/contacts`
- `PUT /api/contacts/:id`
- `GET /api/sites/:id/erc-locations`
- `POST /api/sites/:id/erc-locations`
- `GET /api/instrument-lookups`
- `GET /api/sites/:id/instruments`
- `POST /api/sites/:id/instruments`
- `PUT /api/instruments/:id`

Keep `GET /api/health` public.

Decide whether `GET /api/sites` should be public or protected.

Recommended for demo:

- public landing/login page
- protected site map and all details

### Database Tasks

Update `db/init/001_schema.sql` if needed:

- users table already exists
- add role values:
  - `admin`
  - `editor`
  - `viewer`

Add seed admin user for demo.

Do not hardcode a real password in public files if project will be shared widely.

For local demo, acceptable:

- email: `admin@example.local`
- password: `Admin@12345`

But mention clearly in docs that it is demo-only.

## Day 1 Priority: Frontend Login Flow

Create or update frontend files:

- `index.html`
- `styles.css`
- `npp_sites/map.js`
- possibly add `auth.js`
- possibly add `api.js`

Required frontend behavior:

- show login/signup screen if no token exists
- call `/api/auth/login`
- save JWT token in localStorage
- attach token to API calls
- show logged-in user name
- add logout button
- redirect back to login after logout
- handle `401 Unauthorized` by clearing token and showing login

Recommended UI structure:

- full-screen login panel
- after login, show map
- top/right small user toolbar
- clicking a site opens site detail view/sidebar

## Day 2 Priority: Site Details Page/Sidebar

When user clicks a site marker:

- zoom to site
- load site details
- load enabled layers
- show site sidebar
- show sections/tabs:
  - Details
  - Contacts
  - ERC Locations
  - Instruments
  - Layers

Site details should show:

- name
- state
- zone
- reactor type
- installed capacity
- units
- operator
- status
- description
- latitude
- longitude

For map zoom/detail:

- show site marker on main map
- when clicked, zoom near site
- load site layers on demand
- layer checkboxes should toggle GeoJSON overlays
- style point/line/polygon layers clearly
- clicking a feature should show properties popup

## Day 2 Priority: Add/Edit Forms

### Contacts

Show contact list grouped by:

- category
- unit

Fields:

- contact_category
- dae_unit
- std_code
- unit
- name
- designation
- office_tel_fax
- head_tel_fax
- residence_mobile
- email
- address
- remarks
- applies_to_all_sites

Actions:

- add contact
- edit contact

### ERC Locations

Fields:

- erc_state
- location
- unit
- coordinator
- phone_number_o
- phone_number_h
- mobile_number

Actions:

- add ERC location
- optionally edit ERC location if time permits

Current backend has add only for ERC locations. Add `PUT /api/erc-locations/:id` if edit is required.

### Instruments

Fields:

- ERC location
- manufacturer
- category/monitor type
- status
- checked by
- assigned to
- checked on
- calibrated on
- serial number
- model
- current location
- barcode verification
- efficiency
- resolution
- calibration factor
- sensitivity
- datasheet
- remark

Actions:

- add instrument
- edit instrument

Use `/api/instrument-lookups` for dropdowns.

## Minimum Role Rules

Use simple role behavior:

- `viewer`: can view map/details only
- `editor`: can add/edit contacts, ERC locations, instruments
- `admin`: can do everything editor can do, plus manage users later

For this phase:

- do not build full user management UI unless time remains
- seed one admin/editor user for demo

## Error Handling Checklist

Backend should return clean JSON errors:

- `400` for invalid input
- `401` for missing/invalid login
- `403` for insufficient role
- `404` for not found
- `500` for unexpected server/database errors

Frontend should show:

- login error
- save failed message
- loading state
- empty state for no records

## Testing Checklist

Run these before demo:

```powershell
docker compose up --build
```

Open:

```text
http://localhost:5000/
```

Test:

- health endpoint works
- login works
- wrong password fails
- logout works
- map loads after login
- site click opens details
- contacts load
- add contact works
- edit contact works
- ERC locations load
- add ERC location works
- instruments load
- add instrument works
- edit instrument works
- layer toggles work
- browser refresh keeps login
- invalid token redirects to login

API checks:

```text
GET /api/health
POST /api/auth/login
GET /api/auth/me
GET /api/sites
GET /api/sites/:id
GET /api/sites/:id/contacts
GET /api/sites/:id/instruments
```

## Packaging For Final Submission

Current release script:

```powershell
.\scripts\package-release.ps1
```

This creates:

```text
dist\gis-map-data-barc-backend-release.zip
```

Before packaging:

- remove sensitive data
- remove real credentials
- include `.env.example`
- include README run steps
- include demo login credentials only if allowed
- check that `data`, `secure_import_data`, `node_modules`, and dumps are excluded

## Offline Demo Options

### Option A: Docker Offline Demo

This is the best realistic full-feature demo.

It keeps:

- real backend
- real PostgreSQL/PostGIS
- real login
- real edits
- real APIs

Requirement on demo PC:

- Docker Desktop must already be installed

No internet is needed after images are loaded.

Prepare on your PC:

```powershell
docker compose build
docker pull postgis/postgis:16-3.4
docker save -o dist\gis-demo-images.tar postgis/postgis:16-3.4 gis-map-data-barc-backend-app
.\scripts\package-release.ps1
```

Ship:

```text
dist\gis-map-data-barc-backend-release.zip
dist\gis-demo-images.tar
load-images.ps1
start-demo.ps1
README_OFFLINE_DEMO.md
```

On demo PC:

```powershell
docker load -i gis-demo-images.tar
docker compose up
```

Then open:

```text
http://localhost:5000/
```

### Option B: Static No-Dependency Demo

This is possible, but it is not the real backend project.

It can run by opening an HTML file in a browser.

It can have:

- same visual look
- same map
- same site details
- same contacts display
- same instruments display
- fake login screen
- add/edit forms saved in browser localStorage
- local JSON files for data

It cannot truly have:

- secure login
- server-side users
- PostgreSQL
- PostGIS
- real database constraints
- real multi-user editing
- real API persistence
- secure role enforcement

Recommended use:

- final submission: backend project
- demo fallback: static no-dependency mock/demo with same look and flow

This is acceptable if you clearly say:

> This is an offline static demo build with the same user interface and workflow. The submitted full project uses Express and PostgreSQL/PostGIS for real authentication, persistence, and spatial data.

### Option C: Bundle Node And PostgreSQL

This is technically possible but not recommended in 1-2 days.

Problems:

- PostgreSQL/PostGIS installation is heavy
- Windows services and ports can fail
- paths and permissions become difficult
- packaging becomes fragile
- debugging on another PC is slow

Avoid this unless there is more time.

## Answer To Main Question

Can the completed backend project be converted into a true no-dependency project like a simple JavaScript folder?

Short answer:

No, not as the same real project.

Reason:

- backend APIs need Node.js
- database needs PostgreSQL
- spatial data needs PostGIS
- login/auth needs a server
- add/edit persistence needs a database or server-side storage

But you can create a static demo version that looks and behaves almost the same for presentation.

Best strategy:

- submit the real backend project
- prepare Docker offline package for proper full demo
- also prepare a static browser-only demo as emergency fallback

## Recommended Final Deliverables

Submit:

- source code zip
- database schema
- Dockerfile
- docker-compose.yml
- README
- screenshots
- ERD
- demo credentials

Carry for demo:

- Docker offline package
- static no-dependency demo folder
- screenshots/video backup

## Tomorrow Morning Execution Order

1. Add backend auth dependencies.
2. Implement auth routes.
3. Implement auth middleware.
4. Protect APIs.
5. Add seed/demo user.
6. Add frontend login/logout.
7. Add authenticated API helper.
8. Finish site details sidebar.
9. Finish contacts add/edit.
10. Finish ERC add/edit if required.
11. Finish instruments add/edit.
12. Test using Docker.
13. Package release zip.
14. Prepare offline Docker image package.
15. If time remains, create static no-dependency demo fallback.

## Practical Rule For Finishing On Time

If time becomes short:

Must finish:

- login
- protected site details
- contacts view/add/edit
- instruments view/add/edit
- Docker demo

Can skip or simplify:

- user management UI
- complex role screens
- delete operations
- advanced validation
- advanced map styling
- full static no-dependency demo
