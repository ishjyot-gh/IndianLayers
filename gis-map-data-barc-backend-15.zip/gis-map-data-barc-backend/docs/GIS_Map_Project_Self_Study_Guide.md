# GIS Map Project Self-Study Guide

Last updated: 2026-07-14

This guide is meant for quick revision before explaining the project. It covers the idea, user flow, database, code flow, imports, constraints, and common questions at both layman and technical levels.

## 1. Project In One Minute

This project is a GIS-based web system for viewing nuclear-related site data on a map and managing operational records linked to those sites.

It shows:

- NPP sites on an India map.
- DAE-RERC units on the same map.
- Site detail pages after login.
- Contact records.
- Instrument records.
- Site-specific protected GIS layers stored in PostgreSQL/PostGIS.

The frontend is plain HTML, CSS, JavaScript, and Leaflet. The backend is Node.js/Express. The database is PostgreSQL with PostGIS.

## 2. What Problem It Solves

Without a map-based system, site information, contacts, instruments, and GIS layers are scattered across files or separate tables. This app brings them into one workflow:

1. Open the map.
2. Select a site or DAE-RERC unit.
3. Login to see protected details.
4. View or maintain contacts and instruments.
5. For populated NPP sites, load GIS layers like roads, settlements, hospitals, sectors, and water bodies.

In simple words: the map is the entry point, and the database is the source of truth.

## 3. Current Technology Stack

```text
Frontend: HTML, CSS, JavaScript, Leaflet
Backend: Node.js, Express
Database: PostgreSQL + PostGIS
Authentication: JWT
DB driver: pg
Excel/CSV import: multer + xlsx
Run command: npm start
Default URL: http://localhost:5000/
```

Important files:

```text
index.html                         Main map page
auth.js                            Login/signup/session handling
api.js                             Adds Authorization header to API calls
styles.css                         Shared UI styles

npp_sites/map.js                   Main map bootstrap
npp_sites/map_common.js            Shared Leaflet marker/layer helpers
npp_sites/site.html                Site detail page
npp_sites/site_detail.js           Site detail bootstrap
npp_sites/site_detail_records.js   Contacts, instruments, and import UI
npp_sites/site_detail_layer_controller.js
                                   Protected PostGIS layer UI

backend/server.js                  Express routes, validation, DB writes
backend/db.js                      PostgreSQL connection pool
backend/config.js                  Reads .env

db/init/001_schema.sql             Fresh schema and seed data
db/migrations/*.sql                Existing database corrections/migrations
backend/scripts/import_geojson.js  GeoJSON to PostGIS importer
```

## 4. User Flow

### Main Map Flow

1. User opens `http://localhost:5000/`.
2. Frontend calls `GET /api/sites`.
3. Sites are shown as map markers.
4. Markers are grouped as:
   - NPP Sites
   - DAE-RERC Units
5. Clicking a marker opens:

```text
npp_sites/site.html?id=<site_id>
```

### Login Flow

The detail page requires login. Auth APIs:

```http
POST /api/auth/login
POST /api/auth/signup
GET  /api/auth/me
POST /api/auth/logout
```

JWT is stored in `sessionStorage`. `api.js` attaches:

```http
Authorization: Bearer <token>
```

Roles:

```text
viewer -> view protected details and records
editor -> add/edit/delete contacts and instruments
admin  -> same operational permissions as editor
```

Demo login:

```text
email: admin@example.local
password: Admin@12345
```

## 5. Site Detail Page

The site detail page loads:

- Site summary.
- Contacts.
- Instruments.
- ERC/instrument location rows.
- Lookup tables.
- Map context.
- Protected GIS layers for NPP sites that have layer data.

RERC-specific behavior:

- Site Layers section is hidden.
- Wider detail panel.
- Focus is on contacts and instruments.
- Each RERC unit has one `erc_locations` row.

NPP behavior:

- Site details are shown.
- GIS layers can be listed and toggled if available in DB.
- Layer geometry comes from PostGIS.

## 6. Database Overview

Main tables:

```text
users
sites
contacts
site_contact_links
erc_locations
instruments
manufacturers
instrument_categories
instrument_status
layer_catalog
site_layers
geo_features
```

Important relationships:

```text
sites.id -> erc_locations.site_id
sites.id -> instruments.site_id
erc_locations.erc_id -> instruments.erc_id
manufacturers.manufacturer_id -> instruments.manufacturer_id
instrument_categories.instrument_category_id -> instruments.category_id
instrument_status.status_id -> instruments.status_id
users.id -> instruments.checked_by_user_id / assigned_to_user_id
sites.id -> site_contact_links.site_id
contacts.id -> site_contact_links.contact_id
sites.id -> site_layers.site_id
layer_catalog.layer_key -> site_layers.layer_key
layer_catalog.layer_key -> geo_features.layer_key
sites.id -> geo_features.site_id
```

Visual ERD:

```text
docs/database_erd.svg
```

## 7. Sites And RERC Mapping

Seeded site groups:

```text
NPP sites: 1-7
DAE-RERC sites: 101-123
```

Current RERC instrument-location mapping:

| erc_id | Location | Unit | STD |
|---:|---|---|---|
| 1 | Alwaye | IREL | 0484 |
| 2 | Bengaluru | AMD | 080 |
| 3 | Delhi | AMD | 011 |
| 4 | Gandhinagar | IPR | 079 |
| 5 | Hyderabad | NFC | 040 |
| 6 | Indore | RRCAT | 0731 |
| 7 | Jaduguda | UCI | 0657 |
| 8 | Jaipur | AMD | 0141 |
| 9 | Kolkata | VECC | 033 |
| 10 | MK-TN | IREL | 04651 |
| 11 | Mysuru | RMP | 0821 |
| 12 | Nagpur | AMD | 0712 |
| 13 | OSCOM | IREL | 06811 |
| 14 | Shillong | AMD | 0364 |
| 15 | Turamdih | UCI | 0657 |
| 16 | Vizag | BARC | 0891 |
| 17 | Srinagar | NRL-BARC | 0194 |
| 18 | Kaiga | NPCIL | 08382 |
| 19 | Kakrapar | NPCIL | 02626 |
| 20 | Kota | NPCIL | 01475 |
| 21 | Kudankulam | NPCIL | 04637 |
| 22 | Narora | NPCIL | 05734 |
| 23 | Tarapur | NPCIL | 02525 |

Why this matters:

- Instrument CSV files refer to `ERC_ID`.
- The app uses `ERC_ID` to decide which RERC unit owns the instrument.
- Site filtering works because each `erc_locations` row has the correct `site_id`.

## 8. Contacts

Contact fields shown in UI:

```text
Category
DAE Unit
City
STD Code
Name
Telephone 1 / Telephone 2
Mobile 1 / Mobile 2
Email 1 / Email 2 / Email 3
Fax No.
Remarks
```

Required in the form:

```text
Name
Email 1
Telephone 1
```

For DAE-RERC-specific categories, at least one location clue is required:

```text
DAE Unit, City, or STD Code
```

Contact categories:

```text
DAE-RERC Coordinator
DAE-RERC Alternate Coordinator
DAE-RERC Unit Head Details
Other Contact Details
```

Important behavior:

- `/api/rerc-units` feeds DAE Unit, City, and STD lookup suggestions.
- Legacy `BARC / VECC` is normalized to `VECC`.
- Schema supports site-linked contacts through `site_contact_links`.
- Current contact fetch route returns all contacts ordered by category/unit/name.

## 9. Instruments

Instrument tables:

```text
instruments
erc_locations
manufacturers
instrument_categories
instrument_status
users
```

Manual Add Instrument form:

- Requires instrument location.
- Requires serial number.
- Requires model.
- Allows selecting existing manufacturer/category/status.
- Allows creating a new manufacturer or category from form fields.

Instrument import:

- Accepts `.csv`, `.xls`, `.xlsx`.
- Upload button is inside the Add Instrument form.
- Serial number is optional only for import.
- Manual form still requires serial number.

Common imported columns:

```text
ERC_ID
MANF_ID
CAT_ID
INST_ID
STATUS
CHECKED_
CALIBRATI
INST_SNo
INST_MOD
CHECKED
CURR_Loc
ASSIGNED
BCODE_VE
EFFICIENC
RESOLUTI
CALIB_FA
SENSITIVI
DATASHEET
REMARK
```

Legacy import cleanup:

```text
\N       -> NULL
NULL     -> NULL
blank    -> NULL
######## -> NULL, usually Excel date display overflow
```

Dates:

- Valid dates are accepted.
- Excel serial dates are accepted.
- Broken display values like `########` are stored as NULL.

Statuses:

- Numeric `STATUS_ID` is used directly.
- Text status like `Working` is looked up in `instrument_status`.
- If missing, the status is created once and reused.

Duplicate behavior:

- The app treats `erc_id + inst_sno + inst_model` as the instrument identity when serial number exists.
- If a CSV repeats `INST_ID` for different instruments, new DB `inst_id` values are generated.
- Import response now shows inserted vs updated counts.

Example message:

```text
Imported 225 instrument row(s): 225 inserted, 0 updated.
Imported 0 manufacturer row(s) and 0 category row(s).
```

## 10. Manufacturer And Category Lookups

Current lookup state:

```text
manufacturers: 18 rows, IDs 1..18
instrument_categories: 9 rows, IDs 1..9
```

Why these tables are separate:

- Avoid repeating manufacturer names in every instrument row.
- Keep category/monitor type normalized.
- Keep instrument rows compact and consistent.

If an imported instrument refers to a missing lookup ID:

- The importer creates a placeholder row to preserve the foreign key.
- Later lookup uploads can fill real details for that same ID.

## 11. GIS Layer Flow

Public map overlays:

```text
data/india.geojson
data/states.geojson
data/districts.geojson
```

Protected site-specific layers:

```text
layer_catalog     master list of layer keys
site_layers       which layer is enabled for which site
geo_features      actual PostGIS geometry and properties
```

Layer APIs:

```http
GET /api/sites/:id/layers
GET /api/sites/:id/layers/:layerKey
```

GeoJSON import helper:

```text
backend/scripts/import_geojson.js
```

Expected source folder:

```text
secure_import_data/<site-folder>/<file-name>
```

What must match:

1. `sites.folder` must match the folder under `secure_import_data`.
2. `site_layers.file_name` must match the GeoJSON file name.
3. `site_layers.layer_key` must exist in `layer_catalog`.
4. `geo_features.layer_key` must match `layer_catalog.layer_key`.
5. Geometry must be valid GeoJSON.

If a layer does not show:

- Check the user is logged in.
- Check `/api/sites/:id/layers`.
- Check `site_layers.is_enabled = true`.
- Check `layer_catalog` has the layer key.
- Check `geo_features` has rows for that `site_id + layer_key`.

## 12. How A Request Is Executed

Example: user opens instruments for a site.

```text
Browser
  -> site_detail_records.js
  -> GET /api/sites/:id/instruments
  -> api.js adds JWT token
  -> backend/server.js requireAuth
  -> SQL joins instruments + erc_locations + lookups
  -> JSON response
  -> frontend renders table
```

Example: user uploads instrument CSV.

```text
Browser file input
  -> FormData upload
  -> POST /api/sites/:id/instruments/import
  -> multer receives file
  -> xlsx parses CSV/XLS/XLSX
  -> headers are mapped to DB fields
  -> \N / ######## are normalized
  -> lookup IDs are validated or created
  -> instruments inserted or updated in one transaction
  -> response shows inserted/updated/skipped
```

Example: user adds contact.

```text
Contact form
  -> POST /api/sites/:id/contacts
  -> role check: admin/editor
  -> validation
  -> duplicate check
  -> insert/update contact
  -> link to matching RERC site if relevant
  -> frontend reloads contacts
```

## 13. Important Constraints

Database constraints:

- `users.email` is unique.
- `erc_locations.erc_id` is primary key.
- `instruments.erc_id` is required.
- Instrument lookup IDs must exist because of foreign keys.
- `site_contact_links` uses `(site_id, contact_id)` as composite primary key.
- `geo_features.geom` requires PostGIS.

Application constraints:

- Login required for protected detail pages and record APIs.
- Admin/editor required for writes.
- Manual instrument form requires serial number and model.
- Import requires model but allows missing serial number.
- Contact form requires name, email, and telephone.

## 14. Common Scenarios And Answers

### What happens if login expires?

Protected API returns `401`. `api.js` clears session and redirects/forces login.

### What happens if a viewer tries to add data?

Backend returns `403 Insufficient permissions`.

### What happens if CSV has `\N`?

It is stored as NULL, not as text.

### What happens if Excel shows `########`?

It usually means the date/number column is too narrow. Import treats it as NULL so PostgreSQL date fields do not fail.

### Why did CSV say imported 225 but count did not increase before?

Earlier, repeated CSV `INST_ID` values caused updates. Now the response separates inserted and updated, and repeated CSV IDs can get new DB IDs when they are different instruments.

### Why keep RERC `erc_id` as 1..23?

It matches the mentor-style CSV data and makes instrument import predictable.

### Does contact data affect map layers?

No. Contacts and map geometry are separate tables and routes.

### Does instrument upload affect contacts or login?

No. It only touches instruments and lookup tables inside a database transaction.

## 15. Demo Explanation Flow

Use this order when explaining:

1. Show main map and overlays.
2. Explain NPP vs DAE-RERC markers.
3. Open one site detail page.
4. Login.
5. Show site details and records panel.
6. Show contacts form and DAE/RERC lookup fields.
7. Show instrument list and upload option.
8. Explain that CSV `ERC_ID` maps to a RERC unit.
9. Show ERD and explain normalized tables.
10. Show protected GIS layers for a populated NPP site.
11. Explain offline setup and database restore.

## 16. Current Project Strengths

- Simple frontend stack, easy to inspect.
- Real backend and database, not fake local-only storage.
- JWT login and role checks.
- PostGIS storage for protected geometry.
- RERC-specific behavior.
- Instrument import handles legacy CSV/Excel data.
- ERD, migrations, run guide, and presentation docs are included.

## 17. Known Practical Notes

- Some lookup names came from screenshots where spreadsheet columns were truncated; visible text was inserted exactly.
- Contact schema supports site scoping, but current contact list route returns all contacts.
- For production, replace demo credentials and use a strong `JWT_SECRET`.
- For concurrent heavy imports, ID handling is acceptable for this local/admin workflow but could be moved fully to identity/default DB-generated IDs later.

## 18. Quick Commands

Start app:

```powershell
npm start
```

Health check:

```powershell
Invoke-RestMethod http://localhost:5000/api/health
```

Count instruments:

```sql
SELECT COUNT(*) FROM instruments;
```

Check RERC mapping:

```sql
SELECT erc_id, location, unit, std_code
FROM erc_locations
ORDER BY erc_id;
```

Check orphan instrument references:

```sql
SELECT COUNT(*)
FROM instruments i
LEFT JOIN erc_locations e ON e.erc_id = i.erc_id
WHERE e.erc_id IS NULL;
```

## 19. Files To Mention In Viva

```text
backend/server.js
db/init/001_schema.sql
docs/database_erd.svg
docs/GIS_Map_Project_Self_Study_Guide.md
docs/GIS_Map_Project_Presentation.pptx
npp_sites/site_detail_records.js
backend/scripts/import_geojson.js
```

## 20. One-Line Closing

This project connects map-based site discovery with protected operational records and spatial layers using a lightweight Leaflet frontend, an Express API, and a normalized PostgreSQL/PostGIS database.
