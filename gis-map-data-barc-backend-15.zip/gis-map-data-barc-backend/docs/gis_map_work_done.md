# GIS Map Work Done

> Superseded for study/handoff by `docs/GIS_Map_Project_Self_Study_Guide.md`.
> This file is kept only as an older work log.

Last updated: 2026-07-14

This is the handoff reference for continuing the GIS Map Data BARC backend project.

## Current Purpose

The app is a GIS-based site viewer and records system for:

- NPP site markers and detail pages.
- DAE-RERC unit markers and detail pages.
- Contacts and instruments linked to site context.
- Protected site-specific GIS layers stored in PostGIS.

## Stack

```text
Frontend: HTML, CSS, JavaScript, Leaflet
Backend: Node.js, Express
Database: PostgreSQL + PostGIS
Auth: JWT in sessionStorage
Run command: npm start
```

Main files:

```text
index.html                         Main map page
auth.js                            Login/signup/logout
api.js                             Authenticated fetch wrapper
styles.css                         Shared styling

npp_sites/map.js                   Main map bootstrap
npp_sites/map_common.js            Shared Leaflet markers/overlays
npp_sites/site.html                Protected site detail page
npp_sites/site_detail.js           Site detail bootstrap and panel/map behavior
npp_sites/site_detail_records.js   Contacts and instruments UI
npp_sites/site_detail_layer_controller.js
                                   Protected GIS layer rendering

backend/server.js                  Express routes and DB writes
backend/config.js                  .env config loader
backend/db.js                      PostgreSQL pool

db/init/001_schema.sql             Fresh DB schema and seed data
db/migrations/20260712_rerc_contacts_common.sql
                                   Contacts/instrument cleanup migration
db/migrations/20260714_vecc_dae_unit.sql
                                   Existing DB migration for BARC / VECC -> VECC
```

## Startup And Deployment

The app does not create tables on startup. Initialize or restore the DB first.

Fresh schema:

```powershell
psql -U <user> -d <db> -f db/init/001_schema.sql
```

Restore dump:

```powershell
pg_restore -U <user> -d <db> --no-owner --no-privileges gis_db_backup.dump
```

Required `.env` values:

```text
DB_HOST=localhost
DB_PORT=5432
DB_NAME=<database>
DB_USER=<user>
DB_PASSWORD=<password>
JWT_SECRET=<secret>
PORT=5000
```

PostGIS is required because:

- `geo_features.geom` uses `geometry(Geometry, 4326)`.
- Layer APIs use `ST_AsGeoJSON`.

For offline PCs:

- Install Node.js.
- Install PostgreSQL.
- Install matching PostGIS for that PostgreSQL major version.
- Add `C:\Program Files\PostgreSQL\<version>\bin` to PATH, or call `psql.exe` / `pg_restore.exe` by full path.
- Copy npm dependencies from an internet-connected machine if `npm install` cannot run.

## Main App Flow

```text
1. Browser opens http://localhost:5000/.
2. index.html loads auth.js, api.js, Leaflet, map_common.js, map.js.
3. Main map calls GET /api/sites.
4. Sites are split into:
   - NPP Sites overlay
   - DAE-RERC Units overlay
5. Clicking a marker opens npp_sites/site.html?id=<site_id>.
6. Site detail page requires JWT login.
```

## Auth And Roles

Routes:

```http
POST /api/auth/login
POST /api/auth/signup
GET  /api/auth/me
POST /api/auth/logout
```

Roles:

```text
viewer -> read protected pages and records
editor -> add/edit/delete contacts and instruments
admin  -> same record permissions as editor
```

JWT is stored in `sessionStorage`; closing the tab/window clears the session.

## Site Detail Behavior

The protected detail page loads:

- Current site details.
- All site marker context.
- Contacts.
- Instruments.
- ERC/instrument locations.
- Lookup tables.
- Leaflet map overlays.

RERC pages:

- Hide the Site Layers UI.
- Skip protected site-specific PostGIS layers.
- Use a wider sidebar.
- Focus on contacts and instruments.

Non-RERC pages:

- Load protected site-specific GIS layers through `/api/sites/:id/layers`.

The sidebar width is user-resizable and saved in:

```text
localStorage: nppSites.siteDetailSidebarWidth
```

## Database Overview

Core tables:

```text
users
sites
contacts
site_contact_links
erc_locations
instruments
manufacturers
instrument_categories
instrument_status
layer_catalog
site_layers
geo_features
```

Main relationships:

```text
sites.id -> erc_locations.site_id
sites.id -> instruments.site_id
erc_locations.erc_id -> instruments.erc_id
sites.id -> site_contact_links.site_id
contacts.id -> site_contact_links.contact_id
sites.id -> site_layers.site_id
layer_catalog.layer_key -> site_layers.layer_key
layer_catalog.layer_key -> geo_features.layer_key
sites.id -> geo_features.site_id
```

See `docs/database_erd.svg` for the visual ERD.

## Contacts

Tables:

```text
contacts
site_contact_links
```

Schema supports:

```text
contacts.applies_to_all_sites = TRUE
  -> common contact

contacts.applies_to_all_sites = FALSE + site_contact_links row
  -> site-linked contact
```

Current routes:

```http
GET    /api/sites/:id/contacts
POST   /api/sites/:id/contacts
PUT    /api/contacts/:id
DELETE /api/contacts/:id
GET    /api/rerc-units
```

Visible form fields:

```text
category
dae_unit
city stored as contacts.unit
std_code
name
telephone 1, telephone 2
mobile 1, mobile 2
email 1, email 2, email 3
fax_no
remarks
```

Required:

```text
name
email 1
telephone 1
```

For DAE-RERC categories, at least one of these is also required:

```text
DAE unit, city, STD code
```

Latest VECC behavior:

- Existing DBs may still contain `BARC / VECC`.
- `db/migrations/20260714_vecc_dae_unit.sql` converts existing stored rows.
- `/api/rerc-units` also normalizes legacy `BARC / VECC` to `VECC`, so the contacts DAE Unit lookup shows `VECC`.
- Contact matching logic also treats legacy `BARC / VECC` site operator as `VECC`.

Important implementation note:

- The schema supports site-scoped contacts, but the current `GET /api/sites/:id/contacts` implementation returns all contacts ordered by category/unit/name.
- Duplicate detection is based on category + name + email + dae_unit + city + std_code.

## Instruments

Tables:

```text
erc_locations
instruments
manufacturers
instrument_categories
instrument_status
users
```

Routes:

```http
GET    /api/sites/:id/erc-locations
GET    /api/sites/:id/instruments
POST   /api/sites/:id/instruments
PUT    /api/instruments/:id
DELETE /api/instruments/:id
GET    /api/instrument-lookups
```

Behavior:

- `erc_locations` is the internal instrument-location master.
- RERC pages ensure one site-backed instrument-location row exists.
- Instrument save validates `erc_id`, serial number, and model.
- New manufacturer/category rows can be created from form input.
- Instruments store both:
  - `site_id`
  - `erc_id`

Fetch rule:

```sql
COALESCE(instruments.site_id, erc_locations.site_id) = :site_id
```

This keeps older rows usable while supporting direct site ownership.

## GIS Layers

Public overlays:

```text
data/india.geojson
data/states.geojson
data/districts.geojson
```

Protected site-specific layers:

```text
layer_catalog
site_layers
geo_features
```

Routes:

```http
GET /api/sites/:id/layers
GET /api/sites/:id/layers/:layerKey
```

`geo_features` stores:

```text
site_id
layer_key
properties jsonb
geom geometry(Geometry, 4326)
```

Import helper:

```text
backend/scripts/import_geojson.js
```

It reads from:

```text
secure_import_data/<site-folder>/<file-name>
```

Important setup note:

- `site_layers.layer_key` and `geo_features.layer_key` reference `layer_catalog.layer_key`.
- Fresh setup must seed `layer_catalog` rows before inserting matching `site_layers` rows.

## Current Seed State

Seeded site groups:

```text
NPP sites: 1-7
DAE-RERC sites: 101-123
```

RERC instrument locations:

```text
One erc_locations row for each RERC site 101-123.
```

Seeded contact placeholders:

```text
DAE-RERC Coordinator
DAE-RERC Alternate Coordinator
DAE-RERC Unit Head Details
```

Demo login:

```text
email: admin@example.local
password: Admin@12345
```

## Known Follow-Up Items

These are not blockers for understanding the project, but should be considered before final deployment:

```text
1. Make GET /api/sites/:id/contacts respect site_contact_links if site-scoped contact filtering is required.
2. Seed layer_catalog rows before site_layers in fresh DB setup.
3. Consider replacing MAX(id) + 1 helper with identity/default inserts to avoid concurrent ID collisions.
4. Confirm whether instrument create should reject ERC locations from a different site.
5. Run db/migrations/20260714_vecc_dae_unit.sql on existing databases that still show BARC / VECC.
```
