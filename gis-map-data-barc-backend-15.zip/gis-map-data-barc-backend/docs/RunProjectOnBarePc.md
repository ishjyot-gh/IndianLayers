# Run Project On A Bare / Offline PC

This file is the practical handoff guide for moving the project to another Windows PC, including a no-internet PC.

## 1. What This Project Contains

- Leaflet map frontend for NPP and DAE-RERC units.
- Express backend APIs.
- PostgreSQL/PostGIS database schema.
- Login with JWT.
- Contacts and instruments management.
- CSV/Excel instrument upload.
- Protected GIS layers from PostGIS.

Main run URL:

```text
http://localhost:5000/
```

Demo login:

```text
email: admin@example.local
password: Admin@12345
```

## 2. Dependencies Needed On Target PC

Install these before running:

1. Node.js LTS
2. PostgreSQL, same major version if restoring an existing dump
3. PostGIS bundle matching the PostgreSQL major version
4. Project folder
5. Database dump or SQL schema
6. `node_modules` folders if the target PC has no internet

Current Node dependencies:

```text
express
pg
bcryptjs
jsonwebtoken
multer
xlsx
```

For an offline PC, prepare these on an internet PC:

- Node.js installer
- PostgreSQL installer
- matching PostGIS installer
- full project folder
- `node_modules` at project root if present
- `backend/node_modules`
- `gis_db_backup.dump` if transferring current DB data

## 3. Files/Folders To Copy

Copy the full project folder:

```text
gis-map-data-barc-backend/
```

Important folders/files:

```text
backend/
data/
db/
docs/
lib/
npp_sites/
secure_import_data/
node_modules/              if available
backend/node_modules/      required offline
.env
package.json
gis_db_backup.dump         if restoring data
```

Do not rely on `npm install` on a no-internet PC unless dependencies are already cached.

## 4. PostgreSQL And PostGIS Setup

Open `psql` as postgres/admin:

```powershell
psql -U postgres -h localhost
```

If `psql` is not recognized:

```powershell
$pgBin = "C:\Program Files\PostgreSQL\17\bin"
$env:Path += ";$pgBin"
psql --version
```

Create user and database:

```sql
CREATE USER ishjyot_user WITH PASSWORD 'your_password';
CREATE DATABASE ishjyot_gis_db OWNER ishjyot_user;
\c ishjyot_gis_db
CREATE EXTENSION IF NOT EXISTS postgis;
```

If the user/database already exists, skip or adjust names.

## 5. Configure `.env`

At project root, `.env` should match the target DB:

```text
PORT=5000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=ishjyot_gis_db
DB_USER=ishjyot_user
DB_PASSWORD=your_password
JWT_SECRET=change-this-for-real-use
```

For local demo only, a simple JWT secret is acceptable. For real deployment, use a strong secret.

## 6. Restore Database With Existing Data

Recommended if `gis_db_backup.dump` exists:

```powershell
$env:PGPASSWORD="your_password"
pg_restore -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db --clean --if-exists --no-owner --no-privileges gis_db_backup.dump
```

Use this when the dump was created with:

```powershell
pg_dump -U postgres -h localhost -p 5432 -d gis_db -Fc -f gis_db_backup.dump
```

## 7. Fresh Schema Option

If no dump is available, initialize a fresh database:

```powershell
$env:PGPASSWORD="your_password"
psql -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db -f db/init/001_schema.sql
```

Then apply migrations that bring older/restored DBs to the latest expected state:

```powershell
psql -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db -f db/migrations/20260712_rerc_contacts_common.sql
psql -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db -f db/migrations/20260714_vecc_dae_unit.sql
psql -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db -f db/migrations/20260714_rerc_erc_ids_1_to_23.sql
psql -U ishjyot_user -h localhost -p 5432 -d ishjyot_gis_db -f db/migrations/20260714_populate_instrument_lookups.sql
```

If using a latest dump made after these migrations, you usually do not need to run them again.

## 8. Install/Check Node Dependencies

If internet is available:

```powershell
npm install
npm install --prefix backend
```

If offline:

- Copy `node_modules` and `backend/node_modules` from the source PC.
- Confirm `backend/node_modules/xlsx` and `backend/node_modules/multer` exist for instrument upload.

Quick check:

```powershell
node -v
npm -v
```

## 9. Start The App

From project root:

```powershell
npm start
```

Expected:

```text
Server running at http://localhost:5000
```

Open:

```text
http://localhost:5000/
```

Health check:

```powershell
Invoke-RestMethod http://localhost:5000/api/health
```

Expected:

```json
{"status":"ok"}
```

## 10. GeoJSON Layer Import

GeoJSON files should be placed under:

```text
secure_import_data/<site-folder>/<file-name>.geojson
```

For a layer to appear:

1. `sites.folder` must match `<site-folder>`.
2. `layer_catalog.layer_key` must exist.
3. `site_layers.site_id`, `layer_key`, `file_name`, and `is_enabled=true` must exist.
4. `geo_features` must contain imported geometry.

Import helper:

```powershell
node backend/scripts/import_geojson.js
```

If a layer does not show, check:

```sql
SELECT * FROM site_layers WHERE site_id = <site_id>;
SELECT layer_key, COUNT(*) FROM geo_features WHERE site_id = <site_id> GROUP BY layer_key;
```

## 11. Instrument Excel/CSV Upload

Open a DAE-RERC site detail page, click:

```text
Add Instrument -> Upload Excel / CSV
```

Supported:

```text
.csv
.xls
.xlsx
```

Important import behavior:

- `ERC_ID` maps to `erc_locations.erc_id`.
- Current RERC `erc_id` range is `1..23`.
- `\N`, blank, `NULL`, and `########` are treated as NULL.
- Text statuses like `Working` are created/reused.
- Serial number is optional only for import.
- Manual Add Instrument form still requires serial number.
- Response shows inserted vs updated rows.

Check count:

```sql
SELECT COUNT(*) FROM instruments;
```

## 12. Contacts

Contacts are managed on the site detail page.

Required:

```text
Name
Email 1
Telephone 1
```

DAE-RERC categories should include at least one of:

```text
DAE Unit
City
STD Code
```

VECC naming is normalized in the app.

## 13. Quick Verification Checklist

Run these after setup:

```powershell
Invoke-RestMethod http://localhost:5000/api/health
```

```sql
SELECT COUNT(*) FROM sites;
SELECT COUNT(*) FROM erc_locations;
SELECT MIN(erc_id), MAX(erc_id), COUNT(*) FROM erc_locations;
SELECT COUNT(*) FROM manufacturers;
SELECT COUNT(*) FROM instrument_categories;
SELECT COUNT(*) FROM instruments;
```

Expected latest lookup state:

```text
erc_locations: 23 rows, erc_id 1..23
manufacturers: 18 rows
instrument_categories: 9 rows
```

Login test:

```text
admin@example.local / Admin@12345
```

Browser test:

1. Main map loads.
2. NPP and DAE-RERC markers appear.
3. Site detail opens after login.
4. Contacts section works.
5. Instruments section works.
6. Instrument CSV/Excel upload works.
7. NPP layer toggles work where layer data is populated.

## 14. Common Problems

### `psql` not recognized

Add PostgreSQL `bin` folder to PATH or call full path:

```powershell
& "C:\Program Files\PostgreSQL\17\bin\psql.exe" --version
```

### PostGIS extension error

Install the PostGIS bundle matching your PostgreSQL version, then run:

```sql
CREATE EXTENSION IF NOT EXISTS postgis;
```

### Login fails

Check the database has demo user or restore completed. Also check `.env` points to the correct DB.

### Server cannot connect to DB

Check:

```text
DB_HOST
DB_PORT
DB_NAME
DB_USER
DB_PASSWORD
```

### Instrument upload fails

Check:

- `backend/node_modules/multer` exists.
- `backend/node_modules/xlsx` exists.
- CSV has `ERC_ID` and model column.
- `erc_locations` contains the referenced `ERC_ID`.

## 15. Current Work Summary

- Map and site detail UI are working.
- Login and roles are implemented.
- Contacts add/edit/delete are implemented.
- Instruments add/edit/delete are implemented.
- Instrument CSV/Excel upload is implemented.
- RERC `erc_id` mapping is `1..23`.
- Manufacturer/category lookup tables are populated.
- Protected PostGIS layer model exists.
- Documentation, ERD, and presentation files are updated.
