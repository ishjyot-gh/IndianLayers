# Database ERD Verification

Verified on 2026-07-15 against:

- Live PostgreSQL database: `gis_db`
- Backup file: `gis_db_backup.dump`
- Backend route usage in `backend/server.js`

Shareable diagram:

- `docs/database_erd.svg`

## Result

The ERD now matches the current application database structure for the 12 application tables:

- `users`
- `sites`
- `erc_locations`
- `manufacturers`
- `instrument_categories`
- `instrument_status`
- `instruments`
- `contacts`
- `site_contact_links`
- `layer_catalog`
- `site_layers`
- `geo_features`

PostGIS metadata/system tables such as `spatial_ref_sys`, `geometry_columns`, and `geography_columns` are intentionally omitted.

## Important Accuracy Notes

- `site_layers.layer_key` has an actual foreign key to `layer_catalog.layer_key`.
- `geo_features.layer_key` is used by backend queries as a logical match to `layer_catalog.layer_key`, but the current database does not define a foreign-key constraint for it.
- `site_contact_links` is the many-to-many link table between `sites` and `contacts`.
- `instruments` connects to `sites`, `erc_locations`, lookup tables, and `users`.
- `sites.geom` exists in the current live database/backup.

## Backend Schema Drift Note

`db/init/001_schema.sql` is not a perfect mirror of the current live database/backup for every column and constraint. For sharing the project ERD, use the verified SVG. For recreating the database, prefer the checked backup dump unless the init SQL is brought fully in sync.
