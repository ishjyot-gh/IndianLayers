let siteMap;

function getSiteIdFromUrl() {
  const params = new URLSearchParams(window.location.search);
  return Number(params.get("id"));
}

function formatLabel(key) {
  const labels = {
    id: "ID",
    lat: "Latitude",
    lng: "Longitude",
    reactor_type: "Reactor Type",
    installed_capacity_mw: "Installed Capacity (MW)"
  };

  return labels[key] || key.replace(/_/g, " ").replace(/\b\w/g, char => char.toUpperCase());
}

function formatValue(value) {
  if (value === undefined || value === null || value === "") return "Not available";
  if (Array.isArray(value)) return value.join(", ");
  return String(value);
}

function renderSiteDetails(site) {
  const detailList = document.getElementById("siteDetails");

  const preferredOrder = [
    "id",
    "state",
    "zone",
    "reactor_type",
    "operator",
    "installed_capacity_mw",
    "units",
    "status",
    "lat",
    "lng"
  ];

  const hiddenKeys = [
    "name",
    "description",
    "folder",
    "layers",
    "layer_sets",
    "site_layers",
    "has_site_layers",
    "generate_sectors",
    "sector_radius_km",
    "sector_count"
  ];

  const displayedKeys = preferredOrder.filter(key => key in site);
  const remainingKeys = Object.keys(site).filter(key =>
    !hiddenKeys.includes(key) && !displayedKeys.includes(key)
  );

  detailList.replaceChildren();

  [...displayedKeys, ...remainingKeys].forEach(key => {
    const term = document.createElement("dt");
    const description = document.createElement("dd");

    term.textContent = formatLabel(key);
    description.textContent = formatValue(site[key]);

    detailList.append(term, description);
  });
}

async function initSitePage() {
  const siteId = getSiteIdFromUrl();

  const sites = await fetch("../data/sites.json").then(response => response.json());
  const layersCatalog = await fetch("../data/layers.json").then(response => response.json());

  const currentSite = sites.find(site => site.id === siteId);

  if (!currentSite) {
    document.getElementById("siteName").textContent = "Site not found";
    document.getElementById("siteDescription").textContent = "No matching site was found in sites.json.";
    return;
  }

  document.getElementById("siteName").textContent = currentSite.name;
  document.getElementById("siteDescription").textContent = currentSite.description || "";
  document.getElementById("siteStatus").textContent = currentSite.status || "Operational";

  renderSiteDetails(currentSite);

  siteMap = L.map("siteMap").setView([currentSite.lat, currentSite.lng], 9);

  const overlays = {};
  const layerControl = L.control.layers(null, overlays, { collapsed: false }).addTo(siteMap);

  const visibleLayerNames = window.NppSitesCommon.getVisibleLayerNames();
  const markLayersReady = window.NppSitesCommon.bindLayerStatePersistence(siteMap, overlays);

  window.NppSitesCommon.createSiteMarkerPane(siteMap);
  window.NppSitesCommon.addTileLayer(siteMap);

  await window.NppSitesCommon.loadStandardLayers({
    map: siteMap,
    layerControl,
    overlays,
    visibleLayerNames,
    sites,
    dataRoot: "../data",
    selectedSiteId: currentSite.id,
    detailHrefForSite: site => `./site.html?id=${site.id}`
  });

  const resolvedLayers = resolveSiteLayers(currentSite, layersCatalog);
  await loadSiteLayers(currentSite, resolvedLayers);

  if (currentSite.generate_sectors) {
    addGeneratedSectors(currentSite);
  }

  markLayersReady();
}

function resolveSiteLayers(site, layersCatalog) {
  const layerSetNames = site.layer_sets || [];
  const layerKeys = [];

  layerSetNames.forEach(setName => {
    const setLayers = layersCatalog.layer_sets?.[setName] || [];

    setLayers.forEach(key => {
      if (!layerKeys.includes(key)) {
        layerKeys.push(key);
      }
    });
  });

  return layerKeys
    .map(key => layersCatalog.layers.find(layer => layer.key === key))
    .filter(Boolean);
}

async function loadSiteLayers(site, layerConfigs) {
  if (!site.folder || !layerConfigs.length) return;

  const groupedLayers = {};
  const allSiteLayers = [];

  for (const layerConfig of layerConfigs) {
    const url = `../data/${site.folder}/${layerConfig.key}.geojson`;

    try {
      const data = await fetch(url).then(response => {
        if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
        return response.json();
      });

      const layer = L.geoJSON(data, {
        style: getStyleForSiteLayer(layerConfig.key),
        pointToLayer(feature, latlng) {
          return L.circleMarker(latlng, getPointStyleForSiteLayer(layerConfig.key));
        },
        onEachFeature(feature, leafletLayer) {
          leafletLayer.bindPopup(createGenericPopup(feature.properties || {}, layerConfig.name));
        }
      });

      layer.addTo(siteMap);
      allSiteLayers.push(layer);

      if (!groupedLayers[layerConfig.category]) {
        groupedLayers[layerConfig.category] = [];
      }

      groupedLayers[layerConfig.category].push({
        name: layerConfig.name,
        layer
      });
    } catch (error) {
      console.warn(`Skipping ${layerConfig.name}:`, error);
    }
  }

  renderLayerPanel(groupedLayers);

  if (allSiteLayers.length > 0) {
    const bounds = L.featureGroup(allSiteLayers).getBounds();

    if (bounds.isValid()) {
      siteMap.fitBounds(bounds, {
        padding: [30, 30],
        maxZoom: 12
      });
    }
  }
}

function renderLayerPanel(groupedLayers) {
  const panel = document.getElementById("siteLayerPanel");

  if (!panel) return;

  panel.innerHTML = "";

  Object.entries(groupedLayers).forEach(([category, layers]) => {
    const categoryBox = document.createElement("div");
    categoryBox.className = "layer-category";

    const button = document.createElement("button");
    button.type = "button";
    button.className = "layer-category-button";
    button.textContent = category;

    const layerList = document.createElement("div");
    layerList.className = "layer-list";
    layerList.style.display = "none";

    button.addEventListener("click", () => {
      layerList.style.display = layerList.style.display === "none" ? "block" : "none";
    });

    layers.forEach(item => {
      const label = document.createElement("label");
      label.className = "layer-checkbox";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = siteMap.hasLayer(item.layer);

      checkbox.addEventListener("change", () => {
        if (checkbox.checked) {
          item.layer.addTo(siteMap);
        } else {
          siteMap.removeLayer(item.layer);
        }
      });

      label.append(checkbox, ` ${item.name}`);
      layerList.appendChild(label);
    });

    categoryBox.append(button, layerList);
    panel.appendChild(categoryBox);
  });
}

function addGeneratedSectors(site) {
  const radiusKm = site.sector_radius_km || 16;
  const sectorCount = site.sector_count || 16;
  const angleStep = 360 / sectorCount;

  const sectorLayerGroup = L.layerGroup();

  for (let i = 0; i < sectorCount; i++) {
    const startAngle = i * angleStep;
    const endAngle = startAngle + angleStep;
    const sectorName = String.fromCharCode(65 + i);

    const polygonCoords = createSectorPolygon(site.lat, site.lng, radiusKm, startAngle, endAngle);

    const sector = L.polygon(polygonCoords, {
      className: "layer-sector"
    });

    sector.bindPopup(`
      <b>Sector ${sectorName}</b><br>
      Radius: ${radiusKm} km<br>
      Angle: ${startAngle}° - ${endAngle}°
    `);

    sector.addTo(sectorLayerGroup);
  }

  sectorLayerGroup.addTo(siteMap);
}

function createSectorPolygon(centerLat, centerLng, radiusKm, startAngle, endAngle) {
  const points = [[centerLat, centerLng]];
  const steps = 12;

  for (let i = 0; i <= steps; i++) {
    const angle = startAngle + ((endAngle - startAngle) * i) / steps;
    points.push(destinationPoint(centerLat, centerLng, radiusKm, angle));
  }

  points.push([centerLat, centerLng]);
  return points;
}

function destinationPoint(lat, lng, distanceKm, bearingDeg) {
  const earthRadiusKm = 6371;
  const bearing = bearingDeg * Math.PI / 180;

  const lat1 = lat * Math.PI / 180;
  const lng1 = lng * Math.PI / 180;
  const angularDistance = distanceKm / earthRadiusKm;

  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(angularDistance) +
    Math.cos(lat1) * Math.sin(angularDistance) * Math.cos(bearing)
  );

  const lng2 = lng1 + Math.atan2(
    Math.sin(bearing) * Math.sin(angularDistance) * Math.cos(lat1),
    Math.cos(angularDistance) - Math.sin(lat1) * Math.sin(lat2)
  );

  return [
    lat2 * 180 / Math.PI,
    lng2 * 180 / Math.PI
  ];
}

function getStyleForSiteLayer(key) {
  const classMap = {
    district_boundary: "layer-district-boundary",
    taluk_boundary: "layer-taluk-boundary",
    road: "layer-road",
    railway_track: "layer-railway-track",
    river_line: "layer-river-line",
    canal_line: "layer-canal-line",
    water_bodies: "layer-water-bodies",
    settlement: "layer-settlement",
    hospital: "layer-hospital",
    landmark: "layer-landmark",
    sector: "layer-sector"
  };

  return {
    className: classMap[key] || "layer-default"
  };
}

function getPointStyleForSiteLayer(key) {
  const classMap = {
    settlement_point: "marker-settlement-point",
    railway_station: "marker-railway-station",
    hospital: "marker-hospital",
    landmark: "marker-landmark"
  };

  return {
    radius: 5,
    className: classMap[key] || "marker-default"
  };
}

function createGenericPopup(properties, layerName) {
  const preferredFields = [
    "NAME",
    "Name",
    "name",
    "TYPE",
    "Type",
    "type",
    "SETTLEMENT",
    "SETTLE_POI",
    "AREA",
    "PERIMETER",
    "SECTOR",
    "SECTOR_NAM",
    "RADIUS"
  ];

  let html = `<b>${layerName}</b><br>`;

  preferredFields.forEach(field => {
    if (properties[field] !== undefined && properties[field] !== null && properties[field] !== "") {
      html += `${field}: ${properties[field]}<br>`;
    }
  });

  return html;
}

initSitePage();